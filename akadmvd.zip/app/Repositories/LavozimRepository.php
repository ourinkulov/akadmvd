<?php

namespace App\Repositories;

use App\Models\Lavozim;

class LavozimRepository implements LavozimRepositoryInterface
{

    public function all()
    {
        return Lavozim::all();
    }

    public function find($id)
    {
        return Lavozim::find($id);
    }

    public function create(array $data)
    {
        return Lavozim::create($data);
    }

    public function update($id, array $data)
    {
        $lavozim = $this->find($id);
        $lavozim->update($data);
        return $lavozim;
    }

    public function delete($id)
    {
        return Lavozim::destroy($id);
    }
}
