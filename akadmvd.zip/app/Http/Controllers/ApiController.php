<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Kriteriya;
use App\Models\User;
use App\Models\Yuklamalar;
use Illuminate\Http\Request;
use Spatie\LaravelIgnition\Solutions\UseDefaultValetDbCredentialsSolution;
use Illuminate\Support\Facades\DB;

class ApiController extends Controller
{

    const uy_id = 5;
    public function insertMonitoringData(Request $request)
    {
        // Validate incoming request
        $validatedData = $request->validate([
            'user_id' => 'required|exists:users,hemis_id',
            // Add other validation rules for the data in $request->all()
        ]);

        // Fetch the user based on hemis_id
        $user = DB::table('users')->where('hemis_id', $validatedData['user_id'])->first();

        // Create the monitoring data
        $yuklama = new Yuklamalar($request->all());
        $yuklama->user_id = $user->id;

        return $yuklama->save()
            ? response()->json(['status' => 'true', 'message' => 'Monitoring data inserted successfully.'])
            : response()->json(['status' => 'false', 'message' => 'Xatolik yuz berdi.']);
    }

}
