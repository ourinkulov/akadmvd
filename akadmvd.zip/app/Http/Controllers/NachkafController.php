<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Yuklamalar;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class NachkafController extends Controller
{
    const uy_id = 4;
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function login()
    {
        $res = DB::table('yuklamalar as y')
            ->select('u.kaf_id', 'u.kaf_name', 'k.id', 'k.band', DB::raw('count(y.id) as soni'))
            ->leftJoin('users as u', 'y.user_id', '=', 'u.id')
            ->leftJoin('kriteriyas as k', 'y.kriteriya_id', '=', 'k.id')
            ->where('kaf_id', '=', Auth::user()->kaf_id)
            ->where('y.uy_id', '=', self::uy_id)
            ->groupBy('u.kaf_id', 'k.id', 'u.kaf_name', 'k.band')
            ->orderBy('k.id')
            ->get();
        $subquery = User::select('u.id')
            ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
            ->where('i.turi_id', '=', 2)
            ->where('u.role', '=', 3);
        $subquery2 = User::select('u.id')
            ->leftJoin('ilmiyunvons as i', 'u.id', '=', 'i.user_id')
            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
            ->where('i.turi_id', '=', 2)
            ->where('u.role', '=', 3);

                $teacherCount=User::query()->where('kaf_id','=',Auth::user()->kaf_id)->where('role','=',3)->count();
                $teacherCountAll=User::query()->where('role','=',3)->count();
        $dscIds =  DB::table('yuklamalar')
            ->select('user_id')
            ->where('kriteriya_id','=',16)
            ->where('tur_id','=',2)
            ->distinct();
        $phdIds = DB::table('yuklamalar')
            ->select('user_id')
            ->where('kriteriya_id','=',16)
            ->where('tur_id','=',1)
            ->distinct();
        $dotsWithoutDegree = DB::table('yuklamalar')
            ->select('user_id')
            ->where('kriteriya_id','=',16)
            ->whereNotIn('tur_id',[1,2])
            //->orWhere('tur_id','=',2)
            ->distinct();

        $dsc= DB::table('yuklamalar')
            ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
            ->where('kriteriya_id','=',16)
            ->where('tur_id','=',2)
            //->whereNotIn('user_id',$phdIds)
            ->distinct()
            ->count();
        $phd= DB::table('yuklamalar')
                            ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
                            ->where('kriteriya_id','=',16)
                            ->where('tur_id','=',1)
                            ->whereNotIn('user_id',$dscIds)
                            ->distinct()
                            ->count();
        $dotsWithoutDegree= DB::table('yuklamalar as y')
        ->leftJoin('users as u', 'y.user_id', '=', 'u.id')
        ->select('y.user_id')
        ->where('y.kriteriya_id','=',17)
        ->where('y.tur_id','=',1)
        ->where('u.kaf_id','=', Auth::user()->kaf_id)
        ->whereNotIn('y.user_id',$phdIds)
        ->whereNotIn('y.user_id',$dscIds)
        ->count();
        $dotsent =  Yuklamalar::selectRaw('count(id) as soni')
        ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
        ->where('kriteriya_id','=',17)
        ->where('tur_id','=',1)
        ->distinct()
        ->first();
        $professor=Yuklamalar::selectRaw('count(id) as soni')
        ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
        ->where('kriteriya_id','=',17)
        ->where('tur_id','=',2)
        ->distinct()
        ->first();

                $idisnot = DB::table('users as u')
                    ->select('u.id')
                    ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
                    ->where('i.turi_id', '=', NULL)
                    ->where('u.kaf_id', '=', Auth::user()->kaf_id)
                    ->where('u.role', '=', 3)
                    //->groupBy('u.id')
                    ->count();
                $passiveTeachs = DB::table('users as u')
                    ->select('u.id', 'u.name', 'u.lavozim', 'u.image')
                    ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
                    ->whereNull('y.id')
                    ->where('u.kaf_id', '=', Auth::user()->kaf_id)
                    ->where('u.role', '=', 3)
                    ->get();




//            DB::table('v_teacher_all_results')
//            ->where('kaf_id','=',Auth::user()->kaf_id)
//            ->get();
        //dd($res);
        return view('dashboards.nachkaf',compact('res','dotsWithoutDegree','teacherCount','dsc','phd','idisnot','teacherCountAll','passiveTeachs','dotsent','professor'));
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = DB::table('users as u')
            ->leftJoin('lavozims as l', 'u.lavozim_id', '=', 'l.id')
            ->select('u.id', 'u.name', 'l.lavozim_name', 'u.image','u.email','u.pwd','u.created_at','u.role','u.passport_pin')
            ->whereIn('role',[3,4])
            ->where('kaf_id','=',Auth::user()->kaf_id)
            ->orderBy('role')
            ->get();
        $kafedras = DB::table('users')->select('id', 'name')->where('role','=',4)->get();
        return view('nachkaf.users.index',compact('users','kafedras'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('nachkaf.users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
        $validData = $request->validate(
            [
                'name' => ['required', 'string', 'max:255'],
                'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                'password' => ['required', 'string', 'min:8', 'confirmed'],
                'image' => ['required',],
                'lavozim_id'=> ['required',],
                'stavka_id'=> ['required',],
                'lavozim'=> ['required', 'string', 'max:255'],
                'born'=>['required',],
                'malumoti_id'=>['required',],
                'malumoti'=>['required',],
                'mutaxassislik'=>['required',],
                'iio'=>['required',],
                'ait'=>['required',],
                'pid'=>['required',],
                'pnfl'=>['required',],
            ]
        );
        if ($validData) {
           // dd($request);
            if ($request->hasFile('image')) {
                $name = $request->file('image')->getClientOriginalName();

                $fileFullname = time() . $name;

                if (
                    $user = User::create([
                        'name' => $validData['name'],
                        'lavozim_id' => $validData['lavozim_id'],
                        'stavka_id' => $validData['stavka_id'],
                        'lavozim' => $validData['lavozim'],
//                        'name' => $validData['name'],
                        'email' => $validData['email'],
                        'password' => Hash::make($validData['password']),
                        'image' => $fileFullname,
                        'role' => 3,
                        'born' => $validData['born'],
                        'malumoti_id' => $validData['malumoti_id'],
                        'malumoti' => $validData['malumoti'],
                        'mutaxassislik' => $validData['mutaxassislik'],
                        'iio' => $validData['iio'],
                        'ait' => $validData['ait'],
                        'pit' => $validData['pid'],
                        'passport_pin' => $validData['pnfl'],
                        'kaf_id' => Auth::user()->kaf_id,
                        'kaf_name' => Auth::user()->kaf_name,
                    ])
                ) {
                    $path = $request->file('image')->storeAs('public/userimage', time() . $name);
                    return back()->with('status', ' Yaratildi !!!');
                } else {

                    return back()->with('danger', ' Xatolik yuz berdi  !!!');
                }
            }
            else {
                return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
            }
        }
        else {
            return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        if($request->action == 'stavka')
        {

            $user = User::find($id);
            //dd($user);
             $user->stavka_id = $request->stavka_id;
             $user->save();
            return back()->with('status', ' Yangilandi !!!');
        }
        else
        {
            $user = User::find($id);
            if (  $user->password = Hash::make($request->password))
            {
                //dd($request->password);
                $user->pwd = $request->password;
                $user->save();
                return back()->with('status', ' Yangilandi !!!');
            }
            else
            {

                return back()->with('danger', ' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function passwd($id)
    {
        $user = User::find($id);
        return view('nachkaf.users.passwd',compact('user'));
    }

    public function changepasswd(Request $request)
    {

    }

    public function getTeacherResultsByCategory($id)
    {
        $res = Yuklamalar::query()
            ->where('kriteriya_id','=',$id)
            ->whereIn('user_id', function ($query) {
            $query->select('id')
                ->from('users')
                ->where('users.kaf_id', Auth::user()->getAuthIdentifier());
        })->get();
        $kriteriyaName = User\Kriteriya::query()
            ->select('band')
            ->where('id','=',$id)->first();

        return view('nachkaf.results.yuklamalar',compact('res','kriteriyaName'))->with('i');
        //dd($res);

    }
    public function changestatus($id)
    {

        $user = User::find($id);
        //dd($user);
        $user->active = 0;
        $user->save();
        return back()->with('status', ' Yangilandi !!!');
    }

    public function transfer(Request $request, $id)
    {
       // dd($request->all());
        // Validate input
        $validated = $request->validate([
            'kafedra_id' => 'required|exists:users,id',
        ]);
        //dd($request->all());

        // Find your main model (e.g., employee, teacher, etc.)
        $item = User::findOrFail($id);
        $kafname = DB::table('users')->select('name')->where('id','=',$validated['kafedra_id'])->first();
        //dd($item->name);

        // Update kafedra
        $item->kaf_id = $validated['kafedra_id'];
        $item->kaf_name = $kafname->name;
        $item->save();

        // Optionally, redirect back with success message
        return redirect()->back()->with('success', 'O‘tkazish muvaffaqiyatli amalga oshirildi!');
    }
}
