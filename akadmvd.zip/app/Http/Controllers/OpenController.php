<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class OpenController extends Controller
{
   public function getuser(Request $request)
   {
       $fans = User::query()->where('kaf_id',$request->kaf_id)->get();
       return response()->json($fans);
   }
}
