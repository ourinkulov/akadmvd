<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IlmiyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function login()
    {

        return view('dashboards.ilmiy');
    }
}
