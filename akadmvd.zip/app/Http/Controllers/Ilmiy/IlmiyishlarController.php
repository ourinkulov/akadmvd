<?php

namespace App\Http\Controllers\Ilmiy;

use App\Http\Controllers\Controller;
use App\Models\User\Ilmiyishlar;
use App\Models\User\Monografiya;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class IlmiyishlarController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ilmiyishlar = DB::table('ilmiyishlars')
            ->where('status','=','1')
            ->get();
        return view('ilmiy.ilmiytadqiqot.ilmiyishlar.index',compact('ilmiyishlar'))->with('i');
    }
    public function warindex()
    {
        $ilmiyishlar = DB::table('ilmiyishlars')
            ->where('status','=','3')
            ->get();
        return view('ilmiy.ilmiytadqiqot.ilmiyishlar.warning',compact('ilmiyishlar'))->with('i');
    }
    public function sucindex()
    {
        $ilmiyishlar = DB::table('ilmiyishlars')
            ->where('status','=','2')
            ->get();
        return view('ilmiy.ilmiytadqiqot.ilmiyishlar.success',compact('ilmiyishlar'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ilmiyishlar = DB::table('ilmiyishlars')->where('id',$id)->first();
        return view('ilmiy.ilmiytadqiqot.ilmiyishlar.create',compact('ilmiyishlar'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
            'turi_id' => 'required',
            'turi_name' => 'required',
            'soni' => 'required',

        ]))
        {
            //dd($request->taboq);
            $kazus = Ilmiyishlar::find($id);
            //$taboq = $request->taboq;

            if ($kazus->update([
                'ball'=>$request->ball,
                'turi_id'=>$request->turi_id,
                'turi_name'=>$request->turi_name,
                'soni'=>$request->soni,

                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ilmiyd = Ilmiyishlar::find($id);

        if ($ilmiyd->delete())
        {

            return back()->with('danger',' O\'chirildi !!!');
        }
        else
        {

            return back()->with('danger',' Xatolik yuz berdi  !!!');
        }

    }

    public function warning($id)
    {
        $ilmiyd = Ilmiyishlar::find($id);
        $ilmiyd->status = 3;

        if ($ilmiyd->save())
        {

            return back()->with('status',' Shubxali deb belgilanfi !!!');
        }
        else
        {

            return back()->with('danger',' Xatolik yuz berdi  !!!');
        }
    }
}
