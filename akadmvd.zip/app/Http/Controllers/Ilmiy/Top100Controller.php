<?php

namespace App\Http\Controllers\Ilmiy;

use App\Http\Controllers\Controller;
use App\Models\User\Elektronplatforma;
use App\Models\User\Top100;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Top100Controller extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $top100 = DB::table('top100s')
            ->where('status','=','1')
            ->get();
        return view('ilmiy.ilmiytadqiqot.top100.index',compact('top100'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $top100 = DB::table('top100s')->where('id',$id)->first();
        return view('ilmiy.ilmiytadqiqot.top100.create',compact('top100'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',


        ]))
        {
            //dd($request->taboq);
            $kazus = Top100::find($id);
            //$taboq = $request->taboq;

            if ($kazus->update([
                'ball'=>$request->ball,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ilmiyd = Top100::find($id);

        if ($ilmiyd->delete())
        {

            return back()->with('danger',' O\'chirildi !!!');
        }
        else
        {

            return back()->with('danger',' Xatolik yuz berdi  !!!');
        }

    }
}
