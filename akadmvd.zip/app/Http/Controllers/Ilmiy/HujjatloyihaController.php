<?php

namespace App\Http\Controllers\Ilmiy;

use App\Http\Controllers\Controller;
use App\Models\User\Hujjatloyiha;
use App\Models\User\Tadqiqotnatija;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HujjatloyihaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hujjatloyiha = DB::table('hujjatloyihas')
            //->where('user_id','=', Auth::user()->getAuthIdentifier())
            ->where('status','=','1')
            ->get();
        return view('ilmiy.ilmiytadqiqot.hujjatloyiha.index',compact('hujjatloyiha'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hujjatloyiha= DB::table('hujjatloyihas')->where('id',$id)->first();
        return view('ilmiy.ilmiytadqiqot.hujjatloyiha.create',compact('hujjatloyiha'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
            'turi_id' => 'required',
            'turi_name' => 'required',
        ]))
        {
            //dd($request->taboq);
            $kazus = Hujjatloyiha::find($id);
            //$taboq = $request->taboq;

            if ($kazus->update([
                'ball'=>$request->ball,
                'turi_id'=>$request->turi_id,
                'turi_name'=>$request->turi_name,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ilmiyd = Hujjatloyiha::find($id);

        if ($ilmiyd->delete())
        {

            return back()->with('danger',' O\'chirildi !!!');
        }
        else
        {

            return back()->with('danger',' Xatolik yuz berdi  !!!');
        }

    }
}
