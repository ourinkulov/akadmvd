<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TeacherAllResultController extends Controller
{
    public function getAllInOne($id){
        $user = DB::table('users')->select('name','image')->where('id','=',$id)->first();

        $attestat  = DB::table('atestats')->where('user_id','=', $id)->get();
        $controlgroup= DB::table('controlgroups')->where('user_id','=', $id)->get();
        $darslik = DB::table('darsliks')->where('user_id','=', $id)->get();
        $davlatatestats = DB::table('davlatatestats')->where('user_id','=', $id)->get();
        $dissertathimoyas = DB::table('dissertathimoyas')->where('user_id','=', $id)->get();
        $elektronplatformas = DB::table('elektronplatformas')->where('user_id','=', $id)->get();
        $fanteaches = DB::table('fanteaches')->where('user_id','=', $id)->get();
        $grands = DB::table('grands')->where('user_id','=', $id)->get();
        $horijiykengashes = DB::table('horijiykengashes')->where('user_id','=', $id)->get();
        $hududmetodiks = DB::table('hududmetodiks')->where('user_id','=', $id)->get();
        $hujjatloyihas = DB::table('hujjatloyihas')->where('user_id','=', $id)->get();
        $ijros = DB::table('ijros')->where('user_id','=', $id)->get();
        $ilmiydarajas = DB::table('ilmiydarajas')->where('user_id','=', $id)->get();
        $ilmiyishlars = DB::table('ilmiyishlars')->where('user_id','=', $id)->get();
        $ilmiykengashes = DB::table('ilmiykengashes')->where('user_id','=', $id)->get();
        $ilmiymaktabs = DB::table('ilmiymaktabs')->where('user_id','=', $id)->get();
        $ilmiyseminars = DB::table('ilmiyseminars')->where('user_id','=', $id)->get();
        $ilmiyunvons = DB::table('ilmiyunvons')->where('user_id','=', $id)->get();
        $iqtibos = DB::table('iqtibos')->where('user_id','=', $id)->get();
        $jurnals = DB::table('jurnals')->where('user_id','=', $id)->get();
        $kasbiymaxorats= DB::table('kasbiymaxorats')->where('user_id','=', $id)->get();
        $kazus = DB::table('kazus')->where('user_id','=', $id)->get();
        $konferensiyas = DB::table('konferensiyas')->where('user_id','=', $id)->get();
        $kurators = DB::table('kurators')->where('user_id','=', $id)->get();
        $kursworks = DB::table('kursworks')->where('user_id','=', $id)->get();
        $majmuas = DB::table('majmuas')->where('user_id','=', $id)->get();
        $malakaoshirishes = DB::table('malakaoshirishes')->where('user_id','=', $id)->get();
        $maruzafonds = DB::table('maruzafonds')->where('user_id','=', $id)->get();
        $masterclas = DB::table('masterclas')->where('user_id','=', $id)->get();
        $masters = DB::table('masters')->where('user_id','=', $id)->get();
        $metodikmats = DB::table('metodikmats')->where('user_id','=', $id)->get();
        $monografiyas = DB::table('monografiyas')->where('user_id','=', $id)->get();
        $pednazorats = DB::table('pednazorats')->where('user_id','=', $id)->get();
        $qaytatopshirishes = DB::table('qaytatopshirishes')->where('user_id','=', $id)->get();
        $raxbarliks = DB::table('raxbarliks')->where('user_id','=', $id)->get();
        $setpednazorats = DB::table('setpednazorats')->where('user_id','=', $id)->get();
        $sotengins = DB::table('sotengins')->where('user_id','=', $id)->get();
        $sustuzlashtirgans = DB::table('sustuzlashtirgans')->where('user_id','=', $id)->get();
        $tadbirs = DB::table('tadbirs')->where('user_id','=', $id)->get();
        $tadqiqotnatijas = DB::table('tadqiqotnatijas')->where('user_id','=', $id)->get();
        $taqrizs = DB::table('taqrizs')->where('user_id','=', $id)->get();
        $tils = DB::table('tils')->where('user_id','=', $id)->get();
        $top100s= DB::table('top100s')->where('user_id','=', $id)->get();
        $ttgs = DB::table('ttgs')->where('user_id','=', $id)->get();
        $tugaraks= DB::table('tugaraks')->where('user_id','=', $id)->get();
        $uchrashuvs = DB::table('uchrashuvs')->where('user_id','=', $id)->get();
        $uquvmashgulots = DB::table('uquvmashgulots')->where('user_id','=', $id)->get();
        $uquvmaxsulots = DB::table('uquvmaxsulots')->where('user_id','=', $id)->get();
        $uquvrejas = DB::table('uquvrejas')->where('user_id','=', $id)->get();
        $workgroups = DB::table('workgroups')->where('user_id','=', $id)->get();
        $xizmattekshiruvs = DB::table('xizmattekshiruvs')->where('user_id','=', $id)->get();

        return view('admin.userallresults.userresults', compact(['user',$user],['attestat',$attestat ]));

    }
}
