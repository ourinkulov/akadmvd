<?php

namespace App\Http\Controllers;

use App\Models\Fan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    const uy_id = 5;
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function login()
    {
//        $subquery= DB::table('yuklamalar as d')
//            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
//            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
//            ->select(
//                'd.user_id',
//                //DB::raw('SUM(d.ball) as ball'),
//                DB::raw('SUM(CASE
//                        WHEN t.category_id >= 5 THEN  d.ball
//                        ELSE 0
//                    END) as jball'))
//            ->where('lavozim_id','=',1)
//            ->orWhere('lavozim_id','=',2)
//            ->orWhere('lavozim_id','=',3)
//            ->orWhere('lavozim_id','=',4)
//            ->orWhere('lavozim_id','=',5)
//            ->orWhere('lavozim_id','=',6)
//            ->where('d.kriteriya_id','>=',57)
//            ->groupBy('d.user_id')
//            ->orderByDesc('jball')
//            //->limit(10)
//            ->get();
        //dd($subqueryJball);
        // Subquery to calculate jball
        $subqueryJball = DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'u.id',
                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN d.ball ELSE 0 END) as jball')
            )
            ->whereIn('u.lavozim_id', [1, 2, 3, 4, 5, 6])
            //->where('d.kriteriya_id', '>=', 57)
            ->groupBy('u.id');
        //dd($subqueryJball);

//        $allrating = DB::table('yuklamalar as d')
//            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
//            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
//            ->select(
//                'd.user_id',
//                DB::raw('SUM(d.ball-jballtable.jball) as ball'),
//
////                DB::raw('SUM(CASE
////                        WHEN t.category_id >= 5 THEN  d.ball-jballtable.jball
////                        ELSE 0
////                    END) as jball'),
////                DB::raw('SUM(CASE
////                        WHEN t.category_id < 5 THEN  d.ball
////                        ELSE 0
////                    END) as ball'),
//                'u.image',
//                'u.name',
//                'u.kaf_name',
//                'u.lavozim'
//            )
//            ->leftJoinSub($subqueryJball, 'jballtable',function ($join) {
//                $join->on('jballtable.user_id', '=', 'd.user_id');
//            })
//            ->where('lavozim_id','=',1)
//            ->orWhere('lavozim_id','=',2)
//            ->orWhere('lavozim_id','=',3)
//            ->orWhere('lavozim_id','=',4)
//            ->orWhere('lavozim_id','=',5)
//            ->orWhere('lavozim_id','=',6)
//            //->where('d.kriteriya_id','<',57)
//            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
//            ->orderByRaw('ball-jball DESC')
//            ->limit(10)
//            ->get();
        $allrating = DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'd.user_id',
                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as ball'),
                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as jball'),
                DB::raw('SUM(CASE WHEN d.kriteriya_id < 57 THEN IFNULL(d.ball, 0) ELSE 0 END) - SUM(CASE WHEN d.kriteriya_id >= 57 THEN IFNULL(d.ball, 0) ELSE 0 END) as allball'),
                'u.image',
                'u.name',
                'u.kaf_name',
                'u.lavozim'
            )
            ->where('d.uy_id','=', self::uy_id)
            ->whereIn('u.lavozim_id', [1, 2, 3, 4, 5, 6])
            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
            ->orderBy('allball','DESC')
            ->limit(10)
            ->get();
        //dd($allrating);

        $usr = DB::table('yuklamalar')
            ->select(
                'yuklamalar.user_id',
                'users.name',
                'users.image',
                'users.lavozim',
                'users.kaf_name',
                DB::raw('SUM(yuklamalar.ball) as ball')
//                DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
            )
            ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
            ->where('yuklamalar.uy_id','=', self::uy_id)
            ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                $query->select('id')
                    ->from('kriteriyas')
                    ->where('kriteriyas.category_id', 1);
            })
            ->where('lavozim_id','=',1)
            ->orWhere('lavozim_id','=',2)
            ->orWhere('lavozim_id','=',3)
            ->orWhere('lavozim_id','=',4)
            ->orWhere('lavozim_id','=',5)
            ->orWhere('lavozim_id','=',6)
            ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
            ->orderByDesc('ball')
            ->limit(10)
            ->get();

        $uyr = DB::table('yuklamalar')
            ->select(
                'yuklamalar.user_id',
                'users.name',
                'users.image',
                'users.lavozim',
                'users.kaf_name',
                DB::raw('SUM(yuklamalar.ball) as ball')
//                DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
            )
            ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
            ->where('yuklamalar.uy_id','=', self::uy_id)
            ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                $query->select('id')
                    ->from('kriteriyas')
                    ->where('kriteriyas.category_id', 2);
            })
            ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
            ->orderByDesc('ball')
            ->limit(10)
            ->get();;

        $iir = DB::table('yuklamalar')
            ->select(
                'yuklamalar.user_id',
                'users.name',
                'users.image',
                'users.lavozim',
                'users.kaf_name',
                DB::raw('SUM(yuklamalar.ball) as ball')
//                DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
            )
            ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
            ->where('yuklamalar.uy_id','=', self::uy_id)
            ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                $query->select('id')
                    ->from('kriteriyas')
                    ->where('kriteriyas.category_id', 3);
            })
            ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
            ->orderByDesc('ball')
            ->limit(10)
            ->get();

        $jir = DB::table('yuklamalar')
            ->select(
                'yuklamalar.user_id',
                'users.name',
                'users.image',
                'users.lavozim',
                'users.kaf_name',
                DB::raw('SUM(yuklamalar.ball) as ball')
//                DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
            )
            ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
            ->where('yuklamalar.uy_id','=', self::uy_id)
            ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                $query->select('id')
                    ->from('kriteriyas')
                    ->where('kriteriyas.category_id', 4);
            })
            ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
            ->orderByDesc('ball')
            ->limit(10)
            ->get();

//        $kafs =
//
//            DB::table('users')
//            ->leftJoin('yuklamalar as d', 'users.id', '=', 'd.user_id')
//            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
////133 qatordagi SUMM funksiya ichiga yoziladi % xisoblanganda
////            CASE
////                        WHEN t.category_id = 1 THEN 0.30 * d.ball
////                        WHEN t.category_id = 2 THEN 0.15 * d.ball
////                        WHEN t.category_id = 3 THEN 0.45 * d.ball
////                        WHEN t.category_id = 4 THEN 0.10 * d.ball
////                        ELSE 0
////            END
//            ->select(
//                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END) AS ball'),
//                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END)/ COUNT(DISTINCT users.id) AS jball'),
//                DB::raw('(SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END)) - (SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END)) as allball'),
//                DB::raw('COUNT(DISTINCT users.id) AS user_count'),
//                'users.kaf_name','users.kaf_id')
//            ->where('d.uy_id','=', self::uy_id)
////                DB::raw('
////                SUM(
////                    d.ball
////                ) / COUNT(DISTINCT users.id) AS ball,
////                COUNT(DISTINCT users.id) AS user_count,
////                users.kaf_name
////            '))
//            ->groupBy('users.kaf_name')
//            //->orderByDesc('ball')
//            ->get();
        // Kafedra uqituvchilari soni
        $subQueryCount = DB::table('users as u2')
            ->select(DB::raw('COUNT(id)'))
            ->whereColumn('u2.kaf_id', 'u.kaf_id');

// Kafedra reytingi
        $kafs = DB::table('users as u')
            ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
            ->leftJoin('kriteriyas as t', 't.id', '=', 'y.kriteriya_id')
            ->select(
        //         DB::raw('(
        //     SELECT COUNT(id)
        //     FROM users as u2
        //     WHERE u2.kaf_id = u.kaf_id
        // ) AS user_count')
        DB::raw('(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) AS user_count'),
                'u.kaf_name',
                DB::raw('(
            SUM(y.ball) /
            (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)
        ) AS aball'),
                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END) AS ball'),
                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)/ (
                SELECT COUNT(id)
                FROM users as u2
                WHERE u2.kaf_id = u.kaf_id
            ) AS jball'),
            //     DB::raw('
            //     (
            //     (SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END))
            //     -
            //     (SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END))
            //     )
            //     /
            //     (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)

            //    as allball')
            DB::raw('
    (
        SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END) -
        SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)
    ) /
    (
        (
            SELECT COUNT(id)
            FROM users AS u2
            WHERE u2.kaf_id = u.kaf_id
              AND u2.role = 3
              AND u2.stavka_id = 1
        ) +
        (
            SELECT COUNT(id)
            FROM users AS u2
            WHERE u2.kaf_id = u.kaf_id
              AND u2.role = 3
              AND u2.stavka_id = 2
        ) / 2
    ) AS allball
')
,
                DB::raw('(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) as user_count')

            )
            ->where('u.role', '<', 7)
            ->where('y.uy_id', '=', self::uy_id)
            ->whereNotNull('u.kaf_id')
            ->where('u.kaf_id', '<>', 0)
            ->where('u.kaf_id', '<>', 100)
            ->where('u.kaf_id', '<>', 275)
            ->where('u.kaf_id', '<>', 19)
            ->groupBy('u.kaf_id', 'u.kaf_name')
            ->orderBy('allball', 'desc')
            ->get();
       // dd($kafs);



        $kafUsersCount = DB::table('users')->select('kaf_id', DB::raw('COUNT(DISTINCT id) AS user_count'))->where('kaf_id','<', 900)
            ->whereNotIn('kaf_id',[100,275,19,0])
            ->groupBy('kaf_name')->get();
        //dd($kafUsersCount);

        $iunvonDotsent = DB::table('users as u')
            ->leftJoin('ilmiyunvons as i', 'u.id', '=', 'i.user_id')
            ->where('i.turi_id','=',1)
            ->count();
        $iunvonProfessor= DB::table('users as u')
            ->leftJoin('ilmiyunvons as i', 'u.id', '=', 'i.user_id')
            ->where('i.turi_id','=',2)
            ->count();

        $idarajaPHD = DB::table('users as u')
            ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
            ->where('i.turi_id','=',1)
            ->count();
        $idarajaDSC = DB::table('users as u')
            ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
            ->where('i.turi_id','=',2)
            ->count();


        $idarajaByYear = DB::table('v_ds_ilmiydaraja_by_year')
            ->get();
        $allTeachersCount = DB::table('users')
            ->where('lavozim_id','=',1)
            ->orWhere('lavozim_id','=',2)
            ->orWhere('lavozim_id','=',3)
            ->orWhere('lavozim_id','=',4)
            ->orWhere('lavozim_id','=',5)
            ->orWhere('lavozim_id','=',6)
            ->count();
        $passiveTeachs = DB::table('users as u')
            ->select(
                'u.id',
                'u.name',
                'u.image',
                'u.lavozim',
                'u.kaf_name',
            )
            ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
            ->whereNull('y.id')
            ->where('u.role', '=', 3)
            ->where('u.lavozim_id','<',9)
            //->limit(2)
            ->get();
        //dd($idaraja);

        return view('dashboards.admin',compact('passiveTeachs','kafUsersCount','usr','uyr','jir','iir','allrating','kafs','allTeachersCount','idarajaDSC','idarajaByYear','idarajaPHD','iunvonProfessor','iunvonDotsent'));
    }
    public function getallreyting()
    {
//        $allr= DB::table('yuklamalar as d')
//            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
//            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
//            ->select(
//                'd.user_id',
//                DB::raw('SUM(d.ball) as ball'),
////                DB::raw('SUM(CASE
////                        WHEN t.category_id = 1 THEN 0.30 * d.ball
////                        WHEN t.category_id = 2 THEN 0.15 * d.ball
////                        WHEN t.category_id = 3 THEN 0.45 * d.ball
////                        WHEN t.category_id = 4 THEN 0.10 * d.ball
////                        ELSE 0
////                    END) as ball'),
//                'u.image',
//                'u.name',
//                'u.kaf_name',
//                'u.lavozim'
//            )
//            ->where('lavozim_id','=',1)
//            ->orWhere('lavozim_id','=',2)
//            ->orWhere('lavozim_id','=',3)
//            ->orWhere('lavozim_id','=',4)
//            ->orWhere('lavozim_id','=',5)
//            ->orWhere('lavozim_id','=',6)
//            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
//            ->orderByDesc('ball')
//            ->get();
        $user_count = User::query()->whereIn('lavozim_id', [1, 2, 3, 4, 5, 6])->count();
        $allr= DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'd.user_id',
                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as ball'),
                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as jball'),
                DB::raw('SUM(CASE WHEN d.kriteriya_id < 57 THEN IFNULL(d.ball, 0) ELSE 0 END) - SUM(CASE WHEN d.kriteriya_id >= 57 THEN IFNULL(d.ball, 0) ELSE 0 END) as allball'),
                'u.image',
                'u.name',
                'u.kaf_name',
                'u.lavozim'
            )
            ->where('d.uy_id','=', self::uy_id)
            ->where('stavka_id','=',1)
            ->whereIn('u.lavozim_id', [1, 2, 3, 4, 5, 6])
            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
            ->orderBy('allball','DESC')

            ->get();
        return view('admin.allreyting',compact('allr','user_count'));
    }

    public function adminuserprofile($id)
    {
        $uid = $id;
        $user = DB::table('v_users')->where('id',$uid)->first();
        $rey1 = null;
        $name1 = null;

        $rey = DB::select("CALL getIlmiy(?,?,?)",array($uid,$rey1,$name1));
//        echo "<pre>";
//        print_r($rey);
        return view('admin.user',compact('rey','user'));
    }

    public function showuser($id)
    {
        $uid = $id;
        $user = DB::table('v_users')->where('user_id',$uid)->first();
        $rey1 = null;
        $name1 = null;
        $rey = DB::select("CALL getIlmiy(".$uid.",@rey1,@name1)");
//        $rey = DB::select("CALL getIlmiy(?,?,?)",array($uid,$rey1,$name1));
//        echo "<pre>";
//        print_r($rey);
        return view('admin.user',compact('rey','user'));
    }

    public function usershasdsdaraja()
    {
        $ds = DB::table('users as u')->leftJoin('ilmiydarajas as d', 'd.user_id', '=', 'u.id')
            ->select('u.id','u.name','u.lavozim','u.kaf_name','d.turi_name','d.file','d.sana','u.image')
            ->where('d.turi_id','=',2)
            ->orderBy('d.sana')
            ->get();
        return view('admin.usershasdsdaraja',compact('ds'));
    }
    public function usershasphddaraja()
    {
        $phd = DB::table('users as u')->leftJoin('ilmiydarajas as d', 'd.user_id', '=', 'u.id')
            ->select('u.id','u.name','u.lavozim','u.kaf_name','d.turi_name','d.file','d.sana','u.image')
            ->where('d.turi_id','=',1)
            ->orderBy('d.sana')
            ->get();
        return view('admin.usershasphddaraja',compact('phd'));
    }

    public function usershasdotsent()
    {
        $phd = DB::table('users as u')->leftJoin('ilmiyunvons as d', 'd.user_id', '=', 'u.id')
            ->select('u.id','u.name','u.lavozim','u.kaf_name','d.turi_name','d.file','d.sana','u.image')
            ->where('d.turi_id','=',1)
            ->orderBy('d.sana')
            ->get();
        return view('admin.usershasphddaraja',compact('phd'));
    }

    public function usershasprofessor()
    {
        $ds = DB::table('users as u')->leftJoin('ilmiyunvons as d', 'd.user_id', '=', 'u.id')
            ->select('u.id','u.name','u.lavozim','u.kaf_name','d.turi_name','d.file','d.sana','u.image')
            ->where('d.turi_id','=',2)
            ->orderBy('d.sana')
            ->get();
        return view('admin.usershasdsdaraja',compact('ds'));
    }

    public function getTeacherReportIndex(){
        return view('admin.getteacherreport');
    }

    public function getTeacherReport(Request $request){
        //dd($request->all());
        $fdate = $request->fdate;
        $ldate = $request->ldate;
        $results = DB::table('yuklamalar as y')
            ->leftJoin('kriteriyas as k', 'y.kriteriya_id', '=', 'k.id')
            ->whereBetween('y.created_at', [$fdate, $ldate])
            ->select('k.id','k.band', DB::raw('count(y.id) as count'))
            ->groupBy('k.band')
            ->orderByDesc('count')
            ->get();
        //dd($results);
        return view('admin.getteacherreport',compact('results','fdate','ldate'));

    }


}
