<?php

namespace App\Http\Controllers;

use App\Models\Kriteriya;
use App\Models\Ug;
use App\Models\User;
use App\Models\Yuklamalar;
use Dflydev\DotAccessData\Data;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Fan;

class UserController extends Controller
{
    const uy_id = 5;
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {

        $view = 'dashboards.user';
        $data = [];
        switch (Auth::user()->role){
            case 1:
            case 2:

                $result = DB::table('yuklamalar as d')
                    ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
                    ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
                    ->select(
                        'd.user_id',
                        DB::raw('SUM(d.ball) as ball'),
// %SIZ XISOBLASH         DB::raw('SUM(CASE
//                        WHEN t.category_id = 1 THEN 0.30 * d.ball
//                        WHEN t.category_id = 2 THEN 0.15 * d.ball
//                        WHEN t.category_id = 3 THEN 0.45 * d.ball
//                        WHEN t.category_id = 4 THEN 0.10 * d.ball
//                        ELSE 0
//                    END) as ball'),
                        'u.image',
                        'u.name',
                        'u.kaf_name',
                        'u.lavozim'
                    )
                    ->where('uy_id','=', self::uy_id)
                    ->where('u.stavka_id','=',1)
                    ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
                    ->orderByDesc('ball')
                    ->limit(10)
                    ->get();
            $allrating = DB::table('yuklamalar as d')
                ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
                ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
                ->select(
                    'd.user_id',
                    DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as ball'),
                    DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as jball'),
                    DB::raw('SUM(CASE WHEN d.kriteriya_id < 57 THEN IFNULL(d.ball, 0) ELSE 0 END) - SUM(CASE WHEN d.kriteriya_id >= 57 THEN IFNULL(d.ball, 0) ELSE 0 END) as allball'),
                    'u.image',
                    'u.name',
                    'u.kaf_name',
                    'u.lavozim'
                )
                ->where('uy_id','=', self::uy_id)
                ->whereIn('u.lavozim_id', [1, 2, 3, 4, 5, 6])
                ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
                ->orderBy('allball','DESC')
                ->limit(10)
                ->get();
//                $allrating = DB::table('yuklamalar as d')
//                    ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
//                    ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
//                    ->select(
//                        'd.user_id',
//                        DB::raw('SUM(d.ball) as ball'),
////                        DB::raw('SUM(CASE
////                        WHEN t.category_id = 1 THEN 0.30 * d.ball
////                        WHEN t.category_id = 2 THEN 0.15 * d.ball
////                        WHEN t.category_id = 3 THEN 0.45 * d.ball
////                        WHEN t.category_id = 4 THEN 0.10 * d.ball
////                        ELSE 0
////                    END) as ball'),
//                        'u.image',
//                        'u.name',
//                        'u.kaf_name',
//                        'u.lavozim'
//                    )
//                    ->where('lavozim_id','=',1)
//                    ->orWhere('lavozim_id','=',2)
//                    ->orWhere('lavozim_id','=',3)
//                    ->orWhere('lavozim_id','=',4)
//                    ->orWhere('lavozim_id','=',5)
//                    ->orWhere('lavozim_id','=',6)
//                    ->where('d.kriteriya_id','<',57)
//                    ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
//                    ->orderByDesc('ball')
//                    ->limit(10)
//                    ->get();
                $usr = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->where('yuklamalar.uy_id','=', self::uy_id)
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 1);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
                    ->limit(10)
                    ->get();
                $uyr = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.15 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->where('yuklamalar.uy_id','=', self::uy_id)
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 2);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
                    ->limit(10)
                    ->get();;

                $iir = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.45 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->where('yuklamalar.uy_id','=', self::uy_id)
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 3);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
                    ->limit(10)
                    ->get();
            $passiveTeachs = DB::table('users as u')
            ->select(
                'u.id',
                'u.name',
                'u.image',
                'u.lavozim',
                'u.kaf_name',
            )
            ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
                ->where('y.uy_id','=', self::uy_id)
            ->whereNull('y.id')
            ->where('u.role', '=', 3)
                ->where('u.lavozim_id','<',9)
            ->limit(2)->get();
            //dd($passiveTeachs);

                $jir = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.10 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->where('yuklamalar.uy_id','=', self::uy_id)
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 4);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
                    ->limit(10)
                    ->get();
            //         $kafs = DB::table('users as u')
            // ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
            // ->leftJoin('kriteriyas as t', 't.id', '=', 'y.kriteriya_id')
            // ->select(
            //     DB::raw('(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) AS user_count'),
            //     'u.kaf_name',
            //     DB::raw('(
            // SUM(y.ball) / (
            //     SELECT COUNT(id)
            //     FROM users as u2
            //     WHERE u2.kaf_id = u.kaf_id
            //                 )
            //                 ) AS aball'),
            //     DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END) AS ball'),
            //     DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)/(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) AS jball'),
            //     DB::raw('(
            //     (
            //     SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END)
            //     /
            //     (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1) + ((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)
            //     )
            //     -
            //     (
            //     SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)
            //     /
            //     (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1) + ((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)
            //     )

            // ) as allball'),
            //     // DB::raw('(
            //     // SUM((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1))+
            //     // (SUM((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)) as user_count

            //     // )'),
            //     // DB::raw('(
            //     //     SUM(CASE
            //     //         WHEN u2.role = 3 AND u2.stavka_id = 1 AND u2.kaf_id = u.kaf_id THEN 1
            //     //         ELSE 0
            //     //     END) +
            //     //     SUM(CASE
            //     //         WHEN u2.role = 3 AND u2.stavka_id = 2 AND u2.kaf_id = u.kaf_id THEN 0.5
            //     //         ELSE 0
            //     //     END) AS user_count
            //     // )')
            // )
            // ->where('u.role', '<', 7)
            // ->where('y.uy_id', '=', self::uy_id)
            // ->whereNotNull('u.kaf_id')
            // ->where('u.kaf_id', '<>', 0)
            // ->where('u.kaf_id', '<>', 100)
            // ->where('u.kaf_id', '<>', 275)
            // ->where('u.kaf_id', '<>', 19)
            // ->groupBy('u.kaf_id', 'u.kaf_name')
            // ->orderBy('allball', 'desc')
            // ->get();
//             $kafs = DB::table('yuklamalar as d')
//                 ->rightJoin('users', 'users.id', '=', 'd.user_id')
//                 ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
// //133 qatordagi SUMM funksiya ichiga yoziladi % xisoblanganda
// //            CASE
// //                        WHEN t.category_id = 1 THEN 0.30 * d.ball
// //                        WHEN t.category_id = 2 THEN 0.15 * d.ball
// //                        WHEN t.category_id = 3 THEN 0.45 * d.ball
// //                        WHEN t.category_id = 4 THEN 0.10 * d.ball
// //                        ELSE 0
// //            END
//                 ->select(
//                     DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END)/ COUNT(DISTINCT users.id) AS ball'),
//                     DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END)/ COUNT(DISTINCT users.id) AS jball'),
//                     DB::raw('(SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END)/ COUNT(DISTINCT users.id)) - (SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END)/ COUNT(DISTINCT users.id)) as allball'),
//                     DB::raw('(SELECT COUNT(DISTINCT u2.id) FROM users as u2 where u2.kaf_id = users.kaf_id and u2.stavka_id=1) AS user_count'),
//                     DB::raw('(SELECT COUNT(u2.id) FROM users as u2 WHERE u2.kaf_id = users.kaf_id and u2.stavka_id=2) as half_stavka_user_count'),
//                     'users.kaf_name')
//                     ->where('d.uy_id','=', self::uy_id)
// //                DB::raw('
// //                SUM(
// //                    d.ball
// //                ) / COUNT(DISTINCT users.id) AS ball,
// //                COUNT(DISTINCT users.id) AS user_count,
// //                users.kaf_name
// //            '))
//                 ->groupBy('users.kaf_name')
//                 ->orderByDesc('ball')
//                 ->get();
                //dd($kafs);
                $kafs = DB::table('users as u')
            ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
            ->leftJoin('kriteriyas as t', 't.id', '=', 'y.kriteriya_id')
            ->select(
        //         DB::raw('(
        //     SELECT COUNT(id)
        //     FROM users as u2
        //     WHERE u2.kaf_id = u.kaf_id
        // ) AS user_count')
        DB::raw('(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) AS user_count'),
                'u.kaf_name',
                DB::raw('(
            SUM(y.ball) /
            (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)
        ) AS aball'),
                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END) AS ball'),
                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)/ (
                SELECT COUNT(id)
                FROM users as u2
                WHERE u2.kaf_id = u.kaf_id
            ) AS jball'),
            //     DB::raw('
            //     (
            //     (SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END))
            //     -
            //     (SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END))
            //     )
            //     /
            //     (SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2)

            //    as allball')
            DB::raw('
    (
        SUM(CASE WHEN t.category_id < 5 THEN IFNULL(y.ball, 0) ELSE 0 END) -
        SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(y.ball, 0) ELSE 0 END)
    ) /
    (
        (
            SELECT COUNT(id)
            FROM users AS u2
            WHERE u2.kaf_id = u.kaf_id
              AND u2.role = 3
              AND u2.stavka_id = 1
        ) +
        (
            SELECT COUNT(id)
            FROM users AS u2
            WHERE u2.kaf_id = u.kaf_id
              AND u2.role = 3
              AND u2.stavka_id = 2
        ) / 2
    ) AS allball
')
,
                DB::raw('(SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=1)+((SELECT COUNT(id) FROM users as u2 WHERE u2.kaf_id = u.kaf_id and u2.role=3 and u2.stavka_id=2)/2) as user_count')

            )
            ->where('u.role', '<', 7)
            ->where('y.uy_id', '=', self::uy_id)
            ->whereNotNull('u.kaf_id')
            ->where('u.kaf_id', '<>', 0)
            ->where('u.kaf_id', '<>', 100)
            ->where('u.kaf_id', '<>', 275)
            ->where('u.kaf_id', '<>', 19)
            ->groupBy('u.kaf_id', 'u.kaf_name')
            ->orderBy('allball', 'desc')
            ->get();
            //dd($kafs);

            $fakultets= DB::table('yuklamalar as d')
                ->leftJoin('users', 'users.id', '=', 'd.user_id')
                ->leftJoin('kafedras as k','users.kaf_id','=','k.id')
                ->leftJoin('fakultets as f', 'f.id', '=', 'k.fakultet_id')
                ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
                ->select(DB::raw('
                SUM(
                d.ball
                ) / COUNT(DISTINCT users.id) AS ball,
                COUNT(DISTINCT users.id) AS user_count,
                f.name
            '))
                ->groupBy('f.name')
                ->orderByDesc('ball')
                ->get();

            //dd($fakultets);
            $iunvonDotsent = DB::table('yuklamalar')
                ->where('kriteriya_id','=',17)
                ->where('tur_id','=',1)
                ->distinct()
                ->count();
//
            $iunvonProfessor=  DB::table('yuklamalar')
                ->where('kriteriya_id','=',17)
                ->where('tur_id','=',2)
                ->distinct()
                ->count();

            $idarajaPHD = DB::table('yuklamalar')
                ->where('kriteriya_id','=',16)
                ->where('tur_id','=',1)
                ->distinct()
                ->count();
            $idarajaDSC = DB::table('yuklamalar')
                ->where('kriteriya_id','=',16)
                ->where('tur_id','=',2)->count();

            $idarajaByYear = DB::table('v_ds_ilmiydaraja_by_year')
                ->get();
            $allTeachersCount = DB::table('users')
                ->where('lavozim_id','=',1)
                ->orWhere('lavozim_id','=',2)
                ->orWhere('lavozim_id','=',3)
                ->orWhere('lavozim_id','=',4)
                ->orWhere('lavozim_id','=',5)
                ->orWhere('lavozim_id','=',6)
                ->count();

                $view = 'dashboards.admin';
                $data = [
                    'allrating' => $allrating,
                    'usr' => $usr,
                    'uyr' => $uyr,
                    'jir' => $jir,
                    'iir' => $iir,
                    'kafs' => $kafs,
                    'passiveTeachs' => $passiveTeachs,
                    'result' => $result,
                    'idarajaByYear' => $idarajaByYear,
                    'idarajaDSC' => $idarajaDSC,
                    'idarajaPHD' => $idarajaPHD,
                    'iunvonProfessor' => $iunvonProfessor,
                    'iunvonDotsent' => $iunvonDotsent,
                    'allTeachersCount' => $allTeachersCount,
                ];
                break;
                //Teacher
            case 3:

                $users = Yuklamalar::select('user_id', \DB::raw('SUM(ball) as total_ball'))
                    ->where('uy_id','=', self::uy_id)
                    ->groupBy('user_id')
                    ->orderByDesc('total_ball')
                    ->get();
                $specialUser = $users->firstWhere('user_id', Auth::user()->id);
                try {
                    $rank = $users->search(function ($user) use ($specialUser) {
                            return $user->user_id === $specialUser->user_id;
                        }) + 1;
                } catch (\Exception $e) {
                    $rank = User::query()->count();
                }
                $data = [
                    'idara' => Yuklamalar::query()->where(['kriteriya_id' => 16])->where(['user_id' => Auth::user()->id])->first(),
//                    'idaraold' => User\Ilmiydaraja::query()->where(['user_id' => Auth::user()->id])->first(),
                    'yunvon' => Yuklamalar::query()->where(['kriteriya_id' => 17])->where(['user_id' => Auth::user()->id])->first(),
//                    'yunvonold' => User\Ilmiyunvon::query()->where(['user_id' => Auth::user()->id])->first(),
                    'user' => Auth::user(),
                    'rating' => $rank,
                    'chart' => [
                        $this->calculateResult(1),
                        $this->calculateResult(2),
                        $this->calculateResult(3),
                        $this->calculateResult(4),
                    ]
                ];
                //dd($data['idara']);
                //dd($data['yunvon']);
                break;
            case 4:
                $dscIds =  DB::table('yuklamalar')
                    ->select('user_id')
                    ->where('kriteriya_id','=',16)
                    ->where('tur_id','=',2)
                    ->distinct();
                $phdIds = DB::table('yuklamalar')
                    ->select('user_id')
                    ->where('kriteriya_id','=',16)
                    ->where('tur_id','=',1)
                    ->distinct();
                $dotsWithoutDegree = DB::table('yuklamalar')
                    ->select('user_id')
                    ->where('kriteriya_id','=',16)
                    ->whereNotIn('tur_id',[1,2])
                    //->orWhere('tur_id','=',2)
                    ->distinct();
                    //->get();
                //dd($phdIds);
                $data =
                    [
                        'res' => DB::table('yuklamalar as y')
                                ->select('u.kaf_id', 'u.kaf_name', 'k.id', 'k.band', DB::raw('count(y.id) as soni'))
                                ->leftJoin('users as u', 'y.user_id', '=', 'u.id')
                                ->leftJoin('kriteriyas as k', 'y.kriteriya_id', '=', 'k.id')
                                ->where('kaf_id', '=', Auth::user()->kaf_id)
                                 ->where('y.uy_id','=', self::uy_id)
                                ->groupBy('u.kaf_id', 'k.id', 'u.kaf_name', 'k.band')
                                ->orderBy('k.id')
                                ->get(),
                        'teacherCount'=>User::query()->where('kaf_id','=',Auth::user()->kaf_id)->where('role','=',3)->count(),
                        'teacherCountAll'=>User::query()->where('role','=',3)->count(),
                        'dsc'=> DB::table('yuklamalar')
                            ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
                            ->where('kriteriya_id','=',16)
                            ->where('tur_id','=',2)
                            //->whereNotIn('user_id',$phdIds)
                            ->distinct()
                            ->count(),
                        'phd'=> DB::table('yuklamalar')
                            ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
                            ->where('kriteriya_id','=',16)
                            ->where('tur_id','=',1)
                            ->whereNotIn('user_id',$dscIds)
                            ->distinct()
                            ->count(),
                        'dotsWithoutDegree'=> DB::table('yuklamalar as y')
                            ->leftJoin('users as u', 'y.user_id', '=', 'u.id')
                        ->select('y.user_id')
                        ->where('y.kriteriya_id','=',17)
                        ->where('y.tur_id','=',1)
                        ->where('u.kaf_id','=', Auth::user()->kaf_id)
                        ->whereNotIn('y.user_id',$phdIds)
                        ->whereNotIn('y.user_id',$dscIds)
                        ->count(),


//                            User::selectRaw('count(u.id) as soni')
//                            ->from('users as u')
//                            ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
//                            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
//                            ->where('i.turi_id', '=', 1)
//                            ->where('u.role', '=', 3)
//                            ->whereNotIn('u.id', $subquery)
//                            ->first(),
                        'dotsent' =>  Yuklamalar::selectRaw('count(id) as soni')
                            ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
                            ->where('kriteriya_id','=',17)
                            ->where('tur_id','=',1)
                            ->distinct()
                            ->first(),



//                            User::selectRaw('count(u.id) as soni')
//                            ->from('users as u')
//                            ->leftJoin('ilmiyunvons as i', 'u.id', '=', 'i.user_id')
//                            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
//                            ->where('i.turi_id', '=', 1)
//                            ->where('u.role', '=', 3)
//                            ->whereNotIn('u.id', $subquery2)
//                            ->first(),
                'professor'=> Yuklamalar::selectRaw('count(id) as soni')
                    ->whereIn('user_id',(DB::table('users')->select('id')->where('kaf_id','=', Auth::user()->kaf_id)))
                    ->where('kriteriya_id','=',17)
                    ->where('tur_id','=',2)
                    ->distinct()
                    ->first(),


//                    User::selectRaw('count(u.id) as soni')
//                    ->from('users as u')
//                    ->leftJoin('ilmiyunvons as i', 'u.id', '=', 'i.user_id')
//                    ->where('u.kaf_id', '=', Auth::user()->kaf_id)
//                    ->where('i.turi_id', '=', 2)
//                    ->where('u.role', '=', 3)
//                    ->first(),
                    'idisnot'=> DB::table('users as u')
                            ->select('u.id')
                            ->leftJoin('ilmiydarajas as i', 'u.id', '=', 'i.user_id')
                            ->where('i.turi_id', '=', NULL)
                            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
                            ->where('u.role', '=', 3)
                            //->groupBy('u.id')
                            ->count()                        ,
                    'passiveTeachs'=> DB::table('users as u')
                            ->select('u.id', 'u.name', 'u.lavozim', 'u.image')
                            ->leftJoin('yuklamalar as y', 'u.id', '=', 'y.user_id')
                            ->whereNull('y.id')
                            ->where('u.kaf_id', '=', Auth::user()->kaf_id)
                            ->where('u.role', '=', 3)
                            ->get()
//                            DB::table('v_teacher_all_results')
//                            ->where('kaf_id','=',Auth::user()->kaf_id)
//                            ->get(),
                    ];
                $view = 'dashboards.nachkaf';
                break;
        }
        $user = User::query()->where('kaf_id','=', Auth::user()->kaf_id)->get();
        //dd($data);
        return view($view, $data,compact('user'));
    }
    public function login2($id)
    {
        $uid = $id;
        $user = DB::table('v_users')->select('user_id','name','lavozim_id','lavozim','kaf_id','shtat','kaf_name','image','born','malumoti','malumoti_id','mutaxassislik','iio','ait','pit')->where('user_id',$uid)->first();
        $rey1 = null;
        $name1 = null;
        $oldidaraja = DB::selectOne('SELECT id,turi_id, turi_name, file FROM `old_ilmiydarajas` WHERE user_id='.$uid.' and sana=(select max(sana) FROM old_ilmiydarajas WHERE user_id='.$uid.' limit 1);');
        $idaraja = DB::selectOne('SELECT id,turi_id, turi_name, file FROM `ilmiydarajas` WHERE user_id='.$uid.' and sana=(select max(sana) FROM ilmiydarajas WHERE user_id='.$uid.' limit 1);');

        $oldilmiyunvon = DB::selectOne('SELECT id, turi_id, turi_name, file FROM `old_ilmiyunvons` WHERE user_id='.$uid.' and sana=(select max(sana) FROM old_ilmiyunvons WHERE user_id='.$uid.' limit 1);');
        $ilmiyunvon = DB::selectOne('SELECT id, turi_id, turi_name, file FROM `ilmiyunvons` WHERE user_id='.$uid.' and sana=(select max(sana) FROM ilmiyunvons WHERE user_id='.$uid.' limit 1);');


        //dd($ilmiyunvon);
        //$rey = DB::select('CALL getIlmiy(?,?,?)',array($uid,$rey1,$name1));
        $rey = DB::select("CALL getIlmiy(".$uid.",@rey1,@name1)");
        //dd($rey);
//        echo "<pre>";
//        print_r($rey);
        return view('dashboards.user',compact('rey','user','oldidaraja','idaraja','oldilmiyunvon','ilmiyunvon'));
    }
    public function reyting()
    {
        $allr= DB::table('v_all_reyting')
            //->select('id','name','kaf_id','image','ball')
            ->get();
        return view('users.reyting',compact('allr'));
    }

    public function profile(Request $request, $id)
    {
        $validData = $request->validate(
            [

                'image' => ['required',],
                'lavozim_id'=> ['required',],
                'lavozim'=> ['required', 'string', 'max:255'],
                'born'=>['required',],
                'malumoti_id'=>['required',],
                'malumoti'=>['required',],
                'mutaxassislik'=>['required',],
                'iio'=>['required',],
                'ait'=>['required',],
                'pid'=>['required',],
                'pnfl'=>['required',],
            ]
        );
        if ($validData) {
            // dd($request);
            if ($request->hasFile('image')) {
                $name = $request->file('image')->getClientOriginalName();

                $fileFullname = time() . $name;

                if (
                    $user = \App\Models\User::create([
                        'name' => $validData['name'],
                        'lavozim_id' => $validData['lavozim_id'],
                        'lavozim' => $validData['lavozim'],
//                        'name' => $validData['name'],
                        'email' => $validData['email'],
                        'password' => Hash::make($validData['password']),
                        'image' => $fileFullname,
                        'role' => 3,
                        'born' => $validData['born'],
                        'malumoti_id' => $validData['malumoti_id'],
                        'malumoti' => $validData['malumoti'],
                        'mutaxassislik' => $validData['mutaxassislik'],
                        'iio' => $validData['iio'],
                        'ait' => $validData['ait'],
                        'pit' => $validData['pid'],
                        'pnfl' => $validData['pnfl'],
                        'kaf_id' => Auth::user()->kaf_id,
                        'kaf_name' => Auth::user()->kaf_name,
                    ])
                ) {
                    $path = $request->file('image')->storeAs('public/userimage', time() . $name);
                    return back()->with('status', ' Yaratildi !!!');
                } else {

                    return back()->with('danger', ' Xatolik yuz berdi  !!!');
                }
            }
            else {
                return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
            }
        }
        else {
            return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
        }
    }

    public function changeimage(Request $request,$id)
    {
        //dd($request);
        if ($request->validate(['image'=>'required']))
        {
            $user = \App\Models\User::find($id);
            $name = $request->file('image')->getClientOriginalName();
            $path = $request->file('image')->storeAs('public/userimage',time().$name);
            $fileFullname = time().$name;
            $user->image = $fileFullname;
            if ($user->save())
            {
                return back()->with('status','Profil sur\'ati qabul qlindi. !!!');
            }
            else
            {

                return back()->with('danger','Xatolik yuz berdi  !!!');
            }
        } else {
            return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
        }
    }

    public function changeimagepage()
    {
        return view('users.profileimage');
    }

    public function settings($id)
    {

        $data = User::find($id);
        //dd($data);
        return view('users.settings.create',compact('data'));
    }

    public function update(Request $request, $id){
        //dd($request);
        $validData = $request->validate(
            [
                'name' => ['required', 'string', 'max:255'],
                'lavozim_id'=> ['required',],
                'lavozim'=> ['required', 'string', 'max:255'],
                'born'=>['required',],
                'malumoti_id'=>['required',],
                'malumoti'=>['required',],
                'mutaxassislik'=>['required',],
                'iio'=>['required',],
                'ait'=>['required',],
                'pit'=>['required',],
                'pnfl'=>['required','min:12'],
            ]
        );
        if ($validData) {
                    $user = User::find($id);
                    $user->name = $request->name;
                    $user->pit = $request->pit;
                    $user->ait = $request->ait;
                    $user->iio = $request->iio;
                    $user->mutaxassislik = $request->mutaxassislik;
                    $user->malumoti = $request->malumoti;
                    $user->malumoti_id = $request->malumoti_id;
                    $user->born = $request->born;
                    $user->passport_pin = $request->pnfl;
                    $user->lavozim = $request->lavozim;
                    $user->lavozim_id = $request->lavozim_id;
                    if ($user->save())
                    {
                        return back()->with('status', 'Muvaffaqiyatli');
                    }
                    else{
                        return back()->with('danger', 'Muvaffaqiyatsiz');
                    }
            }
            else {
                return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
            }


    }

    function calculateResult($category_id) {
        $maxBall = match($category_id){
            1 => 300,
            2 => 150,
            3 => 450,
            4 => 100
        };
        $percent = match($category_id){
            1 => 0.30,
            2 => 0.15,
            3 => 0.45,
            4 => 0.10
        };
        $allSt = Kriteriya::where('category_id', $category_id)->sum('max_ball');

        $kriteriyaIds = Kriteriya::where('category_id', $category_id)->pluck('id');

        $balls = Yuklamalar::whereIn('kriteriya_id', $kriteriyaIds)->where('user_id', Auth::user()->id)->where('uy_id','=', self::uy_id)->sum('ball') ;

        return $balls != 0 ? $balls / $maxBall  * 1  : 0;
    }
    function calculateResultforUser($category_id, $user_id) {
        $maxBall = match($category_id){
            1 => 300,
            2 => 150,
            3 => 450,
            4 => 100
        };
        $percent = match($category_id){
            1 => 0.30,
            2 => 0.15,
            3 => 0.45,
            4 => 0.10
        };
        $allSt = Kriteriya::where('category_id', $category_id)->sum('max_ball');

        $kriteriyaIds = Kriteriya::where('category_id', $category_id)->pluck('id');

        $balls = Yuklamalar::whereIn('kriteriya_id', $kriteriyaIds)->where('user_id', $user_id)->where('uy_id','=', self::uy_id)->sum('ball') ;

        return $balls != 0 ? $balls / $maxBall  * 1  : 0;
    }
    public function getOneUserResult($id)
    {
        $data = [
            'chart' => [
                $this->calculateResultforUser(1,$id),
                $this->calculateResultforUser(2,$id),
                $this->calculateResultforUser(3,$id),
                $this->calculateResultforUser(4,$id),

            ]
        ];
        $idara = Yuklamalar::query()->where(['kriteriya_id' => 16])->where(['user_id' => $id])->first();
        $yunvon = Yuklamalar::query()->where(['kriteriya_id' => 17])->where(['user_id' => $id])->first();
        $user = User::find($id);
        $res = Yuklamalar::query()->where('user_id','=',$id)->where('uy_id','=', self::uy_id)->orderByDesc('ball')->get();

        return view('admin.userallresults.oneuser',$data,compact('res','user','idara','yunvon'))->with('i');
    }
    public function getOneUserResultforusers($id)
    {
       $data = [
           'chart' => [
               $this->calculateResultforUser(1,$id),
               $this->calculateResultforUser(2,$id),
               $this->calculateResultforUser(3,$id),
               $this->calculateResultforUser(4,$id),

           ]
       ];

       $user = User::find($id);
        $res = Yuklamalar::query()->where('user_id','=',$id)->where('uy_id','=', self::uy_id)->orderByDesc('ball')->get();
        $counts = DB::table('yuklamalar as y')
            ->leftJoin('kriteriyas as k', 'y.kriteriya_id', '=', 'k.id')
            ->where('y.user_id', '=', $id)
            ->whereIn('k.category_id', [1, 2, 3, 4])
            ->select('k.category_id', DB::raw('count(*) as count'))
            ->groupBy('k.category_id')
            ->pluck('count', 'category_id');

        $w1 = $counts[1] ?? 0;
        $w2 = $counts[2] ?? 0;
        $w3 = $counts[3] ?? 0;
        $w4 = $counts[4] ?? 0;


//        dd($w1);
        return view('users.forms.oneuser',$data,compact('res','user','w1','w2','w3','w4'))->with('i');
    }
    public function getallreyting()
    {
        $allr= DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'd.user_id',
                DB::raw('SUM(d.ballas ball'),
//                DB::raw('SUM(CASE
//                        WHEN t.category_id = 1 THEN 0.30 * d.ball
//                        WHEN t.category_id = 2 THEN 0.15 * d.ball
//                        WHEN t.category_id = 3 THEN 0.45 * d.ball
//                        WHEN t.category_id = 4 THEN 0.10 * d.ball
//                        ELSE 0
//                    END) as ball'),
                'u.image',
                'u.name',
                'u.kaf_name',
                'u.lavozim'
            )
            ->where('uy_id','=', self::uy_id)
            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
            ->orderByDesc('ball')
            ->get();
        return view('admin.allreyting',compact('allr'));
    }
    public function getallreytingforusers()
    {
        $allr= DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'd.user_id',
                DB::raw('SUM(d.ball) as ball'),
//                DB::raw('SUM(CASE
//                        WHEN t.category_id = 1 THEN 0.30 * d.ball
//                        WHEN t.category_id = 2 THEN 0.15 * d.ball
//                        WHEN t.category_id = 3 THEN 0.45 * d.ball
//                        WHEN t.category_id = 4 THEN 0.10 * d.ball
//                        ELSE 0
//                    END) as ball'),
                'u.image',
                'u.name',
                'u.kaf_name',
                'u.lavozim'
            )
            ->where('uy_id','=', self::uy_id)
            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
            ->orderByDesc('ball')
            ->orderByDesc('u.lavozim')
            ->get();
        return view('users.forms.allreyting',compact('allr'));
    }

    public function openoldresults()
    {
        $uys = Ug::all();
        return view('users.forms.oldresults',compact('uys'));
    }

    public function getoldresults(Request $request)
    {

        $uys = Ug::all();
        $oldresults = DB::table('yuklamalar as y')
            ->leftJoin('kriteriyas as k', 'y.kriteriya_id', '=', 'k.id')
            ->select('y.id','y.user_id','y.ball','y.soat','y.fayl','k.band','y.comment')
            ->where('y.user_id','=',Auth::user()->getAuthIdentifier())
            ->where('y.uy_id','=', $request->uy_id)
            ->where('status','=',1)
            ->orderByDesc('y.ball')
            ->orderByDesc('k.band')
            ->get();
        $allrating = DB::table('yuklamalar as d')
            ->join('kriteriyas as t', 'd.kriteriya_id', '=', 't.id')
            ->leftJoin('users as u', 'd.user_id', '=', 'u.id')
            ->select(
                'd.user_id',
//                DB::raw('SUM(CASE WHEN t.category_id < 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as ball'),
//                DB::raw('SUM(CASE WHEN t.category_id >= 5 THEN IFNULL(d.ball, 0) ELSE 0 END) as jball'),
                DB::raw('SUM(CASE WHEN d.kriteriya_id < 57 THEN IFNULL(d.ball, 0) ELSE 0 END) - SUM(CASE WHEN d.kriteriya_id >= 57 THEN IFNULL(d.ball, 0) ELSE 0 END) as allball'),
                'u.image',
                'u.name',
                'u.kaf_name',
                'u.lavozim'
            )
            ->where('uy_id','=', $request->uy_id)
            ->whereIn('u.lavozim_id', [1, 2, 3, 4, 5, 6])
            ->groupBy('d.user_id', 'u.image', 'u.name', 'u.kaf_name', 'u.lavozim')
            ->orderBy('allball','DESC')
            //->limit(10)
            ->get();

        $userReyting = 0;
        $userBall = 0;
        foreach ($allrating as $key => $value) {
            if ($value->user_id == Auth::user()->getAuthIdentifier()) {
                $userReyting = $key + 1;
                $userBall = $value->allball;
            }

        }
        //dd($userBall);
        return view('users.forms.oldresults',compact('oldresults','uys','userBall','userReyting','allrating'));
    }

}
