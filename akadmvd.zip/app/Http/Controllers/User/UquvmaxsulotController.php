<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Majmua;
use App\Models\User\Uquvmaxsulot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UquvmaxsulotController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $uquvmaxsulot = DB::table('uquvmaxsulots')
//            ->where('status','=',1)
            ->where('user_id','=',Auth::user()->getAuthIdentifier())->get();
        return view('users.uquvmaxsulot.index',compact('uquvmaxsulot'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.uquvmaxsulot.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->method() == 'POST') {
            $storedData= $request->validate([
                'title' => 'required',
                'sana' => 'required',
                'turi_id' => 'required',
                'turi_name' => 'required',
            ]);
            if ($storedData)
            {

                if ($request->hasFile('file')) {
                $name = $request->file('file')->getClientOriginalName();
                $path = $request->file('file')->storeAs('public/uquvmaxsulot',time().$name);
                $fileFullname = time().$name;
                $userid = Auth::user()->getAuthIdentifier();
                $username = Auth::user()->name;

                $storedData1 = new Uquvmaxsulot();
                $storedData1->title = $request->title;
                $storedData1->turi_id = $request->turi_id;
                $storedData1->turi_name = $request->turi_name;
                $storedData1->sana = $request->sana;
                $storedData1->havola = $request->havola;
                $storedData1->file = $fileFullname;
                $storedData1->user_id = $userid;
                $storedData1->user_name = $username;
                $storedData1->kaf_id = Auth::user()->kaf_id;
                if ($storedData1->save())
                {
                    return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                }
                else
                {

                    return back()->with('danger','Xatolik yuz berdi  !!!');
                }
                } else {
                    return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
                }

            }
            else {
                return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
