<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User\Grand;
use App\Models\User\Iqtibo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class GrandController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $grand = DB::table('grands')
            ->where('user_id','=', Auth::user()->getAuthIdentifier())
//            ->where('status','=','1')
            ->get();
        return view('users.ilmiytadqiqot.grand.index',compact('grand'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.ilmiytadqiqot.grand.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->method() == 'POST') {
            $storedData= $request->validate([


                'turi_id' => 'required',
                'turi_name' => 'required',
                'title'=>'required'

            ]);
            if ($storedData)
            {
                if ($request->hasFile('file')) {
                $name = $request->file('file')->getClientOriginalName();
                $path = $request->file('file')->storeAs('public/grand',time().$name);
                $fileFullname = time().$name;
                $userid = Auth::user()->getAuthIdentifier();
                $username = Auth::user()->name;

                $storedData1 = new Grand();
                $storedData1->title = $request->title;
                $storedData1->turi_id = $request->turi_id;
                $storedData1->turi_name = $request->turi_name;
                $storedData1->file = $fileFullname;
                $storedData1->user_id = $userid;
                $storedData1->user_name = $username;
                $storedData1->kaf_id = Auth::user()->kaf_id;
                if ($storedData1->save())
                {
                    return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                }
                else
                {

                    return back()->with('danger','Xatolik yuz berdi  !!!');
                }
            } else {
                return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
            }

        }
        else {
            return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
        }
    }
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Grand::find($id);
        if ($item->delete())
        {
            return back()->with('status', 'O\'chirildi  !!!');
        } else
        {

            return back()->with('danger', 'Xatolik yuz berdi  !!!');
        }
    }
}
