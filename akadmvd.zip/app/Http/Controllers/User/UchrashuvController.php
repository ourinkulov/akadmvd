<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Uchrashuv;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use illuminate\Database\Eloquent\SoftDeletes;

class UchrashuvController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $uchrashuv = DB::table('uchrashuvs')->where('user_id','=', Auth::user()->getAuthIdentifier())->get();
        return view('users.work.uchrashuv.index',compact('uchrashuv'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.work.uchrashuv.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->method() == 'POST') {
            $storedData= $request->validate([
                'title' => 'required',
                'sana' => 'required',

            ]);
            if ($storedData)
            {
                if ($request->hasFile('file')) {
                    $name = $request->file('file')->getClientOriginalName();


                    $fileFullname = time().$name;
                    //dd($fileFullname);
                    $path = $request->file('file')->storeAs('public/uchrashuv',$fileFullname);

                    $userid = Auth::user()->getAuthIdentifier();
                    $username = Auth::user()->name;

                    $storedData1 = new Uchrashuv();
                    $storedData1->title = $request->title;
                    $storedData1->sana = $request->sana;
                    $storedData1->file = $fileFullname;


                    $storedData1->user_id = $userid;
                    $storedData1->user_name = $username;
                    $storedData1->kaf_id = Auth::user()->kaf_id;
                    if ($storedData1->save())
                    {
                        return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                    }
                    else
                    {

                        return back()->with('danger','Xatolik yuz berdi  !!!');
                    }
                } else {
                    return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
                }

            }
            else {
                return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
