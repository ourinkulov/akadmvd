<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User\Darsliks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DarslikController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $darslik = DB::table('darsliks')
           // ->where('status','=',1)
            ->where('user_id','=',Auth::user()->getAuthIdentifier())->get();
        return view('users.darslik.index',compact('darslik'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.darslik.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if ($request->method() == 'POST') {
            $yangiDarslik = $request->validate([
                'title' => 'required',
                'sana' => 'required',
                'muallif_soni' => 'required',
                'taboq' => 'required',
                'turi_id' => 'required',
                'turi_name' => 'required',
            ]);
            if ($yangiDarslik)
            {
                if ($request->hasFile('file')) {
                $name = $request->file('file')->getClientOriginalName();
                $path = $request->file('file')->storeAs('public/darsliklar',time().$name);
                $fileFullname = time().$name;
                $userid = Auth::user()->getAuthIdentifier();
                $username = Auth::user()->name;

                $darslik = new Darsliks();
                $darslik->title = $request->title;
                $darslik->turi_id = $request->turi_id;
                $darslik->turi_name = $request->turi_name;
                $darslik->sana = $request->sana;
                $darslik->muallif_soni = $request->muallif_soni;
                $darslik->taboq = $request->taboq;
                $darslik->file = $fileFullname;
                $darslik->user_id = $userid;
                $darslik->user_name = $username;
                $darslik->kaf_id = Auth::user()->kaf_id;
                if ($darslik->save())
                {
                    return back()->with('status','Darslik tizimga qabul qlindi. Darslik O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                }
                else
                {

                    return back()->with('danger','Xatolik yuz berdi  !!!');
                }
            } else {
                return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
            }

        }
        else {
            return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
        }
    }
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Darsliks::find($id);
        if ($item->delete())
        {
            return back()->with('status', 'O\'chirildi  !!!');
        } else
        {

            return back()->with('danger', 'Xatolik yuz berdi  !!!');
        }
    }
}
