<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Kriteriya;
use App\Models\Yuklamalar;
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;


class KriteriyaController extends Controller
{
    public  $isChecker;

    const uy_id = 5;
    public function __construct(Request $request)
    {
        $this->middleware(function ($request, $next) {
            if(Auth::user()->role == 4)
            {
                $this->isChecker = 4;
            }
            elseif(Auth::user()->role == 1 || Auth::user()->role == 2)
            {
                $this->isChecker = 1;
            }
            return $next($request);
        });
        $route = $request->route('route');
        $this->kriteriya = Kriteriya::where(['route' => $route])->firstOrFail();
    }

    public Kriteriya $kriteriya;
    public function index($route): View
    {   $kafId = Auth::user()->kaf_id;
        if($this->isChecker == 1){
//            $model = Yuklamalar::where(['route' => $this->kriteriya->route])->get();
            $model= Yuklamalar::query()
                ->select('yuklamalar.id','yuklamalar.user_id','yuklamalar.ball',
                    'yuklamalar.soat','yuklamalar.tur_id','yuklamalar.havola','yuklamalar.fayl',
                    'yuklamalar.muallif_soni','yuklamalar.taboqlar_soni','yuklamalar.comment','yuklamalar.status',
                    'yuklamalar.route','yuklamalar.kriteriya_id','yuklamalar.uy_id','users.name','kriteriyas.turlar','yuklamalar.created_at',
                )
                ->leftJoin('users', 'yuklamalar.user_id', '=', 'users.id')
                ->leftJoin('kriteriyas', 'yuklamalar.kriteriya_id', '=', 'kriteriyas.id')
                ->where(['yuklamalar.route' => $this->kriteriya->route])
                ->where('uy_id','=',self::uy_id)
                ->orderBy('users.name')
                ->get();
            //dd($model);
        }
        elseif($this->isChecker == 4)
        {
            $kafUsers = DB::table('users')->select('id')->where('kaf_id','=',$kafId)->pluck('id');
            $ids = [];
            foreach($kafUsers as $key=>$val)
            {$ids = $val;}
            // $model = Yuklamalar::where(['route' => $this->kriteriya->route])->get();
            // $model = Yuklamalar::leftJoin('users', function($join){$join->on('yuklamalar.user_id','=','users')})                where(['route' => $this->kriteriya->route])->get();
//              $model = Yuklamalar::whereIn('user_id',$kafUsers)->where(['route' => $this->kriteriya->route])->get();
            $model= Yuklamalar::query()
                ->select('yuklamalar.id','yuklamalar.user_id','yuklamalar.ball',
                    'yuklamalar.soat','yuklamalar.tur_id','yuklamalar.havola','yuklamalar.fayl',
                    'yuklamalar.muallif_soni','yuklamalar.taboqlar_soni','yuklamalar.comment','yuklamalar.status',
                    'yuklamalar.route','yuklamalar.kriteriya_id','yuklamalar.uy_id','users.name','kriteriyas.turlar',
                )
                ->leftJoin('users', 'yuklamalar.user_id', '=', 'users.id')
                ->leftJoin('kriteriyas', 'yuklamalar.kriteriya_id', '=', 'kriteriyas.id')
                ->whereIn('yuklamalar.user_id',$kafUsers)
                ->where(['yuklamalar.route' => $this->kriteriya->route])
                ->where('uy_id','=',self::uy_id)
                ->get();
//             dd($model);
        }
        else {
            //dd($model);
            $model = Yuklamalar::where(['user_id' => Auth::user()->id, 'route' => $this->kriteriya->route])->where('uy_id','=',self::uy_id)->get();
        }
        return view('users.forms.index',[
            'model' => $model,
            'kriteriya' => $this->kriteriya,
            'admin' => $this->isChecker,
        ]);
    }

    public function create()
    {
        return view('users.forms.create',[
            'kriteriya' => $this->kriteriya,
            'admin' => $this->isChecker,
            'kaf' => User::query()->where('role','=',4)->get(),
        ]);
    }
    public function edit($route, $id)
    {
        $model = Yuklamalar::findOrFail($id);
        $turli = !($model->tur_id === null);
        return view('users.forms.edit',[
            'kriteriya' => $this->kriteriya,
            'model' => $model,
            'admin' => $this->isChecker,
            'turli' => $turli,
        ]);
    }

    public function store(Request $request)
    {
        $user_id = Auth::user()->getAuthIdentifier();
        if ($this->kriteriya->id == 8 || $this->kriteriya->id == 9){
            return redirect()->back()->with('danger','Ushbu kriteriyalar uchun ma\'lumotlar HEMIS tizimidan olinadi');
        }
        if ($this->kriteriya->id == 16 || $this->kriteriya->id == 17  ){
            if ($this->kriteriya->id == 17 && $request->tur_id==1 ){
                $dotsentCheck = DB::table('yuklamalar')->select('id')
                    ->where('kriteriya_id','=',17)
                    ->where('tur_id','=',1)
                    ->where('user_id','=',$user_id)
                    ->count();
                if($dotsentCheck >= 1){
                    return redirect()->back()->with('danger','Ilmiy unvonga oid malumotlar kiritilgan!');
                }
            }
            if ($this->kriteriya->id == 17 && $request->tur_id==2 ){
                $profCheck = DB::table('yuklamalar')->select('id')
                    ->where('kriteriya_id','=',17)
                    ->where('tur_id','=',2)
                    ->where('user_id','=',$user_id)
                    ->count();
                if($profCheck >= 1){
                    return redirect()->back()->with('danger','Ilmiy unvonga oid malumotlar kiritilgan!');
                }
            }
            if ($this->kriteriya->id == 16 && $request->tur_id==1 ){
                $phdCheck = DB::table('yuklamalar')->select('id')
                    ->where('kriteriya_id','=',16)
                    ->where('tur_id','=',1)
                    ->where('user_id','=',$user_id)
                    ->count();
                if($phdCheck >= 1){
                    return redirect()->back()->with('danger','Ilmiy daraja oid malumotlar kiritilgan!');
                }
            }
            if ($this->kriteriya->id == 16 && $request->tur_id==2 ){
                $dsCheck = DB::table('yuklamalar')->select('id')
                    ->where('kriteriya_id','=',16)
                    ->where('tur_id','=',2)
                    ->where('user_id','=',$user_id)
                    ->count();
                if($dsCheck >= 1){
                    return redirect()->back()->with('danger','Ilmiy daraja oid malumotlar kiritilgan!');
                }
            }
        }
       // dd($this->kriteriya->id);
        $data = $request->validate([
            'soat' => ($this->kriteriya->soat) ? 'required' : '',
            'tur_id' => ($this->kriteriya->turlar_bormi) ? 'required' : '',
            'muallif_soni' => ($this->kriteriya->muallif_soni) ? 'required' : '',
            'taboqlar_soni' => ($this->kriteriya->taboqlar) ? 'required' : '',
            'havola' => ($this->kriteriya->havola) ? 'required' : '',
            'file' => 'required|file',
            'comment' => 'nullable|string',
        ]);
        //Maksimal balldan oshganmi tekshirish

        $maxBall =DB::table('kriteriyas')->select('max_ball')
           // ->where('uy_id','=',self::uy_id)
            ->where('id','=',$this->kriteriya->id)->first();
        $userBall= Yuklamalar::query()
            ->where('kriteriya_id','=',$this->kriteriya->id)
            ->where('user_id','=', $user_id)
            ->where('uy_id','=',self::uy_id)
            ->sum('ball');

        if ($maxBall->max_ball < $userBall+$request->ball) {
            return back()->with('danger','Ushbu kriteriyada Sizda mavjud ballar va kiritayotgan ballar yig\'indisi ajratilgan maksimal baldan oshib ketmoqda!')->withInput();
        }
        else
        {
            if ($request->hasFile('file')) {
                $file = $request->file('file');
                $fileName = Str::uuid() . '.' . $file->getClientOriginalExtension();
                $today = date('d/m/Y');
                $year = Carbon::createFromFormat('d/m/Y', $today)->format('Y');
                $month = Carbon::createFromFormat('d/m/Y', $today)->format('m');
                $day = Carbon::createFromFormat('d/m/Y', $today)->format('d');
//            $file->storeAs('public/'.$year.'/'.$month.'/'.$day, $year.'/'.$month.'/'.$day,'/'.$fileName);
                $path = $year.'/'.$month.'/'.$day.'/'.$fileName;
                Storage::disk('public')->put($path,file_get_contents($file));
                $data['fayl'] = $path;
                unset($data['file']);
            }


            $data['route'] = $this->kriteriya->route;

            $data['kriteriya_id'] = $this->kriteriya->id;

            $data['uy_id'] = self::uy_id;
            if (isset($request->jarimaball))
            {
                $data['user_id'] = $request->user_id;
                $data['ball'] = $request->ball;
                $data['status'] = 1;
            }
            else
            {
                $data['user_id'] = Auth::user()->id;
                $data['status'] = 0;
            }
            if (Yuklamalar::create($data))
            {
                return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
            } else {
                return back()->with('danger','Xatolik yuz berdi  !!!')->withInput();
            }
        }


    }
    public function update(Request $request, $route, $id)
    {
        //return redirect()->back()->with('danger','Materiallar qabul qilish muddati tugagan!');
        $data = $request->validate([
            'soat' => ($this->kriteriya->soat) ? 'required' : '',
            'tur_id' => ($this->kriteriya->turlar_bormi) ? 'required' : '',
            'muallif_soni' => ($this->kriteriya->muallif_soni) ? 'required' : '',
            'taboqlar_soni' => ($this->kriteriya->taboqlar) ? 'required' : '',
            'havola' => ($this->kriteriya->havola) ? 'required' : '',
            'comment' => 'nullable|string',
            'ball' => $this->isChecker ? 'required|numeric' : '',
            'accept' =>  $this->isChecker ? 'boolean' : '',
        ]);
        $maxBall =DB::table('kriteriyas')->select('max_ball')
            //->where('uy_id','=',self::uy_id)
            ->where('id','=',$this->kriteriya->id)->first();
        $yuklama = Yuklamalar::findOrFail($id);
        $userBall= Yuklamalar::query()
            ->where('uy_id','=',self::uy_id)
            ->where('kriteriya_id','=',$this->kriteriya->id)
            ->where('user_id','=',$yuklama->user_id)
            ->sum('ball');
        //dd($userBall+$request->ball);
       // dd($maxBall->max_ball);
        if ($maxBall->max_ball < ($userBall+$request->ball)) {
            return back()->with('danger','Ushbu professor-o\'qituvchi kriteriya uchun ajratilgan maksimal ballga egasiz. Shu sababli ushbu kriteriya bo\'yicha boshqa ma\'lumot kiritaolmaysiz  !!!')->withInput();
        }
        else
        {
            $data['status'] = $data['accept'];
            if(!$data['accept']){
                $data['ball'] = 0;
            }
            unset($data['accept']);
            if ($yuklama->update($data))
            {
                return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
            } else {
                return back()->with('danger','Xatolik yuz berdi  !!!')->withInput();
            }

        }


    }
    public function destroy($route, $id)
    {
        //dd($id);
        $yuklama = Yuklamalar::findOrFail($id);
        if ($yuklama->delete())
        {
            return back()->with('status',' O\'chirildi  !!!');
        } else {
            return back()->with('danger','Xatolik yuz berdi  !!!')->withInput();
        }
    }
    public function getUser(Request $request)
    {
        $fans = DB::table('users')->where('kaf_id','=',$request->kaf_id)->get();
        return response()->json($fans);
    }


}
