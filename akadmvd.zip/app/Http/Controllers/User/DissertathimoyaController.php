<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User\Darsliks;
use App\Models\User\Dissertathimoya;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DissertathimoyaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $dissertathimoya = DB::table('dissertathimoyas')
          //  ->where('status','=',1)
            ->where('user_id','=',Auth::user()->getAuthIdentifier())->get();
        return view('users.ilmiytadqiqot.dissertathimoya.index',compact('dissertathimoya'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.ilmiytadqiqot.dissertathimoya.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if ($request->method() == 'POST') {
            $yangiDarslik = $request->validate([
                'ximoya_belgilangan_sana' => 'required',
                'ximoya_sana' => 'required',
                'turi_id' => 'required',
                'turi_name' => 'required',
            ]);
            if ($yangiDarslik)
            {
                if ($request->hasFile('file')) {


                $name = $request->file('file')->getClientOriginalName();
                $path = $request->file('file')->storeAs('public/dissertathimoya',time().$name);
                $fileFullname = time().$name;
                $userid = Auth::user()->getAuthIdentifier();
                $username = Auth::user()->name;

                $darslik = new Dissertathimoya();

                $darslik->turi_id = $request->turi_id;
                $darslik->turi_name = $request->turi_name;
                $darslik->ximoya_belgilangan_sana = $request->ximoya_belgilangan_sana;
                $darslik->ximoya_sana = $request->ximoya_sana;

                $darslik->file = $fileFullname;
                $darslik->user_id = $userid;
                $darslik->user_name = $username;
                $darslik->kaf_id = Auth::user()->kaf_id;
                if ($darslik->save())
                {
                    return back()->with('status','Tizimga qabul qlindi. Darslik O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                }
                else
                {

                    return back()->with('danger','Xatolik yuz berdi  !!!');
                }
                } else {
                    return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
                }

            }
            else {
                return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Dissertathimoya::find($id);
        if ($item->delete())
        {
            return back()->with('status', 'O\'chirildi  !!!');
        } else
        {

            return back()->with('danger', 'Xatolik yuz berdi  !!!');
        }
    }
}
