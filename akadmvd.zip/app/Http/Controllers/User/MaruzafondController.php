<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\User\Maruzafond;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MaruzafondController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $maruzafonds = DB::table('maruzafonds')
//            ->where('status','=',1)
            ->where('user_id','=',Auth::user()->getAuthIdentifier())->get();
        return view('users.maruzafond.index',compact('maruzafonds'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('users.maruzafond.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($request->method() == 'POST') {
            $storedData= $request->validate([
                'title' => 'required',
                'sana' => 'required',
                'mavzu_soni' => 'required',
                'turi_id' => 'required',
                'turi_name' => 'required',
            ]);
            if ($storedData)
            {
                if ($request->hasFile('file')) {
                $name = $request->file('file')->getClientOriginalName();
                $path = $request->file('file')->storeAs('public/maruzafond',time().$name);
                $fileFullname = time().$name;
                $userid = Auth::user()->getAuthIdentifier();
                $username = Auth::user()->name;

                $storedData = new Maruzafond();
                $storedData->title = $request->title;
                $storedData->turi_id = $request->turi_id;
                $storedData->turi_name = $request->turi_name;
                $storedData->sana = $request->sana;
                $storedData->mavzu_soni = $request->mavzu_soni;
                $storedData->file = $fileFullname;
                $storedData->user_id = $userid;
                $storedData->user_name = $username;
                $storedData->kaf_id = Auth::user()->kaf_id;
                if ($storedData->save())
                {
                    return back()->with('status','Tizimga qabul qlindi.  O\'quv - uslubiy boshqarma tomonidan tasdiqlangandan  so\'ng ball ajratiladi  !!!');
                }
                else
                {

                    return back()->with('danger','Xatolik yuz berdi  !!!');
                }
                } else {
                    return back()->with('danger', 'Ilova faylini yuklang  ')->withInput();
                }

            }
            else {
                return back()->with('danger', 'Hamma maydonlarni kiriting')->withInput();
            }
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Maruzafond::find($id);
        if ($item->delete())
        {
            return back()->with('status', 'O\'chirildi  !!!');
        } else
        {

            return back()->with('danger', 'Xatolik yuz berdi  !!!');
        }
    }
}
