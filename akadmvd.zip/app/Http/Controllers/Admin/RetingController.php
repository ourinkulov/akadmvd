<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;

class RetingController extends Controller
{

    public function getReting($type_id){

        $encryptedData = Crypt::encrypt('user_uuid=12345&book_id=67890');
        $decryptedData = Crypt::decrypt($encryptedData);

         dd(Str::before($decryptedData,'book_id'));
         dd(Str::before($decryptedData,'book_id'));

        $type_id = $type_id;
        switch($type_id) {
            case('3e47d333-ee16-4f76-aaae-861c57000c93'):
                   $reting = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 1);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
//                    ->limit(10)
                    ->get();
                return view('retings.reting', compact('reting','type_id'));
            case('d4e45598-6033-4543-89cf-eed106f1127e'):
                   $reting = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.15 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 2);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
//                    ->limit(10)
                    ->get();;
                 return view('retings.reting', compact('reting','type_id'));

            case('a86e6ca3-9bdc-45ce-a03f-a116315e5d71'):
                $reting = DB::table('yuklamalar')
                ->select(
                    'yuklamalar.user_id',
                    'users.name',
                    'users.image',
                    'users.lavozim',
                    'users.kaf_name',
                    DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.45 as ball')
                )
                ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                    $query->select('id')
                        ->from('kriteriyas')
                        ->where('kriteriyas.category_id', 3);
                })
                ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                ->orderByDesc('ball')
//                ->limit(10)
                ->get();
            return view('retings.reting', compact('reting','type_id'));
            case('a843760e-2a2c-4446-aca7-a696d3dd355c'):
                $reting = DB::table('yuklamalar')
                    ->select(
                        'yuklamalar.user_id',
                        'users.name',
                        'users.image',
                        'users.lavozim',
                        'users.kaf_name',
                        DB::raw('SUM(yuklamalar.ball) * 0.3 as ball')
//                        DB::raw('SUM(yuklamalar.ball) * 0.10 as ball')
                    )
                    ->leftJoin('users', 'users.id', '=', 'yuklamalar.user_id')
                    ->whereIn('yuklamalar.kriteriya_id', function ($query) {
                        $query->select('id')
                            ->from('kriteriyas')
                            ->where('kriteriyas.category_id', 4);
                    })
                    ->groupBy('yuklamalar.user_id', 'users.name', 'users.image', 'users.lavozim', 'users.kaf_name')
                    ->orderByDesc('ball')
//                    ->limit(10)
                    ->get();
                return view('retings.reting', compact('reting','type_id'));
            default;

        }







    }
}
