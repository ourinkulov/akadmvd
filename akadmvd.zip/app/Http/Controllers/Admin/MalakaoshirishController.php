<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Malakaoshirish;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MalakaoshirishController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $malakaoshirish = DB::table('malakaoshirishes')
            ->where('status','=',1)
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.work.malakaoshirish.index',compact('malakaoshirish'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.work.malakaoshirish.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $malakaoshirish = DB::table('malakaoshirishes')->where('id',$id)->first();
        return view('admin.work.malakaoshirish.create',compact('malakaoshirish'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
//            'soni' => 'required',
//            'sana' => 'required',


        ]))
        {
            //dd($request->taboq);
            $darslik = \App\Models\User\Malakaoshirish::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
//                'soni'=>$request->soni,
//                'sana'=>$request->sana,
//                'gacha'=>$request->gacha,
//                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $masteruchrashuv = Malakaoshirish::find($id);
            if ($masteruchrashuv->delete())
            {
                return back()->with('danger','O\'chirildi');
            }
            else
            {
                return back()->with('danger','Xatolik yuz berdi');
            }
        }
    }
}
