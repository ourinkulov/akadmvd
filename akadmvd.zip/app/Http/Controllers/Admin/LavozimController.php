<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\LavozimRepositoryInterface;


class LavozimController extends Controller
{
    public function __construct(LavozimRepositoryInterface $lavozimRepository)
    {
        $this->lavozimRepository = $lavozimRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lavozim = $this->lavozimRepository->all();
        return view('admin.lavozim.index', compact('lavozim'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.lavozim.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
        $data = $request->validate([
            'lavozim_name'=>'required'
        ]);
        $this->lavozimRepository->create($data);
        return redirect()->back()
        ->with('status','Yaratildi!!!');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $lavozim = $this->lavozimRepository->find($id);
        return view('admin.lavozim.update', compact('lavozim'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //dd($request);
        $request->validate([
            'lavozim_name'=>'required',
            ]);
        $this->lavozimRepository->update($id, $request->only('lavozim_name') );
        return redirect()->back()->with('status','O\'zgartirildi !!!');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->lavozimRepository->delete($id);
        return redirect()->back()->with('danger','O\'chirildi !!!');
    }


}
