<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReytingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getUquvUslubiyReyting()
    {
        $usr = DB::table('v_uquvuslubiy_reyting')
            //->select('id','name','kaf_id','image','ball')
            ->get();
        return view('admin.uslubiyreyting.index',compact('usr'))->with('i');
    }
    public function getUquvMaxsulotReyting()
    {
        $uyr= DB::table('v_uquv_yuklama')
            //->select('id','name','kaf_id','image','ball')
            ->get();
        return view('admin.uquvyuklama.index',compact('uyr'))->with('i');
    }
    public function getUquvJamoatishlarReyting()
    {
        $jir= DB::table('v_jamoat_ishlari')
            //->select('id','name','kaf_id','image','ball')
            ->get();
        return view('admin.work.index',compact('jir'))->with('i');
    }


}
