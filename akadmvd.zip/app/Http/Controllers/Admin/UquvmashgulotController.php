<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Pednazorat;
use App\Models\User\Uquvmashgulot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UquvmashgulotController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $uquvmashgulot = DB::table('uquvmashgulots')->orderBy('user_name')
            ->where('status','=',1)
            ->get();

        return view('admin.uquvyuklama.uquvmashgulot.index',compact('uquvmashgulot'))->with('i');
    }
    public function tasdiq()
    {
        $uquvmashgulot = DB::table('uquvmashgulots')
            ->where('status','=',2)->orderBy('user_name')->orderBy('turi_name')
            ->get();

        return view('admin.uquvyuklama.uquvmashgulot.tasdiq',compact('uquvmashgulot'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $uquvmashgulot = DB::table('uquvmashgulots')
            ->where('id',$id)
            ->first();
        return view('admin.uquvyuklama.uquvmashgulot.create',compact('uquvmashgulot'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
            'soni'=>'required',
            'turi_id' => 'required',
            'turi_name' => 'required',


        ]))
        {
            //dd($request->soni);
            $kazus = Uquvmashgulot::find($id);
            //$taboq = $request->taboq;
                $kazus->ball = $request->ball;
                $kazus->soni = $request->soni;
                $kazus->turi_id = $request->turi_id;
            $kazus->turi_name=$request->turi_name;
            $kazus->status = '2';
            if ($kazus->save())
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Uquvmashgulot::find($id);
        if ($item->delete())
        {
            return back()->with('status', 'O\'chirildi  !!!');
        } else
        {

            return back()->with('danger', 'Xatolik yuz berdi  !!!');
        }
    }
}
