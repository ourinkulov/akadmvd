<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Maruzafond;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MaruzafondController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $maruzafonds = DB::table('maruzafonds')
            ->where('status','=',1)->orWhere('status','=',2)->orderBy('user_name')
            ->get();
        return view('admin.maruzafond.index',compact('maruzafonds'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $maruzafond = DB::table('maruzafonds')->where('id',$id)->first();
        return view('admin.maruzafond.create',compact('maruzafond'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate(['ball'=>'required','turi_name'=>'required','mavzu_soni'=>'required','turi_id'=>'required']))
        {
            //dd($request->taboq);
            $darslik = Maruzafond::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
                'turi_id'=>$request->turi_id,
                'turi_name'=>$request->turi_name,
                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = Maruzafond::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
