<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Kurswork;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Davlatatestat extends Controller
{ public function __construct()
{
    $this->middleware('auth');
}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $attestat = DB::table('davlatatestats')
            ->where('status','=',1)
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.uquvyuklama.atestat.index',compact('attestat'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.uquvyuklama.atestat.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $attestat = DB::table('davlatatestats')->where('id',$id)->first();
        return view('admin.uquvyuklama.atestat.create',compact('attestat'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
//            'soni' => 'required',
//            'turi_name' => 'required',

        ]))
        {
            //dd($request->taboq);
            $darslik = \App\Models\User\Davlatatestat::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
                //'soni'=>$request->soni,
//                'turi_name'=>$request->turi_name,
//                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = \App\Models\User\Davlatatestat::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
