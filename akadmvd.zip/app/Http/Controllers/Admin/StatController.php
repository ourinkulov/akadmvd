<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Yuklamalar;

class StatController extends Controller
{
    public function getTeacherHours(){
        $results = DB::table('yuklamalar AS y')->leftJoin('users AS u','y.user_id', '=', 'u.id')
        ->select('u.id as _employee','u.name','y.ball','y.soat as dars_soni')
        ->where('uy_id','=', 4)
        ->where('kriteriya_id','=',1)
        ->orderByDesc('u.name','y.ball')
        ->get();
        //dd($results);
//         $results = DB::connection('pgsql')->table(DB::raw("(  
//             SELECT 
//                 s._employee
//             FROM e_subject_schedule s
//             LEFT JOIN e_group g ON s._group = g.id
//             WHERE s._subject_topic IS NOT NULL
//                 AND CAST(s._education_year AS INTEGER) = 2024
//                 AND CAST(g._education_form AS INTEGER) = 11
//             GROUP BY 
//                 s._employee, 
//                 s._training_type, 
//                 s._auditorium, 
//                 s._lesson_pair, 
//                 s.lesson_date
//         ) AS qd"))
//         ->leftJoin('e_employee AS e', 'qd._employee', '=', 'e.id')
//         ->leftJoin('e_employee_meta AS em', 'e.id', '=', 'em._employee')
//         ->leftJoin('h_teacher_position_type AS tt', 'em._position', '=', 'tt.code')
//         ->select([
//             'qd._employee',
//             DB::raw("e.second_name || ' ' || e.first_name || ' ' || e.third_name AS name"),
//             DB::raw('tt.name AS lavozim'),
//             DB::raw('COUNT(*) * 2 AS dars_soni'),
//             DB::raw("
//                 CASE 
//     WHEN CAST(tt.code AS INTEGER) IN (11, 12) THEN 
//         CASE 
//             WHEN COUNT(*) * 2 > 350 THEN 
//                 150 + ROUND((COUNT(*) * 2 - 350.0) * 0.1, 1)
//             ELSE 
//                 ROUND(150 * (COUNT(*) * 2 / 350.0), 1)
//         END
//     WHEN CAST(tt.code AS INTEGER) = 13 THEN 
//         CASE 
//             WHEN COUNT(*) * 2 > 300 THEN 
//                 150 + ROUND((COUNT(*) * 2 - 300.0) * 0.1, 1)
//             ELSE 
//                 ROUND(150 * (COUNT(*) * 2 / 300.0), 1)
//         END
//     WHEN CAST(tt.code AS INTEGER) = 14 THEN 
//         CASE 
//             WHEN COUNT(*) * 2 > 280 THEN 
//                 150 + ROUND((COUNT(*) * 2 - 280.0) * 0.1, 1)
//             ELSE 
//                 ROUND(150 * (COUNT(*) * 2 / 280.0), 1)
//         END
//     WHEN CAST(tt.code AS INTEGER) = 15 THEN 
//         CASE 
//             WHEN COUNT(*) * 2 > 250 THEN 
//                 150 + ROUND((COUNT(*) * 2 - 250.0) * 0.1, 1)
//             ELSE 
//                 ROUND(150 * (COUNT(*) * 2 / 250.0), 1)
//         END
//     WHEN CAST(tt.code AS INTEGER) = 16 THEN 
//         CASE 
//             WHEN COUNT(*) * 2 > 150 THEN 
//                 150 + ROUND((COUNT(*) * 2 - 150.0) * 0.1, 1)
//             ELSE 
//                 ROUND(150 * (COUNT(*) * 2 / 150.0), 1)
//         END
//     ELSE NULL
// END AS ball

//             ")
//         ])
//         //->where('qd._employee','=',750)
//         ->groupBy(
//             'qd._employee',
//             DB::raw("e.second_name || ' ' || e.first_name || ' ' || e.third_name"),
//             DB::raw('tt.name'),
//             DB::raw('tt.code')
//         )
//         ->orderByDesc('dars_soni')
//         ->get();
        //dd($results);        
        // foreach ($results as $item) {
           
        //     if(!empty($item)){
        //         $user = DB::table('users')->where('hemis_id', '=', $item->_employee)->where('role','=',3)->first();
        //         //dd($item->ball);
        //         if(!empty($user)){
        //             $yuklama = new Yuklamalar;
        //         $yuklama->user_id = $user->id;
        //         $yuklama->status = 1;
                
        //         if(!empty($item->ball)){
                    
        //             if($item->ball > 190)
        //             {
        //                 $yuklama->ball = 190;
        //             }else{
        //                 //dd($item->ball);
        //                 $yuklama->ball = !empty($item->ball) ? $item->ball : 0;
        //             }
                    
        //         }else{$yuklama->ball = 0;}

                 
        //         $yuklama->soat = $item->dars_soni;
        //         $yuklama->havola = 'https://hemis.akadmvd.uz';
        //         $yuklama->fayl = 'hemis_jurnal';
        //         $yuklama->muallif_soni = 1;
        //         $yuklama->route = '11-band-professor-oqituvchining-oquv-yuklamasini-bajarganligi';
        //         $yuklama->kriteriya_id = 1;
        //         $yuklama->uy_id = 4;
        //         $yuklama->tur_id = 1;
        //         if($yuklama->save()){
        //            //echo $user->id;
        //            return view('admin.stat.getteacherreport',compact('results'));
        //         }else{
        //             return "Xatolik yuz berdi";
        //         }
        //         }
        //     }
        // }
        return view('admin.stat.getteacherreport',compact('results'));

    }

    public function getTeacherMarks(){
      

$data = DB::connection('pgsql')->table('e_subject_schedule')
    ->select([
        '_subject as fan_id',
        '_group as guruh_id',        
        '_employee as teacher_id',
        DB::raw('COUNT(_employee) as dars_soni')
    ])
    ->where('_education_year', '2024')
    //->where('_employee', 190)
    ->groupBy('_subject', '_group', '_employee')
    ->having(DB::raw('COUNT(_employee)'), '>', 10)
    ->orderBy('_group')
    ->get();

$data_two = DB::connection('pgsql')->table('e_performance as p')
    ->select([
        'sub.id as fan_id',
        'sub.name as fan_name',
        'g.id as guruh_id',
        'g.name as guruh_name',
        'em._employee as teacher_id',
        DB::raw('AVG(p.grade) as baho')
    ])
    ->leftJoin('e_student_meta as sm', 'p._student', '=', 'sm._student')
    ->leftJoin('e_student as s', 'p._student', '=', 's.id')
    ->leftJoin('e_group as g', 'sm._group', '=', 'g.id')
    ->leftJoin('e_subject as sub', 'p._subject', '=', 'sub.id')
    ->leftJoin('e_employee_meta as em', 'em._employee', '=', 'p._employee')
    ->where('p._education_year', '2024')
    ->where('p._exam_type', '13')
    ->groupBy('g.id', 'g.name', 'sub.id', 'sub.name', 'em._employee')
    ->having(DB::raw('AVG(p.grade)'), '>', 4) // Filter here!
    ->orderByDesc(DB::raw('AVG(p.grade)'))
    //->limit(5)
    ->get();

// Natijalarni chiqarish
$results = [];
//dd($data_two);

foreach ($data as $item) {
    foreach ($data_two as $item_two) {
        if (
            $item->fan_id == $item_two->fan_id &&
            $item->guruh_id == $item_two->guruh_id &&
            $item_two->baho > 4
        ) {
            $results[] = [
                'teacher_id' => $item->teacher_id,
                'guruh_name' => $item_two->guruh_name,
                'baho' => $item_two->baho,
            ];
        }
    }
}

// Baholarni kamayish tartibida saralash
usort($results, fn($a, $b) => $b['baho'] <=> $a['baho']);

// Faqat 5 ta yuqori baholi guruhni olish
$top_results = array_slice($results, 0, 5);
//dd($top_results);

// Natijalarni chiqarish
foreach ($results as $item) {
    //dd($item['teacher_id']);
    if ($item['baho'] > 4.5) {
        //echo "O'qituvchi {$item['teacher_id']}ning 5 baho olgan guruhi: {$item['guruh_name']}\n";
        $user = DB::table('users')->where('hemis_id', '=', $item['teacher_id'])->where('role','=',3)->first();
                //dd($item->ball);
                if(!empty($user)){
                    $yuklama = new Yuklamalar;
                $yuklama->user_id = $user->id;
                $yuklama->status = 1;
                $yuklama->ball = 10;
                 
                $yuklama->soat = $item['guruh_name'];
                $yuklama->havola = 'https://hemis.akadmvd.uz';
                $yuklama->fayl = 'hemis_jurnal';
                $yuklama->muallif_soni = 1;
                $yuklama->route = '15-band-biriktirilgan-oquv-guruhlarining-fanlar-boyicha-umumiy-ozlashtirish-korsatkichlari';
                $yuklama->kriteriya_id = 8;
                $yuklama->uy_id = 4;
                $yuklama->tur_id = 1;
                // if($yuklama->save()){
                //    //echo $user->id;
                //    return view('admin.stat.getteacherreport',compact('results'));
                // }else{
                //     return "Xatolik yuz berdi";
                // }
                }
    }
    if ($item['baho'] > 4) {
        //echo "O'qituvchi {$item['teacher_id']}ning 4 baho olgan guruhi: {$item['guruh_name']}\n";
        $user = DB::table('users')->where('hemis_id', '=', $item['teacher_id'])->where('role','=',3)->first();
                //dd($item->ball);
                if(!empty($user)){
                    $yuklama = new Yuklamalar;
                $yuklama->user_id = $user->id;
                $yuklama->status = 1;
                $yuklama->ball = 4;
                 
                $yuklama->soat = $item['guruh_name'];
                $yuklama->havola = 'https://hemis.akadmvd.uz';
                $yuklama->fayl = 'hemis_jurnal';
                $yuklama->muallif_soni = 1;
                $yuklama->route = '15-band-biriktirilgan-oquv-guruhlarining-fanlar-boyicha-umumiy-ozlashtirish-korsatkichlari';
                $yuklama->kriteriya_id = 8;
                $yuklama->uy_id = 4;
                $yuklama->tur_id = 2;
                // if($yuklama->save()){
                //    //echo $user->id;
                //    return view('admin.stat.getteacherreport',compact('results'));
                // }else{
                //     return "Xatolik yuz berdi";
                // }
                }
    } 
    $yuklama->save();
    // else {
    //     //dd($item);
    //     echo "O'qituvchi {$item['teacher_id']}ning 4 baho olgan guruhi: {$item['guruh_name']}\n";
    // }
}



//     $data = DB::connection('pgsql')->table('e_subject_schedule')
//     ->select([
//         '_subject as fan_id',
//         '_group as guruh_id',        
//         '_employee as teacher_id',
//         DB::raw('COUNT(_employee) as dars_soni')
//     ])
//     ->where('_education_year', '2024')
//     ->where('_employee', 198)
//     ->groupBy('_subject', '_group', '_employee')
//     ->having(DB::raw('COUNT(_employee)'), '>', 4)
//     ->orderBy('_group')
//     ->get();

//     $data_two = DB::connection('pgsql')->table('e_performance as p')
//     ->select([
//         'sub.id as fan_id',
//         'sub.name as fan_name',
//         'g.id as guruh_id',
//         'g.name as guruh_name',
//         'em._employee as teacher_id',
//         DB::raw('AVG(p.grade) as baho')
//     ])
//     ->leftJoin('e_student_meta as sm', 'p._student', '=', 'sm._student')
//     ->leftJoin('e_student as s', 'p._student', '=', 's.id')
//     ->leftJoin('e_group as g', 'sm._group', '=', 'g.id')
//     ->leftJoin('e_subject as sub', 'p._subject', '=', 'sub.id')
//     ->leftJoin('e_employee_meta as em', 'em._employee', '=', 'p._employee')
//     ->where('p._education_year', '2024')
//     ->where('p._exam_type', '13')
//     ->groupBy('g.id', 'g.name', 'sub.id', 'sub.name', 'em._employee')
//     ->orderBy('sub.id')
//     ->orderBy('g.name')
//     ->get();
//     foreach($data as $item){
//     foreach($data_two as $item_two){
//         if($item->fan_id == $item_two->fan_id && $item->guruh_id == $item_two->guruh_id)
//             if($item_two->baho > 4.5)
//             echo "O'qituvchi ".$item->teacher_id."ning 5 baho olgan guruhi  ".$item_two->guruh_name."\n";
        
//             elseif($item_two->baho > 4)
//             echo "O'qituvchi ".$item->teacher_id."ning 4 baho olgan guruhi  ".$item_two->guruh_name."\n";

             
//     }
// }
// }
}
}
