<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Kurswork;
use App\Models\User\Uquvreja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KursishController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kurswork = DB::table('kursworks')
            ->where('status','=',1)->orWhere('status','=',2)->orderBy('user_name')
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.uquvyuklama.kurswork.index',compact('kurswork'))->with('i');
    }
    public function tasdiq()
    {
        $kurswork = DB::table('kursworks')
            ->where('status','=',2)
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.uquvyuklama.kurswork.tasdiq',compact('kurswork'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.uquvyuklama.kurswork.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kurswork = DB::table('kursworks')->where('id',$id)->first();
        return view('admin.uquvyuklama.kurswork.create',compact('kurswork'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
            'soni' => 'required',
//            'turi_name' => 'required',

        ]))
        {
            //dd($request->taboq);
            $darslik = Kurswork::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
                'soni'=>$request->soni,
//                'turi_name'=>$request->turi_name,
//                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = Kurswork::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
