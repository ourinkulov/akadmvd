<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Hududmetodik;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HudumetodikController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $hududmetodik = DB::table('hududmetodiks')
            ->orderBy('user_name')
            //->where('status','=',1)
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.work.hududmetodik.index',compact('hududmetodik'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.work.hududmetodik.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $hududmetodik = DB::table('hududmetodiks')->where('id',$id)->first();
        return view('admin.work.hududmetodik.create',compact('hududmetodik'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
//            'soni' => 'required',
            'soni' => 'required',
            'taboq' => 'required',

        ]))
        {
            //dd($request->taboq);
            $darslik = \App\Models\User\Hududmetodik::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
//                'soni'=>$request->soni,
                'soni'=>$request->soni,
                'taboq'=>$request->taboq,
//                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = Hududmetodik::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
