<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Ijro;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IjroController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ijro = DB::table('ijros')
            ->where('status','=',1)->orWhere('status','=',2)->orderBy('user_name')
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.work.ijro.index',compact('ijro'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.work.ijro.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ijro = DB::table('ijros')->where('id',$id)->first();
        return view('admin.work.ijro.create',compact('ijro'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
//            'soni' => 'required',
//            'sana' => 'required',


        ]))
        {
            //dd($request->taboq);
            $darslik = \App\Models\User\Ijro::find($id);
            //$taboq = $request->taboq;

            if ($darslik->update([
                'ball'=>$request->ball,
//                'soni'=>$request->soni,
//                'sana'=>$request->sana,
//                'gacha'=>$request->gacha,
//                'mavzu_soni'=>$request->mavzu_soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $masteruchrashuv = Ijro::find($id);
            if ($masteruchrashuv->delete())
            {
                return back()->with('danger','O\'chirildi');
            }
            else
            {
                return back()->with('danger','Xatolik yuz berdi');
            }
        }
    }
}
