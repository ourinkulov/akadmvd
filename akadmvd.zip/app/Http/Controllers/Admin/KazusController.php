<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Kazu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KazusController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kazus = DB::table('kazus')
            ->where('status','=',1)->orWhere('status','=',2)->orderBy('user_name')
            //->where('user_id','=',Auth::user()->getAuthIdentifier())
            ->get();
        return view('admin.kazus.index',compact('kazus'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kazus = DB::table('kazus')->where('id',$id)->first();
        return view('admin.kazus.create',compact('kazus'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->validate([
            'ball'=>'required',
            'turi_id' => 'required',
            'turi_name' => 'required',
            'soni'=>'required'

        ]))
        {
            //dd($request->taboq);
            $kazus = Kazu::find($id);
            //$taboq = $request->taboq;

            if ($kazus->update([
                'ball'=>$request->ball,
                'turi_id'=>$request->turi_id,
                'turi_name'=>$request->turi_name,
                'soni'=>$request->soni,
                'status'=>'2'
            ]))
            {
                return back()->with('status',' Tasdiqlandi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = Kazu::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
