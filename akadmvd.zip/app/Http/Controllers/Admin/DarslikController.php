<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User\Darsliks;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DarslikController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $darslik = DB::table('darsliks')->where('status','=',1)->orWhere('status','=',2)->orderBy('user_name')->get();
        return view('admin.darslik.index',compact('darslik'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $darslik = DB::table('darsliks')->where('id',$id)->first();
        return view('admin.darslik.create',compact('darslik'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

       if ($request->validate(['ball'=>'required','turi_name'=>'required','muallif_soni'=>'required','turi_id'=>'required','taboq'=>'required']))
       {
           //dd($request->taboq);
           $darslik = Darsliks::find($id);
           $taboq = $request->taboq;

           if ($darslik->update([
               'ball'=>$request->ball,
               'turi_id'=>$request->turi_id,
               'turi_name'=>$request->turi_name,
               'muallif_soni'=>$request->muallif_soni,
               'taboq'=> $taboq,
               'status'=>'2'
           ]))
           {
               return back()->with('status',' Darslik tasdiqlandi !!!');
           }
           else
           {

               return back()->with('danger',' Xatolik yuz berdi  !!!');
           }
       }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id)
        {
            $item = Darsliks::find($id);
            if ($item->delete())
            {
                return back()->with('danger',' O\'chirildi !!!');
            }
            else
            {

                return back()->with('danger',' Xatolik yuz berdi  !!!');
            }
        }
    }
}
