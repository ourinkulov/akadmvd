<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Schedule;
use Illuminate\Http\Request;
use App\Models\E_subject_schedule;
use Carbon\Carbon;
class HemisController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function getLesson()
    {
        $yesterday = Carbon::now()->subDay()->toDateString();
        $lesson = E_subject_schedule::where('lesson_date','=', '2025-03-17')->get();
        $subject = new Schedule();
        $subject->e_subject_schedule_id = $lesson[0]->id;
        $subject->_curriculum = $lesson[0]->curriculum;
        $subject->_subject = $lesson[0]->_subject;
        $subject->_education_year = $lesson[0]->_education_year;
        $subject->_semester = $lesson[0]->_semester;
        $subject->_training_type = $lesson[0]->_training_type;
        $subject->_auditorium = $lesson[0]->_auditorium;
        $subject->_subject_topic = $lesson[0]->_subject_topic;
        $subject->_week = $lesson[0]->_week;
        $subject->_employee = $lesson[0]->_employee;
        $subject->_lesson_pair = $lesson[0]->_lesson_pair;
        $subject->lesson_date = $lesson[0]->lesson_date;
        $subject->position = $lesson[0]->position;
        $subject->active = $lesson[0]->active;
        $subject->_translations = $lesson[0]->_translations;
        $subject->additional = $lesson[0]->additional;
        $subject->created_at = $lesson[0]->created_at;
        $subject->updated_at = $lesson[0]->updated_at;
        $subject->save();
    }
}
