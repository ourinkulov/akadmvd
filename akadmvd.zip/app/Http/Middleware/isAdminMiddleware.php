<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use const http\Client\Curl\AUTH_ANY;

class isAdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (Auth::check())
        {
            if (Auth::user()->role == '1' || Auth::user()->role == '2')
            {
                return $next($request);
            }
            else
            {
                return  redirect()->back()->with('message','Sizda ushbu saxifaga kirishga ruxsat berilmagan');
            }
        }
        else
        {
            return  redirect('/login')->with('message','Tizimga kiring');
        }

        return $next($request);
    }

}
