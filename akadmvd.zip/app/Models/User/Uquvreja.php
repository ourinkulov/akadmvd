<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Uquvreja extends Model
{
    use HasFactory;

    protected $table = 'uquvrejas';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'turi_name',
        'turi_id',
        'file',
        'ball',
        'status',
    ];
}
