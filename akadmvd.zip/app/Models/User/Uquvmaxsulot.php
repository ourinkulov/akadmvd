<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Uquvmaxsulot extends Model
{
    use HasFactory;
    protected $table = 'uquvmaxsulots';
    protected $fillable =
        [
          'kaf_id',
          'user_id',
          'user_name',
          'title',
          'sana',
          'havola',
          'turi_id',
          'turi_name',
          'file',
          'ball',
          'status',

        ];
}
