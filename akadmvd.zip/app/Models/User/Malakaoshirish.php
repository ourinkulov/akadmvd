<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Malakaoshirish extends Model
{
    use HasFactory;

    protected $table = 'malakaoshirishes';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'file',
        'ball',
        'status',
    ];
}
