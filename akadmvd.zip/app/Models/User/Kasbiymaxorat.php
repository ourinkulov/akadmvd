<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kasbiymaxorat extends Model
{
    use HasFactory;
    protected $fillable=[
        'kaf_id',
        'user_id',
        'user_name',
        'file',
        'ball',
        'status',
        'sana',
        'turi_name',
        'turi_id'

    ];
    protected $table = 'kasbiymaxorats';
}
