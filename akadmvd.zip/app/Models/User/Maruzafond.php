<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Maruzafond extends Model
{
    use HasFactory;

    protected $table = 'maruzafonds';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'mavzu_soni',
        'file',
        'ball',
        'status'
];
}
