<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dissertathimoya extends Model
{
    use HasFactory;
    protected $table = 'dissertathimoyas';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'turi_id',
        'turi_name',
        'ximoya_belgilangan_sana',
        'ximoya_sana',
        'file',
        'ball',
        'status',
    ];

}
