<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ilmiymaktab extends Model
{
    use HasFactory;
    protected $table = 'ilmiymaktabs';

    protected $fillable  = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'turi_name',
        'turi_id',
        'file',
        'ball',
        'status',
    ];
}
