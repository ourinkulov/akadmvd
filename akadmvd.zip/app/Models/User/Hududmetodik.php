<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hududmetodik extends Model
{
    use HasFactory;

    protected $table = 'hududmetodiks';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'soni',
        'taboq',
        'file',
        'ball',
        'status',
    ];
}
