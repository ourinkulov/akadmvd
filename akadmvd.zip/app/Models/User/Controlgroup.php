<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Controlgroup extends Model
{
    use HasFactory;


    protected $table = 'controlgroups';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'turi_id',
        'turi_name',
        'file',
        'ball',
        'status',
    ];
}
