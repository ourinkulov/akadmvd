<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pednazorat extends Model
{
    use HasFactory;

    protected $table = 'pednazorats';
    protected $fillable =
        [
            'kaf_id',
            'user_id',
            'user_name',
            'soni',
            'turi_id',
            'turi_name',
            'title',
            'file',
            'ball',
            'status'
        ];
}
