<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Darsliks extends Model
{
    use HasFactory;
    protected $table = 'darsliks';
    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'turi_id',
        'turi_name',
        'sana',
        'muallif_soni',
        'file',
        'ball',
        'taboq',
        'status',
    ];
}
