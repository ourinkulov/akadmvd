<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Monografiya extends Model
{
    use HasFactory;
    protected $fillable=[
        'kaf_id',
        'user_id',
        'user_name',
        'turi_name',
        'turi_id',
        'file',
        'ball',
        'status',
        'taboq',
        'soni'
    ];
    protected $table = 'monografiyas';
}
