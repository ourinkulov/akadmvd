<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Davlatatestat extends Model
{
    use HasFactory;
    protected $fillable=[
        'kaf_id',
        'user_id',
        'user_name',
        'file',
        'soni',
        'title',
        'ball',
        'status',
        'turi_name',
        'turi_id'

    ];
    protected $table = 'davlatatestats';
}
