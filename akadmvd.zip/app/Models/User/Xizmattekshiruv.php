<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Xizmattekshiruv extends Model
{
    use HasFactory;

    protected $table = 'xizmattekshiruvs';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',

        'file',
        'ball',
        'status',
    ];
}
