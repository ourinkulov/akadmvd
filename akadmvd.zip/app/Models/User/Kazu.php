<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kazu extends Model
{
    use HasFactory;
    protected $table = 'kazus';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'soni',
        'turi_name',
        'turi_id',
        'file',
        'ball',
        'status',
    ];
}
