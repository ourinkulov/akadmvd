<?php

namespace App\Models\User;

use App\Models\Yuklamalar;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fakultativ extends Model
{
    use HasFactory;

    public $guarded = [];

    public function yuklamalar()
    {
        return $this->morphMany(Yuklamalar::class, 'yuklamalarable');
    }
}
