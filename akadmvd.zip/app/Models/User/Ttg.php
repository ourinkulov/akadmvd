<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ttg extends Model
{
    use HasFactory;


    protected $table = 'ttgs';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'soni',
        'file',
        'ball',
        'status',
    ];
}
