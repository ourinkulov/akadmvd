<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ijro extends Model
{
    use HasFactory;

    protected $table = 'ijros';

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'turi_id',
        'turi_name',
        'sana',
        'file',
        'ball',
        'status',
    ];
}
