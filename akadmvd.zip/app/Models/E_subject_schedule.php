<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class E_subject_schedule extends Model
{
    use HasFactory;
    protected $connection = 'pgsql';
    protected $table = 'e_subject_schedule';

    public $guarded = [];
}
