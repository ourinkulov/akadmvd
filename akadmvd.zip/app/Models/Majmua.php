<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Majmua extends Model
{
    use HasFactory;
    protected $table = 'majmuas';
    protected $fillable = [
      'kaf_id',
      'user_id',
      'user_name',
      'title',
      'havola',
      'turi_id',
      'turi_name',
      'file',
      'ball',
      'status',
    ];
}
