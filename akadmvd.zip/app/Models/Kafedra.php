<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kafedra extends Model
{
    use HasFactory;

    public $guarded = [];

    public function teachers()
    {
        return $this->hasMany(User::class, 'kaf_id', 'id')->where('role', 3);
    }
}
