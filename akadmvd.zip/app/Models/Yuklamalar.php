<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Yuklamalar extends Model
{
    use HasFactory;

    public $guarded = [];

    public $table = 'yuklamalar';
    protected $fillable = [
        'id','user_id','ball',
        'soat','tur_id','havola','fayl',
        'muallif_soni','taboqlar_soni','comment','status',
        'route','kriteriya_id','uy_id'
    ];

    public $casts = [
        'status' => 'boolean'
    ];

    public function kriteriya(): BelongsTo
    {
        return $this->belongsTo(Kriteriya::class, 'kriteriya_id', 'id');
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

}
