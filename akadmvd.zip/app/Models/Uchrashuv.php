<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Uchrashuv extends Model
{
    use HasFactory;

    protected $fillable = [
        'kaf_id',
        'user_id',
        'user_name',
        'title',
        'sana',
        'turi_id',
        'turi_name',
        'file',
        'ball',
        'status',
    ];
}
