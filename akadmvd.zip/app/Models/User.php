<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use App\Models\User\Ilmiydaraja;
use App\Models\User\Ilmiyunvon;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'lavozim',
        'lavozim_id',
        'email',
        'password',
        'image',
        'kaf_id',
        'kaf_name',
        'role',
        'iio',
        'ait',
        'pit',
        'malumoti',
        'mutaxassislik',
        'malumoti_id',
        'born',
        'pwd'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function kafedra(): BelongsTo
    {
        return $this->belongsTo(Kafedra::class, 'kaf_id', 'id');
    }

    public function yuklamalar(): HasMany
    {
        return $this->hasMany(Yuklamalar::class, 'user_id', 'id');
    }

    public function sumBall()
    {
        return $this->yuklamalar()->where('status', 1)->sum('ball');
    }
    public function getOverallRatingForCategory(int $categoryId, float $weight)
    {
        $result = $this->yuklamalar()
            ->whereIn('kriteriya_id', Kriteriya::where(['category_id' => $categoryId])->pluck('id')->toArray())
            ->where('status', 1)
            ->select('user_id', DB::raw('(sum(ball) * ' . $weight . ') as total, count(*) as docs'))
            ->groupBy('user_id')
            ->first();

        // Check if $result is null
        if ($result === null) {
            return [
                'total' => 0, // Or whatever default value you want
                'docs' => 0,
            ];
        }

        return $result->toArray();
    }

    public function getK1OverallRating(): array
    {
        return $this->getOverallRatingForCategory(1, 0.40);
    }

    public function getK2OverallRating(): array
    {
        return $this->getOverallRatingForCategory(2, 0.20);
    }

    public function getK3OverallRating(): array
    {
        return $this->getOverallRatingForCategory(3, 0.30);
    }

    public function getK4OverallRating(): array
    {
        return $this->getOverallRatingForCategory(4, 0.10);
    }

    public function allOverall(): int
    {
        return $this->getK1OverallRating()['total'] +
            $this->getK2OverallRating()['total'] +
            $this->getK3OverallRating()['total'] +
            $this->getK4OverallRating()['total'];
    }

    public function ilmiyDaraja(){
        return $this->belongsTo(Ilmiydaraja::class);
    }

    public function ilmiyUnvon(){
        return $this->belongsTo(Ilmiyunvon::class);
    }

}
