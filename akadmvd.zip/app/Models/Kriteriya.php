<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Kriteriya extends Model
{
    use HasFactory;

    public $casts = [
        'status' => 'boolean',
        'min_ball' => 'integer',
        'max_ball' => 'integer',
        'soat' => 'boolean',
        'turlar_bormi' => 'boolean',
        'mualliflar' => 'boolean',
        'taboqlar' => 'boolean',
        'havola' => 'boolean',
        'turlar' => 'array',
        'category_id' => 'integer',

    ];



    public $guarded = [];

    public function yuklamalar()
    {
        return $this->hasMany(Yuklamalar::class);
    }

}

