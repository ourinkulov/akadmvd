<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class CcAssign extends Model
{
    protected $connection = 'ehujjat';
    protected $table = 'controlcard_assignes';

    use HasFactory;

    public $guarded = [];

    public function controlCard(): HasOne
    {
        return $this->hasOne(Controlcard::class, 'id', 'cc_id');
    }
}
