<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Controlcard extends Model
{
    protected $connection= 'ehujjat';

    use HasFactory;

    public $guarded = [];
}
