<?php

namespace App\Providers;

use App\Models\User\Kriteriya;
use App\Repositories\LavozimRepository;
use App\Repositories\LavozimRepositoryInterface;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Cache;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(LavozimRepositoryInterface::class, LavozimRepository::class);
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(): void
    {
        View::share('k1', $this->getKriteriyaByCategory(1));
        View::share('k2', $this->getKriteriyaByCategory(2));
        View::share('k3', $this->getKriteriyaByCategory(3));
        View::share('k4', $this->getKriteriyaByCategory(4));
        View::share('k5', $this->getKriteriyaByCategory(5));
        View::share('k6', $this->getKriteriyaByCategory(6));
        View::share('k7', $this->getKriteriyaByCategory(7));
        View::share('k8', $this->getKriteriyaByCategory(8));
    }

    function getKriteriyaByCategory($categoryId)
    {
        return Cache::remember('kriteriya_' . $categoryId, now()->addHour(), function () use ($categoryId) {
            return Kriteriya::where('category_id', $categoryId)->get();
        });
    }
}
