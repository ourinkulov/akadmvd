<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use function dd;
use function Laravel\Prompts\confirm;
use function Laravel\Prompts\select;
use function Laravel\Prompts\text;

class Kriteria extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:kt';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Kriteriya yaratish';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $bandNomi = text('Kriteriya bandini kiriting!', required: true);

        $xujjatlar = text('Xujjatlari!', required: true);

        $asoslovchiXujjatlar = text('Asoslovchi xujjatlar', required: true);

        $izox = text('Izox!', required: true);

        $min = text('Minimal ball!', required: true);

        $max = text('Maksimal ball!', required: true);

        $soat = confirm('Kriteriyada soatlar soni kerakmi?',
            yes: 'Ha',
            no: 'Yo\'q'
        );

        $turlar = [];

        if (confirm('Turlar bormi?')) {

            while (true) {
                $tur = text('Tur nomini kiriting');
                $ball = text('Tur uchun ballni kiriting');
                $turlar[] = [
                    'id' => count($turlar) + 1,
                    'nomi' => $tur,
                    'ball' => $ball,
                ];
                if (!confirm('Yana tur qo\'shasizmi?')) {
                    break;
                }
            };
        }
        $count = count($turlar);
        $turlar = serialize($turlar);


        $mualliflarSoni = confirm('Mualliflar soni kerakmi?',
            yes: 'Ha',
            no: 'Yo\'q'
        );

        $taboqlarSoni = confirm('Taboqlar soni kerakmi?',
            yes: 'Ha',
            no: 'Yo\'q'
        );
        $havola = confirm('Havola kiritilishi kerakmi?',
            yes: 'Ha',
            no: 'Yo\'q'
        );

        $routeUrl = text('Router URL ni kiriting');
        $menu = text('Menyudagi nomini kiriting');

        $kriteria = new \App\Models\Kriteriya();

        $kriteria->create([
            'band' => $bandNomi,
            'xujjatlar' => $xujjatlar,
            'asoslovchi_xujjatlar' => $asoslovchiXujjatlar,
            'izox' => $izox,
            'min_ball' => $min,
            'max_ball' => $max,
            'soat' => $soat,
            'turlar_bormi' => $count > 0,
            'turlar' => $turlar,
            'mualliflar' => $mualliflarSoni,
            'taboqlar' => $taboqlarSoni,
            'havola' => $havola,
            'route' =>  Str::lower($routeUrl),
            'menu'=>$menu,
        ]);

        $this->info('Kriteriya yaratildi!');
        return 0;
    }
}
