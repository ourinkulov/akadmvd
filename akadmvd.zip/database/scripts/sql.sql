SELECT
    d.user_id,
    SUM(
        CASE
            WHEN t.category_id = 1 THEN 0.30 * d.ball
            WHEN t.category_id = 2 THEN 0.15 * d.ball
            WHEN t.category_id = 3 THEN 0.40 * d.ball
            WHEN t.category_id = 4 THEN 0.10 * d.ball
            ELSE 0
            END
        ) AS ball,
    u.image,
    u.name,
    u.kaf_name,
    u.lavozim
FROM
    yuklamalar AS d
    JOIN
        kriteriyas AS t
    ON
        d.kriteriya_id = t.id
    LEFT JOIN
        users AS u
    ON
    d.user_id = u.id
GROUP BY d.user_id, u.image, u.name, u.kaf_name, u.lavozim
ORDER BY ball DESC
LIMIT 10;
