<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('e_subject_schedules', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('e_subject_schedule_id')->unsigned();
            $table->integer('_curriculum');
            $table->integer('_subject');
            $table->char('_education_year',64);
            $table->char('_semester',64);
            $table->integer('_group');
            $table->char('_training_type',64)->nullable();
            $table->integer('_auditorium')->nullable();
            $table->integer('_subject_topic')->nullable();
            $table->integer('_week')->nullable();
            $table->integer('_employee');
            $table->char('_lesson_pair',64);
            $table->date('lesson_date');
            $table->integer('position')->default(0);
            $table->boolean('active')->default(true);
            $table->jsonb('_translations')->nullable();
            $table->char('additional',2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('e_subject_schedules');
    }
};
