<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(): void
    {
        $roles = [
            'SuperAdmin',
            'headOfOrganization',
            'deputiesOfOrganization',
            'studyDept',
            'scienceDept',
            'organizationDept',
            'headOfFaculty',
            'headOfDept',
            'teacher',
            'worker',
            'operator',
        ];

        foreach ($roles as $role) {
            Role::query()->firstOrCreate(['name' => $role]);
        }
    }
}
