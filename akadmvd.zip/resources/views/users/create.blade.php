@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('nachkaf.alluser')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <h5>Profil rasmini o'zgartirish</h5>
           <hr>
           <form action="{{route('nachkaf.storeuser')}}" method="POST" enctype="multipart/form-data">


                   @csrf

                   <div class="col-md-6 offset-2">




                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">Rasmingiz</label>
                           <input id="image" type="file" class="form-control @error('image') is-invalid @enderror" name="image"  >

                           @error('image')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                   </div>




                   <button class="btn btn-primary" type="submit">Yaratish</button>


           </form>
       </div>

    </div>
@endsection
