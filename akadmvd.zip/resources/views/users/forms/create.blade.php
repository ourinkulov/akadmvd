@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <a href="{{route('kriteriya.index', ['route' => $kriteriya->route])}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-8">
               <div class="row alert-info mt-2"  style="color: #2f2d2e; font-size: 20px; text-align: center">
                   {{ $kriteriya->band }}
               </div>
               <hr>
               <form action="{{ route('kriteriya.store', ['route' => $kriteriya->route]) }}" method="POST" enctype="multipart/form-data">
                   @csrf
                   @if($kriteriya->soat)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Qiymati </label>
                           <input type="number" step="0.1" name="soat" class="form-control @error('soat') is-invalid @enderror" required/>
                           @error('soat')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->mualliflar)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Mualliflar soni </label>
                           <input type="number" name="muallif_soni" class="form-control @error('muallif_soni') is-invalid @enderror" required/>
                           @error('muallif_soni')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->taboqlar)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Toboqlar soni </label>
                           <input type="number" name="taboqlar_soni" class="form-control @error('taboqlar_soni') is-invalid @enderror" required/>
                           @error('taboqlar_soni')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->turlar_bormi)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">
                               Turi
                           </label>
                           <select name="tur_id" id="tur_id" class="form-control @error('tur_id') is-invalid @enderror" required>
                               <option value="">Tanlang</option>
                               @foreach(unserialize($kriteriya->turlar) as $tur)
                                   <option value="{{ $tur['id'] }}">{{ $tur['nomi'] }}</option>
                               @endforeach
                           </select>
                           @error('tur_id')
                           <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                            </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->havola)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Havola </label>
                           <input type="text" name="havola" class="form-control @error('havola') is-invalid @enderror" required/>
                           @error('havola')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($admin == 1)
                       <input type="hidden" name="jarimaball" value="1">
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">
                               Kafedra nomi
                           </label>
                           <select name="kaf_id" id="kafid" class="form-control">
                               <option value="0">Kafedrani tanlang</option>
                               @foreach($kaf as $item)
                                   <option value="{{$item->id}}">{{$item->name}}</option>
                               @endforeach
                           </select>
                       </div>
                       <div class="form-group">
                           <label class="col-sm-6 col-form-label">Professor-o'qituvchi F.I.SH</label>
                           <select name="user_id" id="user_id" class="form-control bg-white"  value="{{ old('fan_id') }}">

                           </select>
                           @error('user_id')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                       <div class="form-group">

                           <input type="hidden" name="ball" value="{{$kriteriya->min_ball}}">
                       </div>
                   @endif

                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">
                           {{ $kriteriya->asoslovchi_xujjatlar }}
                       </label>
                       <input type="file" name="file" class="form-control @error('file') is-invalid @enderror" required/>
                       @error('file')
                       <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
                       @enderror
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Izoh </label>
                       <input type="text" name="comment" class="form-control @error('comment') is-invalid @enderror" max="64"/>
                       @error('comment')
                       <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                       @enderror
                   </div>
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>

           </div>
       </div>
    </div>
@endsection
