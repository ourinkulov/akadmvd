@extends('layouts.app')
@section('content')
{{--  <h1>{{ \Illuminate\Support\Facades\Auth::user()->name }}</h1>--}}
{{--  @if (is_null(\Illuminate\Support\Facades\Auth::user()->image))--}}
{{--      <img src="{{asset('storage/userimage/images.png')}}" class="card-img-top" alt="..." style="height: 267px; !important;">--}}
{{--  @else--}}
{{--      <img src="{{asset('storage/userimage/'.\Illuminate\Support\Facades\Auth::user()->image)}}" class="card-img-top" alt="..." style="height: 267px; width: 260px; !important;">--}}
{{--  @endif--}}

<a href="{{route('users.getallreyting')}}"><button class="btn btn-info">Ortga</button></a>
<div class="row">
    <div class="col-md-2 p-2 ml-4">
        <div class="card shadow p-3 mb-5 bg-white rounded" style="border-radius: 2%; border-color: white">
            @if (is_null(\Illuminate\Support\Facades\Auth::user()->image))
                <img src="{{asset('storage/userimage/images.png')}}" class="card-img-top" alt="..." style="height: 267px; !important;">
            @else
                <img src="{{asset('storage/userimage/'.$user->image)}}" class="card-img-top" alt="..." style="height: 267px; !important;">
            @endif
            <div class="card-body text-center">
                <h5 class="card-title">
                    <strong>{{$user->name}}</strong>
                </h5>
                <h6>{{$user->lavozim}}</h6>
                <div class="container">
                    <div class="row">
{{--                        <div class="col-md-6 text-right">--}}
{{--                            <img src="{{asset('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0hQbEzmtyhO_VNZGC5Yvm8Pu7Obwdg5bnCA&usqp=CAU')}}" width="36px;" alt="">--}}
{{--                        </div>--}}

                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="col-md-4" >
        <div class="card">
            <div class="card-header text-secondary">
                Professor-o'qituvchining faoliyati ko'rsatkichlari radar chart diagrammasi
            </div>
            <div class="card-body">
                <canvas id="radarChart" style="width: 200px;"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-secondary text-center">
                        O'quv yuklamasiga oid ishlar soni:
                    </div>
                    <div class="card-body">

                        <h1>{{$w1}}</h1>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-secondary text-center">
                        O'quv-uslubiy faoliyatga oid ishlar soni:
                    </div>
                    <div class="card-body">

                        <h1>{{$w2}}</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-secondary text-center">
                        Ilmiy faoliyatga oid ishlar soni:
                    </div>
                    <div class="card-body">

                        <h1>{{$w3}}</h1>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-secondary text-center">
                        Jamoat (ustoz-shogirt) oid ishlar soni:
                    </div>
                    <div class="card-body">

                        <h1>{{$w4}}</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
  <hr>
  <div class="row mt-2 m-2">
      <table class="table table-responsive-lg">
          <thead class="bg-white">
          <th>#</th>

              <th>O'qituvchi</th>
              <th>Band</th>






              <th>Turi</th>


              <th>Soni</th>
          <th>Mualliflar soni</th>


              <th>Ilova</th>

          <th>Ilova</th>
          <th>Status</th>
          <th>Izoh</th>
          <th>Ball</th>

{{--              <th>O'zgartirish</th>--}}
{{--              <th>O'chirish</th>--}}

          </thead>
          <tbody>
          @if(!empty($res))
              @foreach($res as $item)
                  <tr>
                      <td>{{ $item->id }}</td>
                      {{--                            @if($admin=4)--}}
                      <td>{{ $item->teacher->name }}</td>
                      <td>{{ $item->kriteriya->band }}</td>
                      {{--                            @endif--}}
                      @if($item->kriteriya->turlar_bormi)
                          <td>{{ unserialize($item->kriteriya->turlar)[intval($item->tur_id) - 1]['nomi'] }}</td>
                      @else
                          <td></td>
                      @endif
                          <td>{{ $item->soat }}</td>
                      <td>{{ $item->muallif_soni }}</td>
                      @if($item->havola)
                          <td><a href="{{ $item->havola }}" target="_blank">{{ Str::limit($item->havola,50) }}</a></td>
                      @else
                          <td></td>
                      @endif
                      <td><a href="{{ asset('storage/'. $item->fayl) }}"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                      <td>
                          @if(!$item->status)
                              <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                          @else
                              <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                          @endif
                      </td>
                      <td>{{ $item->comment }}</td>
                      <td>{{ $item->ball }}</td>
{{--                          <th>--}}
{{--                              <a href="{{ route('kriteriya.edit',  [$item->route, $item->id]) }}">--}}
{{--                                  <button class="btn btn-primary btn-sm">O'zgartirish</button>--}}
{{--                              </a>--}}
{{--                          </th>--}}
{{--                          <th>--}}
{{--                              <form action="{{ route('kriteriya.destroy',  [$item->route, $item->id]) }}" method="post">--}}
{{--                                  @csrf--}}
{{--                                  @method('DELETE')--}}
{{--                                  <button class="btn btn-danger btn-sm">O'chirish</button>--}}
{{--                              </form>--}}
{{--                          </th>--}}
                  </tr>
              @endforeach
          @endif

          </tbody>
      </table>
  </div>
  <hr>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const plugin = {
        id: 'customCanvasBackgroundColor',
        beforeDraw: (chart, args, options) => {
            const {ctx} = chart;
            ctx.save();
            ctx.globalCompositeOperation = 'destination-over';
            ctx.fillStyle = options.color || '#99ffff';
            ctx.fillRect(0, 0, chart.width, chart.height);
            ctx.restore();
        }
    };
    var ctx = document.getElementById('radarChart').getContext('2d');
    var myRadarChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ["O'quv yuklamasi", "O'quv-uslubiy ishlar", 'ilmiy ishlar', 'jamoat (ustoz-shogird)'],
            datasets: [{
                label: 'Ballar koifisenti',
                data:  @json($chart),
                backgroundColor: 'rgba(235,54,145,0.2)',
                borderColor: 'rgb(240,65,117)',
                borderWidth: 1
            }]
        },
        options: {
            scale: {
                min: 0,
                max: 1,
                stepSize:1,
                ticks: {
                    suggestedMin: 0,
                    suggestedMax: 1,
                    stepSize: 0.1,
                    negative: false
                }
            },

        }
    });
</script>

@endsection('content')
