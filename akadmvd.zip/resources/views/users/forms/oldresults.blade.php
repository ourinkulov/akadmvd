@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="col-md-7 offset-4">
            <div class="row">

                    <div class="col-md-3">
                        <form action="{{route('users.getoldresults')}}" method="POST">
                            @csrf
                        <select name="uy_id" id="" class="form-control">
                            <option value="">Tanlang</option>
                            @foreach($uys as $item)
                                <option value="{{$item->id}}">{{$item->uy}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-primary" type="submit" >Tanlash </button></form>
                    </div>

            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
                @if(!empty($userBall))
                    <div class="card-body bg-success text-white bold">
                        <h4>O'quv yilidagi reytingi: {{$userReyting}}</h4>
                        <h4>O'quv yilida to'plangan ball: {{$userBall}}</h4>
                    </div>
                @endif

                <table class="table table-responsive-lg table-hovered" width="100%">
                    <tr>
                        <td>ID</td>
                        <td>Band</td>
                        <td>Izoh</td>
                        <td>Olingan ball</td>
                        <td>Fayl</td>
                    </tr>
                    @if(!empty($oldresults))
                        @foreach($oldresults as $item)
                            <tr class="bg-white">
                                <td>{{$item->id}}</td>
                                <td>{{$item->band}}</td>
                                <td>{{$item->comment}}</td>
                                <td>{{$item->ball}}</td>
                                <td>
                                    <a href="{{asset('storage/'.$item->fayl)}}">Ilova</a>
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </table>
            </div>
        </div>
    </div>
@endsection
