@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <table>
                    <tr>
                        <td>Ilmiy daraja diplom</td>
                    </tr>
                    @foreach($data as $item)
                        <tr>
                            <td><a href="{{asset('storage/ilmiydaraja/'.$item->file1)}}">Ilmiy daraja diplomi</a></td>
                        </tr>
                    @endforeach
                </table>
            </div>
            <div class="col-md-6">
                <table>
                    <tr>
                        <td>Ilmiy daraja diplom</td>
                    </tr>
                    @foreach($data2 as $item)
                        <tr>
                            <td><a href="{{asset('storage/ilmiyunvon/'.$item->file2)}}">Ilmiy unvon diplomi</a></td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </div>
@endsection
