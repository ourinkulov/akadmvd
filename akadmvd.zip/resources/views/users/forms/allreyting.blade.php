@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <a href="{{route('users.dashboard')}}"><button class="btn btn-info">Ortga</button></a>
            <div class="col">
                <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead class="text-center " style="color: white; font-size: 16px; background-color: rgb(70,117,133)">
                    <th>Reyting</th>
                    <th>-</th>
                    <th>F.I.O</th>
                    <th>Lavozim</th>
                    <th>Kafedra</th>
                    <th>Ball</th>
                    </thead>
                    <tbody>
                    @foreach($allr as $k=>$item)
                        @if($item->user_id == Auth::user()->getAuthIdentifier())
                            <tr class="bg-info text-white">
                                <td>{{++$k}}</td>
                                {{--                            <td><a href="{{route('admin.adminuserprofile2',$item->user_id)}}"><img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;"></a></td>--}}
                                <td>
                                    <a href="{{route('users.getOneUserResultforusers',$item->user_id)}}">
                                        <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                    </a>
                                </td>
                                <td>{{$item->name}}</td>
                                <td>{{$item->lavozim}}</td>
                                <td>{{$item->kaf_name}}</td>
                                <td><strong>{{$item->ball}}</strong></td>
                            </tr>

                        @else
                        <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <a href="{{route('users.getOneUserResultforusers',$item->user_id)}}">
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </a>
                            </td>
                            <td>{{$item->name}}</td>
                            <td>{{$item->lavozim}}</td>
                            <td>{{$item->kaf_name}}</td>
                            <td><strong>{{$item->ball}}</strong></td>
                        </tr>
                    @endif
                    @endforeach
                </table>
            </div>
        </div>
    </div>
@endsection
