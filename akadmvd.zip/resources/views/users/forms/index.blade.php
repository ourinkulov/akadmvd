@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row alert-info"  style="color: #2f2d2e; font-size: 16px; text-align: center">
            <h5>
                {{ $kriteriya->band }}
            </h5>
            <p>
                {{ $kriteriya->xujjatlar }}
            </p>
            <p>
                {{ $kriteriya->izox }}
            </p>
        </div>
        <div class="row">
            @if (!$admin && $kriteriya->category_id<=4)

                    @if( $kriteriya->id == 1 ||$kriteriya->id == 9 || $kriteriya->id == 8 )
                        <h5 class="text-danger">Ushbu kriteriyalar uchun ma'lumotlar HEMIS tizimidan olinadi!</h5>
                    @else
                    <a href="{{ route('kriteriya.create', ['route' => $kriteriya->route]) }}">
                        <button class="btn btn-info">Yaratish</button>
                    </a>
                    @endif


            @endif
            @if ( $admin && $kriteriya->category_id>4 )
                    <a href="{{ route('kriteriya.create', ['route' => $kriteriya->route]) }}">
                        <button class="btn btn-info">Yaratish</button>
                    </a>
            @endif
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                @if($admin)
                    <th>O'qituvchi</th>
                @endif
                @if($kriteriya->mualliflar)
                <th>Mualliflar soni</th>
                @endif

                @if($kriteriya->turlar_bormi)
                <th>Turi</th>
                @endif
                @if(@$kriteriya->soat)
                <th>Soni</th>
                @endif
                @if($kriteriya->havola)
                    <th>Ilova</th>
                @endif
                <th>Ilova</th>
                <th>Status</th>
                <th>Izoh</th>
                <th>Ball</th>
                <th>Ball</th>
                <th>Sana</th>
                @if($admin)
                    <th>O'zgartirish</th>
                    <th>O'chirish</th>
                @endif
                </thead>
                <tbody>
                @if(!empty($model))
                    @foreach($model as $m)
                        <tr>
                            <td>{{ $m->id }}</td>
{{--                            @if(!$k5)--}}
                                <th>{{ $m->name }}</th>
{{--                            @endif--}}
                            @if($kriteriya->mualliflar)
                                <td>{{ $m->muallif_soni }}</td>
                            @endif
                            @if($kriteriya->turlar_bormi)
                                <td>{{ Str::limit(unserialize($m->kriteriya->turlar)[intval($m->tur_id) - 1]['nomi'],50) }}</td>
                            @endif
                            @if(@$kriteriya->soat)
                                <td>{{ $m->soat }}</td>
                            @endif
                            @if($kriteriya->havola)
                                <td><a href="{{ $m->havola }}" target="_blank"><i class="fa fa-link">  Havola</i></a></td>
                            @endif
                            @if($kriteriya->id == 9)
                            @else
                                <td><a href="{{ asset('storage/'. $m->fayl) }}"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                            @endif
                            <td>
                                @if(!$m->status)
                                    <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                                @else
                                    <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                                @endif
                            </td>
                            <td>{{ Str::limit($m->comment,30) }}</td>
                            <td>{{ $m->ball }}</td>
                            <td>{{ $m->created_at }}</td>

                            @if($admin)
                             @if($kriteriya->id == 9)
                             @else

                                <th>
                                    <a href="{{ route('kriteriya.edit',  [$m->route, $m->id]) }}">
                                        <button class="btn btn-primary btn-sm">O'zgartirish</button>
                                    </a>
{{--                                    {{$kriteriya->id}}--}}
                                </th>
                                <th>
                                    <form action="{{ route('kriteriya.destroy',  [$m->route, $m->id]) }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-danger btn-sm">O'chirish</button>
                                    </form>
                                </th>
                                <td>


                             @endif
                                </td>
                            @endif

                        </tr>
                    @endforeach
                @endif

                </tbody>
            </table>
        </div>
    </div>
@endsection
