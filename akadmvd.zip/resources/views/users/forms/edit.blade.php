@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <a href="{{route('kriteriya.index', ['route' => $kriteriya->route])}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-8">
               <div class="row alert-info mt-2"  style="color: #2f2d2e; font-size: 20px; text-align: center">
                   {{ $kriteriya->band }}
               </div>
               <hr>
               <form action="{{ route('kriteriya.update', ['route' => $kriteriya->route, 'id' => $model->id ]) }}" method="POST" enctype="multipart/form-data">
                   @csrf
                   @if($kriteriya->soat)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Qiymati </label>
                           <input type="number" step="0.1" value="{{ $model->soat }}" name="soat" class="form-control @error('soat') is-invalid @enderror" required/>
                           @error('soat')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif



               @if($kriteriya->mualliflar)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Mualliflar soni </label>
                           <input type="number" value="{{ $model->muallif_soni }}" name="muallif_soni" id="muallif_soni" class="form-control @error('muallif_soni') is-invalid @enderror" required/>
                           @error('muallif_soni')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->taboqlar)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Toboqlar soni </label>
                           <input type="number" value="{{ $model->taboqlar_soni }}" name="taboqlar_soni" id="taboqlar_soni" class="form-control @error('taboqlar_soni') is-invalid @enderror" required/>
                           @error('taboqlar_soni')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->turlar_bormi)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">
                               Turi
                           </label>
                           <select value="{{ $model->tur_id }}" name="tur_id" id="tur_id" class="form-control @error('tur_id') is-invalid @enderror" required>
                               <option value="">Tanlang</option>
                               @foreach(unserialize($kriteriya->turlar) as $tur)
                                   <option value="{{ $tur['id'] }}"{{ $tur['id'] == $model->tur_id ? 'selected' : ''}} ball="{{ $tur['ball'] }}" >{{ $tur['nomi'] . ' ('.$tur['ball'].')' }}</option>
                               @endforeach
                           </select>
                           @error('tur_id')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif

                   @if($kriteriya->havola)
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info"> Havola </label>
                           <input type="text" value="{{ $model->havola }}" name="havola" class="form-control @error('havola') is-invalid @enderror" required/>
                           @error('havola')
                           <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                           @enderror
                       </div>
                   @endif
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Izoh </label>
                       <input type="text" value="{{ Str::limit($model->comment,20) }}" name="comment" class="form-control @error('comment') is-invalid @enderror" max="64"/>
                       @error('comment')
                       <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                       @enderror
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Ball </label>
                       <input type="text" value="{{ $kriteriya->min_ball }}" name="ball" id="ball" class="form-control @error('ball') is-invalid @enderror" max="64"/>
                       @error('ball')
                       <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
                       @enderror
                   </div>
                   <button class="btn btn-primary" name="accept" value="1" type="submit">Tasdiqlash</button>
                   <button class="btn btn-danger" name="accept" value="0" type="submit">Qayta yuborish</button>
               </form>

           </div>
       </div>
    </div>
    <script>
        var turSelect = document.getElementById("tur_id");
        turSelect.addEventListener("change", function() {
            var selectedOption = turSelect.options[turSelect.selectedIndex];
            var ballValue = selectedOption.getAttribute("ball");
            if (ballValue !== null) {

                var taboqlar_soni = document.getElementById("taboqlar_soni");

                if (taboqlar_soni !== null) {
                    ballValue *= taboqlar_soni.value;
                }

                var muallif_soni = document.getElementById("muallif_soni");

                if (muallif_soni !== null) {
                    ballValue /= muallif_soni.value;
                }

                var ballInput = document.getElementById("ball");
                ballInput.value = ballValue;

            }
        });
    </script>

@endsection
