@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Eng yaxshi professor - o'qituvchilar</h6>
                    </div>
                    <div class="card-body">

                        <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead >

                            <th>Reyting</th>
                            <th>-</th>
                            {{--                                   <th>Rasm</th>--}}
                            <th>F.I.O</th>
                            <th>Lavozim</th>
                            <th>Kafedra</th>
                            <th>Ball</th>

                            </thead>
                            <tbody>
                            @foreach($allr as $k=>$item)
                                @if($item->id==\Illuminate\Support\Facades\Auth::user()->getAuthIdentifier())
                                    <tr class="bg-primary text-white">
                                        <td style="font-size: 48px; font-weight: bolder">{{++$k}}</td>
                                        <td><a href="{{url('/user/showall',$item->id)}}"><img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;"></a></td>
                                        <td><a href="{{url('/user/showall',$item->id)}}">{{$item->name}}</a></td>
                                        <td>{{$item->lavozim}}</td>
                                        <td>{{$item->kaf_name}}</td>
                                        <td style="font-size: 48px; font-weight: bolder">{{$item->ball}}</td>
                                    </tr>
                                @else
                                    <tr >
                                        <td>{{++$k}}</td>
                                        <td><a href="{{url('/user/showall',$item->id)}}"><img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;"></a></td>
                                        <td style="text-decoration: none"><a href="{{url('/user/showall',$item->id)}}">{{$item->name}}</a></td>
                                        <td>{{$item->lavozim}}</td>
                                        <td>{{$item->kaf_name}}</td>
                                        <td>{{$item->ball}}</td>
                                    </tr>
                                @endif
                            @endforeach
                            </tbody>


                            {{--                                <tfoot>--}}
                            {{--                                <tr>--}}
                            {{--                                    <th>Reyting</th>--}}
                            {{--                                    --}}{{--                                   <th>Rasm</th>--}}
                            {{--                                    <th>F.I.O</th>--}}
                            {{--                                     <th>Lavozim</th> --}}
                            {{--                                    <th>Kafedra</th>--}}
                            {{--                                    <th>Ball</th>--}}

                            {{--                                </tr>--}}
                            {{--                                </tfoot>--}}
                            <tbody>
                            {{--                                @foreach ($teacher10 as $k)--}}
                            {{--                                    <tr>--}}
                            {{--                                        <td>{{++$i}}</td>--}}
                            {{--                                        --}}{{--                                       <td class="text-center"><img src="storage/images/{{$k->image}}" width="90px" height="90px" alt="" style="border-radius: 50%;"  > </td>--}}
                            {{--                                        <td><a href="{{route('admin.getteacherprofil',$k->id)}}">{{$k->name}}</a></td>--}}
                            {{--                                        --}}{{-- <td>{{$k->lavozim}}</td> --}}
                            {{--                                        <td>{{$k->kname}}</td>--}}
                            {{--                                        <td>{{number_format($k->sball,1)}}</td>--}}

                            {{--                                    </tr>--}}
                            {{--                                @endforeach--}}
                            </tbody>
                        </table>


                    </div>
                </div>
            </div>

            {{--            <div class="col-lg-4 col-md-4">--}}
            {{--                <div class="card shadow mb-4">--}}
            {{--                    <div class="card-header py-3">--}}
            {{--                        <h6 class="m-0 font-weight-bold text-primary">Eng faol kafedralar</h6>--}}
            {{--                    </div>--}}
            {{--                    <div class="card-body">--}}

            {{--                        <table class="table  table-hover table-responsive-lg" id="dataTable" width="100%" cellspacing="0">--}}
            {{--                            <thead>--}}
            {{--                            <tr>--}}
            {{--                                <th>Reyting</th>--}}
            {{--                                <th>Kafedra nomi</th>--}}
            {{--                                <th>Ball</th>--}}

            {{--                            </tr>--}}
            {{--                            </thead>--}}
            {{--                            @foreach($kafedra_reyting as $item=>$k)--}}
            {{--                                <tr>--}}
            {{--                                    <td>{{++$item}}</td>--}}
            {{--                                    <td>{{$k->kafName}}</td>--}}
            {{--                                    <td>{{$k->ball}}</td>--}}
            {{--                                </tr>--}}
            {{--                            @endforeach--}}
            {{--                            <tfoot>--}}
            {{--                            <tr>--}}
            {{--                                <th>Reyting</th>--}}
            {{--                                <th>Kafedra nomi</th>--}}
            {{--                                <th>Ball</th>--}}
            {{--                            </tr>--}}
            {{--                            </tfoot>--}}
            {{--                            <tbody>--}}
            {{--                            --}}{{--                                @foreach ($kaff as $kaf)--}}
            {{--                            --}}{{--                                    <tr>--}}
            {{--                            --}}{{--                                        <td>{{++$g}}</td>--}}
            {{--                            --}}{{--                                        <td>{{$kaf->kname}}</td>--}}
            {{--                            --}}{{--                                        <td>{{number_format($kaf->ball,1)}}</td>--}}
            {{--                            --}}{{--                                    </tr>--}}
            {{--                            --}}{{--                                @endforeach--}}
            {{--                            </tbody>--}}
            {{--                        </table>--}}

            {{--                    </div>--}}
            {{--                </div>--}}
            {{--            </div>--}}
        </div>
    </div>
@endsection
