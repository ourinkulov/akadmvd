@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('users.usermajmua')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Yangi ma'ruza fondlari, maslalar toplami, amaliy-uslubiy qo'llanmalar yaratish</h5>
               <hr>
               <form action="{{route('users.storeusermajmua')}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                        <input type="text" name="title"  class="form-control"/>
                    </div>

                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Yaratilgan sana</label>
                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getTuriName()">
                           <option value="0">Tanlang</option>
                           <option value="1">O'zbek yoki rus tilida, shuningdek chet tili mutaxassisliklari bo'yicha</option>
                           <option value="2">Xorijiy tilda</option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF shaklda | Nashrga tavsiya etish hujjati)</label>
                       <input type="file" name="file"  class="form-control"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Havola (https://www.google.com/webhp?hl=uz)</label>
                       <input type="text" name="havola"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
