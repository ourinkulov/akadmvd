@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>Elektron platformaga o'quv yuklamasida nazarda tutilganidan tashqari mustaqil ishlab chiqilgan va o'quv jarayonidan foydalanilayotgan o'quv-uslubiy majmualar</h5>
        <div class="row">
            <a href="{{route('users.createusermajmua')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Yaratilgan vaqti</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Havola</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($majmua as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>
                        <td>{{$item->turi_name}}</td>

                        <td><a href="{{asset('storage/majmua/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td><a href="{{$item->havola}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
