@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('users.useratestat')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Bitiruv (malakaviy) ishi himoyasi bо‘yicha yakuniy davlat attestatsiyasi komissiyasida va Tayanch doktorant (PhD), doktorant va mustaqil izlanuvchilar tanlovi komissiyasida va malaka imtihonida ishtirok etish
               </h5>
               <hr>
               <form action="{{route('users.storeatestat')}}" method="POST" enctype="multipart/form-data">
                   @csrf

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Kursant/Tinlovchilar soni </label>--}}
{{--                       <input type="number" name="soni" min="1" max="5" class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Darajasi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getRaxbarName()">
                           <option value="0">Tanlang</option>
                           <option value="1">Bitiruv (malakaviy) diplom ishi komissiyasida ishtirok etish</option>
                           <option value="2">Magistrlik dissertatsiyasi komissiyasida ishtirok etish</option>
                           <option value="3">Tayanch doktorant (PhD), doktorant va mustaqil izlanuvchilar tanlovi komissiyasida va malaka imtihonida ishtirok etish</option>


                       </select>
                   </div>
                   <div class="form-group">
                                              <label for="" class="bg-white p-2 border-bottom-info">Ilova (Buyruqning
                                                  skaneri:
                                                  Rasm | PDF)</label>
                                              <input type="file" name="file"  class="form-control"/>
                   </div>



                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
