@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('users.usertil')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Xorijiy tillarni bilish darajasini baholovchi milliy va xalqaro tan olingan sertifikatlarni qо‘lga kiritganlik uchun</h5>
               <hr>
               <form action="{{route('users.storetil')}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Til nomi</label>
                        <input type="text" name="title" class="form-control">
                    </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular (Taboq ) soni</label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Darajasi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getTilName()">
                           <option value=" ">Tanlang</option>
                           <option value="1">IELTS darajasi 8.5 - 9.0 bо‘lganda </option>
                           <option value="2">IELTS darajasi 7.0 - 8.0 bо‘lganda</option>
                           <option value="3">IELTS darajasi 5.5 - 6.5 bо‘lganda </option>
                           <option value="4">IELTS darajasi 4.0 - 5.0 bо‘lganda </option>
                           <option value="5">IELTS darajasi 3.0 bо‘lganda </option>
                           <option value="6">IELTS darajasi 2.0  bо‘lganda </option>
                           <option value="7">CEFR darajasi S 2 bо‘lganda </option>
                           <option value="8">CEFR darajasi S 1 bо‘lganda</option>
                           <option value="9">CEFR darajasi V 2 bо‘lganda </option>
                           <option value="10">CEFR darajasi V 1 bо‘lganda</option>
                           <option value="11">CEFR darajasi A 2 bо‘lganda</option>
                           <option value="12">CEFR darajasi A 1 bо‘lganda</option>
                           <option value="13">Xalqaro IT-sertifikat </option>
                       </select>
                   </div>
                                      <div class="form-group">
                                          <label for="" class="bg-white p-2 border-bottom-info">Dan amal qiladi</label>
                                          <input type="date" name="sana1" placeholder="Amal qilish boshlanish sanasi" class="form-control"/>
                                      </div>
                                      <div class="form-group">
                                          <label for="" class="bg-white p-2 border-bottom-info">Gacha amal qiladi</label>
                                          <input type="date" name="sana2" placeholder="Amal qilish tugash sanasi" class="form-control"/>
                                      </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF yoki rasm shaklda | Asos bо‘ladigan hujjatning skaneri)</label>
                       <input type="file" name="file"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
