@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy unvonga ega bо‘lish</h5>
        <div class="row">
            <a href="{{route('users.createuseriyunvon')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($ilmiyunvon as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>

                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/ilmiyunvon/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
