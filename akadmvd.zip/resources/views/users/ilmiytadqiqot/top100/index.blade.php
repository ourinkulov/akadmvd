@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>Oliy ta’lim muassasalarning birinchi mingtalik yoki fan yо‘nalishlari bо‘yicha birinchi yuztalik xalqaro  reytinglarga kirgan OTMning onlayn ta’lim platformalariga ma’ruza joylashtirish yoki sayyor shaklda ma’ruza о‘tkazish</h5>
        <div class="row">
            <a href="{{route('users.createtop100')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>OTM Nomlanishi</th>
                <th>Sana</th>
                <th>Ilova (Havola)</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($top100 as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>

                        <td><a href="{{asset('storage/top100/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
