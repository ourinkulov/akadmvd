@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>О‘quv jarayonida amaliy qо‘llaniladigan intellektual faoliyat natijasi hamda о‘rnatilgan tartibda rо‘yxatdan о‘tkazilgan elektron dastur, platforma yaratish</h5>
        <div class="row">
            <a href="{{route('users.createelektronplatforma')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Platforma nomlanishi</th>
                <th>Yaratilgan sana</th>

                <th>Ilova (Havola)</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($elektronplatforma as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>

                        <td><a href="{{asset('storage/elektronplatforma/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
