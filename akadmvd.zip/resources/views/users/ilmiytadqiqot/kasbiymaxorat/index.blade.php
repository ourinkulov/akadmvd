@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>Kasbiy mahorat (pedagogik faoliyat,
            ilmiy-tadqiqot ishi, sport musobaqalari) tanlovi (konkurs)da faxrli о‘rinlarni egallaganligi
        </h5>
        <div class="row">
            <a href="{{route('users.createkasbiymaxorat')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Mavzusi</th>
                <th>Natija</th>
                <th>Ilova</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                    @foreach($kasbiymaxorat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/kasbiymaxorat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
