@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>Ma’ruza va boshqa о‘kuv   mashg‘ulotlarini pedagogik nazorat qilish va  О‘quv  mashg‘ulotlariga о‘zaro  qatnashish, yozma shaklda taqriz yozish majburiyati bilan</h5>
        <div class="row">
            <a href="{{route('users.createuserpednazorat')}}"><button class="btn btn-info">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Soni</th>
                <th>Turi</th>

                <th>Yaratilgan vaqti</th>
                <th>Ilova</th>
                <th>Status</th>

                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($pednazorat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->soni}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->sana}}</td>
                        <td><a href="{{asset('storage/pednazorat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
