@extends('layouts.userapp')
@section('content')
    <div class="container">
        <div class="row">
            <a href="{{route('users.dashboard')}}"><button class="btn btn-info">Ortga</button></a>
            <hr class="mt-4">
        </div>
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <div class="row">
            <form action="{{route('users.changeimage',\Illuminate\Support\Facades\Auth::user()->getAuthIdentifier())}}" enctype="multipart/form-data" method="POST">
                @csrf
                <div class="form-group">
                    <label for="">Profil rasmingizni tanlang</label>
                    <input type="file" name="image" class="form-control">
                </div>
                <hr>
                <button class="btn btn-primary" type="submit">Saqlash</button>
            </form>
        </div>
    </div>
@endsection
