<?php

class Graph {
    private $graph;
    private $vertices;

    public function __construct($vertices) {
        $this->vertices = $vertices;
        $this->graph = array_fill(0, $vertices, array_fill(0, $vertices, INF));
    }

    public function addEdge($start, $end, $weight) {
        $this->graph[$start][$end] = $weight;
        $this->graph[$end][$start] = $weight; // если граф неориентированный
    }

    public function dijkstra($src) {
        $dist = array_fill(0, $this->vertices, INF);
        $dist[$src] = 0;

        $visited = array_fill(0, $this->vertices, false);

        for ($count = 0; $count < $this->vertices - 1; $count++) {
            $u = $this->minDistance($dist, $visited);
            $visited[$u] = true;

            for ($v = 0; $v < $this->vertices; $v++) {
                if (!$visited[$v] && $this->graph[$u][$v] != INF &&
                    $dist[$u] != INF && $dist[$u] + $this->graph[$u][$v] < $dist[$v]) {
                    $dist[$v] = $dist[$u] + $this->graph[$u][$v];
                }
            }
        }

        $this->printSolution($dist);
    }

    private function minDistance($dist, $visited) {
        $min = INF;
        $min_index = -1;

        for ($v = 0; $v < $this->vertices; $v++) {
            if ($visited[$v] == false && $dist[$v] <= $min) {
                $min = $dist[$v];
                $min_index = $v;
            }
        }

        return $min_index;
    }

    private function printSolution($dist) {
        echo "Vertex \t Distance from Source\n";
        for ($i = 0; $i < $this->vertices; $i++) {
            echo $i . " \t\t " . $dist[$i] . "\n";
        }
    }
}

// Пример использования
$g = new Graph(9);
$g->addEdge(0, 3, 4);
$g->addEdge("Jazo",  "Intizom", 8);
$g->addEdge(1, 2, 8);
$g->addEdge(1, 7, 11);
$g->addEdge(2, 3, 7);
$g->addEdge(2, 8, 2);
$g->addEdge(2, 5, 4);
$g->addEdge(3, 4, 9);
$g->addEdge(3, 5, 14);
$g->addEdge(4, 5, 10);
$g->addEdge(5, 6, 2);
$g->addEdge(6, 7, 1);
$g->addEdge(6, 8, 6);
$g->addEdge(7, 8, 7);

$g->dijkstra(0);
?>
