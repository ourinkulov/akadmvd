@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('users.usermetodikmat')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Metodik materiallarni tayyorlash  </h5>
               <hr>
               <form action="{{route('users.storeusermetodikmat')}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                        <input type="text" name="title"  class="form-control"/>
                    </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular (Taboq ) soni</label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Yaratilgan sana</label>
                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getMetodikmatTuriName()">
                           <option value="0">Tanlang</option>
                           <option value="1">Oraliq nazoratlar uchun</option>
                           <option value="2">Yakuniy nazoratlar uchun</option>
                           <option value="3">Yakuniy davlat attestatsiyalari uchun</option>
                           <option value="4">Tayanch doktorant va mustaqil izlanuvchilar tanlovi uchun </option>
                           <option value="5">Bazaviy amaliyot, stajirovka (amaliyot) bо‘yicha yangi metodik material </option>
                           <option value="6">Bazaviy amaliyot, stajirovka (amaliyot) bо‘yicha qayta ishlash uchun metodik material</option>
                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF shaklda | Ishlanmaning skaneri)</label>
                       <input type="file" name="file"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
