@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
       <div class="row">
           <div class="col-md-6">
               <h5>Darslik yaratish</h5>
               <hr>
               <a href="{{route('users.darslik')}}"><button class="btn btn-info">Ortga</button></a>
               <form action="{{route('users.storeuserdarsliks')}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Darslik nomi</label>
                        <input type="text" name="title"  class="form-control"/>
                    </div>
                   <div class="form-group">
                       <label for="">Darslik turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getUserTuriName()">
                           <option value="0">Tanlang</option>
                           <option value="1">Yangi darslik</option>
                           <option value="2">Yangi o'quv-qo'llanma</option>
                           <option value="3">Qayta nashr etilgan darslik</option>
                           <option value="4">Qayta nashr etilgan o'quv-qo'llanma</option>
                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Darslik yaratilgan sana</label>
                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Mualliflar soni</label>
                       <input type="number" name="muallif_soni"  class="form-control"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni <i>(1 bosma taboq 16 bet)</i></label>
                       <input type="text" name="taboq"  class="form-control"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF shaklda)</label>
                       <input type="file" name="file"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
