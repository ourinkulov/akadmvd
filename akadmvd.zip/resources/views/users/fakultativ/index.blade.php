@extends('layouts.userapp')
@section('content')
    <div class="container-fluid">
        <h5>
            1.1. band - Professor-o'qituvchining o'quv yuklamasini bajarganligi.
            <p style="color: #ee3838">
                O'quv yuklamalar xar o'quv yili uchun professor-o'qituvchilar tomonidan tuziladigan hamda o'quv ishlari bo'yicha o'rinbosar (fakultet boshlig'i) tomonidan tasdiqlanadigan o'quv-yili bo'yicha professor-o'qituvchining shaxsiy rejalari asosida aniqlanadi.
                </br>O'quv yuklamasi meyori to'liq bajarilganda - <strong>150 ball</strong> beriladi. Yuklama ortib ketganda, qo'shimcha har 100 soat uchun 10 baldan qo'shiladi.
                <br>Maksimal ball - <strong> {{ $maxBall }} ball</strong>
            </p>
        </h5>
        <div class="row">
            @if(190 > $maxBall)
                <h5><strong>Tabriklaymiz, Siz ushbu band bo'yicha maksimal {{ $maxBall }} ball to'plab bo'ldingiz </strong><i class="fa fa-thumbs-up "></i> </h5>
            @else
                <a href="{{route('users.createuquvmashgulot')}}"><button class="btn btn-info">Yaratish</button></a>
            @endif
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Soat</th>
                <th>Ilova</th>
                <th>Status</th>
                <th>Ball</th>
                </thead>
                <tbody>
                @foreach($model as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->soni}}</td>
                        <td><a href="{{asset('storage/uquvmashgulot/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <x-status />
                        <td>
                            {{$item->ball}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
