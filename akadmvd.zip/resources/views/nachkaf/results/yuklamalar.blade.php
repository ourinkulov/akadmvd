@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
        <h5 class="bg-white p-3 text-center " style="border-radius: 10%">{{\Illuminate\Support\Facades\Auth::user()->kaf_name}}</h5>
        <div class="row">
            <a href="{{route('nachkaf.dashboard')}}"><button class="btn btn-info">Ortga</button></a>
        </div>
        <h4 class="text-center">{{$kriteriyaName->band}}</h4>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>F.I.O</th>
                <th>Soat</th>
                <th>Ball</th>
                <th>Status</th>
                </thead>
                <tbody>
                @foreach($res as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->teacher->name}}</td>
                        <td>{{$item->soat}}</td>
                        <td>{{$item->ball}}</td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-success">Tasdiqlangan</button>
                            @elseif($item->status == 0)
                                <button class="btn btn-warning">Tasdiqlanmagan</button>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
