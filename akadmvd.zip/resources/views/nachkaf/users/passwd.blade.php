@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('nachkaf.alluser')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-12">
            <h5>Ma'lumotlarni yangilash -   {{$user->name}}</h5>
           <hr>
           <form action="{{route('nachkaf.changepasswd',$user->id)}}" method="POST" enctype="multipart/form-data">
               @csrf
               @method('POST')
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Yangi parolni kiriting</label>
                            <input id="password" type="password" class="form-control" name="password" value="{{ old('password') }}" required autocomplete="password" autofocus placeholder="Kamida 8 ta belgi va harflardan iborat bo'lishi lozim ...">

                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                   </div>
                   <button class="btn btn-primary" type="submit">Tahrirlash</button>
           </form>
           </div>
           <div class="col-md-6">
            
           <hr>
           <form action="{{route('nachkaf.changepasswd',$user->id)}}" method="POST" enctype="multipart/form-data">
               @csrf
               @method('POST')
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Ish stavkasini yangilash</label>
                            <div class="form-group">
                                <label for="">Ish stavkasi</label>
                                <select name="stavka_id" id="stavka_id" class="form-control">
                                    <option>Tanlang</option>
                                    <option value="1">1 stavka</option>
                                    <option value="2">0.5 stavka</option>
                                    <option value="3">0.25 stavka</option>
                                    <option value="4">Soatbay</option>                                
                                </select>
                            </div>

                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                   </div>
                   <button class="btn btn-primary" type="submit" name="action" value="stavka">Tahrirlash</button>
           </form>
           </div>
       </div>
    </div>
@endsection
