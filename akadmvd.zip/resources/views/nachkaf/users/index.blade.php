@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
        <h5 class="bg-white p-3 text-center " style="border-radius: 10%">{{\Illuminate\Support\Facades\Auth::user()->kaf_name}}</h5>
        <div class="row">
            <a href="{{route('nachkaf.adduser')}}"><button class="btn btn-info">Profesor-o'qituvchi qo'shish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg text-center">
                <thead class="bg-white">
                <th>#</th>
                <th>Fotosurat</th>
                <th>F.I.O</th>
                <th>Lavozim</th>
                <th>Login</th>
                <th>Identifikator</th>
                <th>Parol</th>
                <th>Yaratilgan vaqti</th>
                <th>Parolni yangilash</th>
                <th>Boshqa kafedraga o'tkazish</th>
                </thead>
                <tbody>
                @foreach($users as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td><img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="128" height="128" style="border-radius: 50%"></td>
                        <td>{{$item->name}}</td>
                        <td>{{$item->lavozim_name}}</td>
                        <td>{{$item->email}}</td>
                        <td>{{$item->passport_pin}}</td>
                        <td>{{$item->pwd}}</td>
                        <td>{{$item->created_at}}</td>
                        <td><a href="{{route('nachkaf.passwd',$item->id)}}">Parol va stavkani o'zgartirish</a></td>
                        <td>
                            <form action="{{ route('nachkaf.transfer', $item->id) }}" method="post">
                                @csrf
                                <select name="kafedra_id" id="kafedra_id" class="form-control">
                                    <option value="">Tanlang</option>
                                    @foreach($kafedras as $kafedra)
                                        <option value="{{ $kafedra->id }}">{{ $kafedra->name }}</option>
                                    @endforeach
                                </select>
                                <button type="submit"  class="bg-primary text-white form-control">O'tkazish</button>
                            </form>


                        </td>
{{--                        <td><a href="{{route('nachkaf.changestatus',$item->id)}}" style="color: red">O`qituvchini tizimdan o`chirish</a></td>--}}
{{--                        <td>{{$item->sana}}</td>--}}
{{--                        <td><a href="{{asset('storage/pednazorat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>--}}
{{--                        <td>--}}
{{--                            <a href="{{route('admin.editadminpednazorat',$item->id)}}"><i class="fa fa-edit"></i></a>--}}
{{--                        </td>--}}
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
