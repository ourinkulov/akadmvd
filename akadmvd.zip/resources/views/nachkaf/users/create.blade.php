@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('nachkaf.alluser')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <h5>Professor-o'qituvchi yaratish</h5>
           <hr>
           @if($errors->any())
               {{ implode('', $errors->all('<div>:message</div>')) }}
           @endif
           <form action="{{route('nachkaf.storeuser')}}" method="POST" enctype="multipart/form-data">


                   @csrf
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Professor-o'qituvchi PNFL</label>
                            <input id="pnfl" type="text" class="form-control" name="pnfl" value="{{ old('pnfl') }}" required autocomplete="pnfl" autofocus>

                            @error('pnfl')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">F.I.SH</label>
                            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                            @error('name')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Lavozimi</label>
                            <select name="lavozim_id" id="lavozim_id" class="form-control" onchange="getUserName()">
                                <option>Tanlang</option>
                                <option value="1">Kafedra boshlig'i</option>
                                <option value="2">Kafedra boshlig'i o'rinbosari</option>
                                <option value="3">Kafedra professori</option>
                                <option value="4">Kafedra dotsenti</option>
                                <option value="5">Katta o'qituvchi</option>
                                <option value="6">O'qituvchi</option>
                                <option value="7">Kabinet boshlig'i</option>
                                <option value="8">O'quv-saf qismi Kurslar boshlig'i</option>
                                <option value="8">O'quv-saf qismi Kurslar boshlig'ining TIB o'rinbosari</option>
                                <option value="8">Kurs boshlig'i</option>
                                <option value="9">Kurs boshlig'ining TIB o'rinbosari</option>
                                <option value="10">Otryad komandiri</option>
                                <option value="11">Otryad komandirining TIB o'rinbosari</option>
                                <option value="11">Akademiya boshlig'ining o'quv-saf qismi bo'yicha o'rinbosari</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Ish stavkasi</label>
                            <select name="stavka_id" id="stavka_id" class="form-control">
                                <option>Tanlang</option>
                                <option value="1">1 stavka</option>
                                <option value="2">0.5 stavka</option>
                                <option value="3">0.25 stavka</option>
                                <option value="4">Soatbay</option>                                
                            </select>
                        </div>
                        <input type="text" name="lavozim" hidden id="lavozim_name_id">
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Login</label>
                            <input id="email" placeholder="oqituvchi_fio@akadmvd.uz" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Parol (Kamida 8 ta raqam va harflardan iborat bo'lishi kerak)</label>
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                            @error('password')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Parol qayta kiritish</label>
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                        </div>
                        <div class="form-group">
                            <label for="" class="bg-white p-2 border-bottom-info">Rasmi</label>
                            <input id="password" type="file" class="form-control @error('image') is-invalid @enderror" name="image"  >

                            @error('image')
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                        </div>
                    </div>
                   <div class="col-md-6">
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">Tavallud sanasi</label>
                           <input id="born" type="date" class="form-control @error('born') is-invalid @enderror" name="born" value="{{ old('born') }}" required autocomplete="born" autofocus>

                           @error('born')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                       <div class="form-group">
                           <label for="">Ma'lumoti</label>
                           <select name="malumoti_id" id="malumoti_id" class="form-control" onchange="getUserMalumot()">
                               <option>Tanlang</option>
                               <option value="1">Diplomli mutaxassis</option>
                               <option value="2">Bakalavr</option>
                               <option value="3">Magistr</option>

                           </select>
                       </div>
                       <input type="text" name="malumoti" hidden id="malumoti_name_id">
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">Mutaxassisligi</label>
                           <input placeholder="Tergov faoliyati" id="mutaxassislik" type="text" class="form-control @error('mutaxassislik') is-invalid @enderror" name="mutaxassislik" value="{{ old('mutaxassislik') }}" required autocomplete="mutaxassislik">

                           @error('mutaxassislik')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">IIOda qachondan</label>
                           <input id="iio_id" type="date" class="form-control @error('iio') is-invalid @enderror" name="iio" required autocomplete="iio">

                           @error('iio')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">Amaliy ish tajribasi</label>
                           <input id="ait" type="text" class="form-control" name="ait" required autocomplete="ait">
                       </div>
                       <div class="form-group">
                           <label for="" class="bg-white p-2 border-bottom-info">Pedagogik ish tajribasi</label>
                           <input id="pid_id" type="text" class="form-control @error('pid') is-invalid @enderror" name="pid"  >

                           @error('pid')
                           <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                           @enderror
                       </div>
                   </div>




                   <button class="btn btn-primary" type="submit">Yaratish</button>


           </form>
       </div>

    </div>
@endsection
