@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h5>{{\Illuminate\Support\Facades\Auth::user()->name}} - tomonidan joriy o'quv yilida erishilgan natijalar statistikasi</h5>
                <i class="fa fa-file-download"></i> Yuklab olish -        - <i class="fa fa-print"></i> Chop etish
                <table class="table table-responsive-lg table-hover table-bordered bg-white">
                    <thead>
                    <th>Band nomi</th>
                    <th>1.1</th>
                    <th>1.2</th>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Soni</td>
                        <td>4</td>
                        <td>5</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
