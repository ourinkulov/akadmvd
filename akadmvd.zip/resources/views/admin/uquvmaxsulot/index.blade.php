@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5>Hamkor tashkilotlar bilan birgalikda ilmiy yoki labaratoriya vositalaridan keng foydalangan holda yangi o'quv mahsulotlari ishlab chiqish</h5>
        <div class="row">
{{--            <a href="{{route('admin.adminuquvmaxsulot')}}"><button class="btn btn-info">Yaratish</button></a>--}}
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Yaratilgan vaqti</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Havola</th>
                <th>Status</th>
                <th>Ball</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($uquvmaxsulot as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>
                        <td>{{$item->turi_name}}</td>

                        <td><a href="{{asset('storage/uquvmaxsulot/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td><a href="{{$item->havola}}" target="_blank"><i class="fa fa-eye"></i></a></td>
                        <td>@if($item->status == 2) <button class="btn btn-success">Tasdiqlangan</button>@else<button class="btn btn-warning">Tasdiqlanmagan</button>@endif</td>
                        <td>{{$item->ball}}</td>
                        <td>
                            <a href="{{route('admin.editadminuquvmaxsulot',$item->id)}}"><i class="fa fa-edit"></i></a>
                        </td>
                        <td>
                            <form action="{{route('admin.maxsulotdelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
