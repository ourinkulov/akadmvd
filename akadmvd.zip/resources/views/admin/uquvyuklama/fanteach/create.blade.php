@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminfanteach')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Kursant (tinglovchi)larning fanlarni о‘zlashtirish kо‘rsatkichlari:
               </h5>
               <hr>
               <form action="{{route('admin.updatefanteach',$fanteach->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf


                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text"   class="form-control" value="{{$fanteach->user_name}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzusi </label>--}}
{{--                       <input type="text" name="title"  class="form-control"  value="{{$fanteach->title}}"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mashg'ulot soni </label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Natija</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getFanteachName2()">
                           <option value="0">Tanlang</option>
                           <option value="1"> A’lo baho uchun </option>
                           <option value="2"> Yaxshi baho uchun</option>

                       </select>
                   </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball"  id="ball_id" class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
