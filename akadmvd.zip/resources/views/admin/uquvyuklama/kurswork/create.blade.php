@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminkurswork')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Kurs ishlariga rahbarlik qilish,
                   ular bо‘yicha maslahatlar berish

               </h5>
               <hr>
               <form action="{{route('admin.updatekurswork',$kurswork->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Kurs ishi nomi </label>--}}
{{--                       <input type="number" name="soni" min="1" max="5" class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
                   <p>1 ta kurs ishi uchun 0.5 ball</p>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Kurs ishlari soni </label>
                       <input type="text" name="soni"  id="soni_id" class="form-control" value="{{$kurswork->soni}}"/>
                   </div>

{{--                   <div class="form-group">--}}
{{--                       <label for="">Darajasi</label>--}}
{{--                       <select name="turi_id" id="turi_id" class="form-control" onchange="getKursworkName()">--}}
{{--                           <option value="0">Tanlang</option>--}}
{{--                           <option value="1"> Мa’ruza uchun</option>--}}
{{--                           <option value="2"> Amaliy, seminar, laboratoriya, bazaviy-amaliy mashg‘ulotlar uchun</option>--}}
{{--                           <option value="3"> Fakultativ mashg‘ulotlar</option>--}}
{{--                           <option value="4"> Mustaqil tayyorgarlik soatlarida о‘quv fanlari bо‘yicha maslahatlar (Konsultatsiyalar)</option>--}}
{{--                       </select>--}}
{{--                   </div>--}}
                                      <div class="form-group">
{{--                                          <label for="" class="bg-white p-2 border-bottom-info"></label>--}}
                                          <a href="#" onclick="event.preventDefault();getkursworkBall()">Balni xisoblashni bosing</a>
{{--                                          <button class="btn btn-info" onclick="getkursworkBall()">Balni xisoblash</button>--}}
                                      </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball" id="ball_id" class="form-control" />
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
