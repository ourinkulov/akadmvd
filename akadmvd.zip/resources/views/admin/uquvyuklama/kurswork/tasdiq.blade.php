@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <h5>
            Tasdiqlangan kurs ishlari

        </h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
{{--                <th>Turi</th>--}}
                <th>Soni</th>
                <th>Ilova</th>
                <th>Ball</th>
                </thead>
                <tbody>
                    @foreach($kurswork as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
{{--                        <td>{{$item->turi_name}}</td>--}}
                        <td>{{$item->soni}}</td>
                        <td><a href="{{asset('storage/kurswork/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('admin.editkurswork',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
