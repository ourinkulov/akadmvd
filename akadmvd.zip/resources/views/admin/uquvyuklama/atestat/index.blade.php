@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5>
            Yakuniy davlat attestatsiyasini о‘tkazish.
        </h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($attestat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
{{--                        <td>{{$item->turi_name}}</td>--}}

                        <td><a href="{{asset('storage/davatestat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('admin.editattestat',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('admin.davattestatdel', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
