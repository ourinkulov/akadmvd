@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <div class="row mt-2 mb-2">
            <div class="col-md-4">
                <a href="{{route('admin.tasdiqadminuquvmashgulot')}}"><button class="btn btn-info">Tasdiqlanganlar ro'yhati</button></a>
            </div>
            <div class="col-md-4">
                <a href="{{route('admin.adminuquvmashgulot')}}"><button class="btn btn-info">Ortga</button></a>
            </div>

        </div>
        <hr>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   1.1. band - Professor-o'qituvchining o'quv yuklamasini bajarganligi.
                   <p style="color: #ee3838">
                       O'quv yuklamalar xar o'quv yili uchun professor-o'qituvchilar tomonidan tuziladigan hamda o'quv ishlari bo'yicha o'rinbosar (fakultet boshlig'i) tomonidan tasdiqlanadigan o'quv-yili bo'yicha professor-o'qituvchining shaxsiy rejalari asosida aniqlanadi.
                       </br>O'quv yuklamasi meyori to'liq bajarilganda - 150 ball beriladi. Yuklama ortib ketganda, qo'shimcha har 100 soat uchun 10 baldan qo'shiladi.
                       <br>Maksimal ball - 190 ball.
                   </p>
               </h5>
               <hr>
               <form action="{{route('admin.updateuquvmashgulot',$uquvmashgulot->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Kursant/Tinlovchilar soni </label>--}}
{{--                       <input type="number" name="soni" min="1" max="5" class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text"   class="form-control" value="{{$uquvmashgulot->user_name}}"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Akademik soat </label>
                       <input type="text" name="soni"  id="soni_id" class="form-control" value="{{$uquvmashgulot->soni}}"/>

                   </div>

                   <div class="form-group">
                       <label for="">Balni xisoblash</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getUquvmashgulotName2()">
                           <option value="0">Tanlang</option>
                           <option value="1"> Asosiy o'quv yuklamasi</option>
                           <option value="2"> Qo'shimcha yuklama</option>
{{--                           <option value="1"> Мa’ruza uchun</option>--}}
{{--                           <option value="2"> Amaliy, seminar, laboratoriya, bazaviy-amaliy mashg‘ulotlar uchun</option>--}}
{{--                           <option value="3"> Hukumat va rahbariyatning qaroriga binoan fakultativ mashg‘ulotlarni о‘tkazish</option>--}}
{{--                           <option value="4"> Mustaqil tayyorgarlik soatlarida о‘quv fanlari bо‘yicha maslahatlar (konsultatsiyalar)--}}
{{--                           </option>--}}
                       </select>
                   </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Tasdiqlash</button>
               </form>
           </div>
       </div>
    </div>
@endsection
