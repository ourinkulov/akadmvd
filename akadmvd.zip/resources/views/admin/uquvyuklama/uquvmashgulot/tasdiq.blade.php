@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <h5>
            O‘quv (maʼruza, amaliy, seminar,  laboratoriya, bazaviy-amaliy) mashg‘ulotlarini o‘tkazish
        </h5>
        <div class="row">
            <a href="{{route('admin.adminuquvmashgulot')}}"><button class="btn btn-info">Ortga</button></a>


        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Ball</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
{{--                <th>Ball</th>--}}
                </thead>
                <tbody>
                    @foreach($uquvmashgulot as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->soni}}</td>
                        <td>
                            <a href="{{asset('storage/uquvmashgulot/'.$item->file)}}"><i class="fa fa-eye"></i></a>
                        </td>
                        <td>
                            <a href="{{route('admin.editauquvmashgulot',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('admin.uquvmashgulotdelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>
                        </td>
{{--                        <td>--}}
{{--                            <a href="{{route('admin.editauquvmashgulot',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>--}}
{{--                        </td>--}}
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
