@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5>
            1.1. band - Professor-o'qituvchining o'quv yuklamasini bajarganligi.
            <p style="color: #ee3838">
                O'quv yuklamalar xar o'quv yili uchun professor-o'qituvchilar tomonidan tuziladigan hamda o'quv ishlari bo'yicha o'rinbosar (fakultet boshlig'i) tomonidan tasdiqlanadigan o'quv-yili bo'yicha professor-o'qituvchining shaxsiy rejalari asosida aniqlanadi.
                </br>O'quv yuklamasi meyori to'liq bajarilganda - 150 ball beriladi. Yuklama ortib ketganda, qo'shimcha har 100 soat uchun 10 baldan qo'shiladi.
                <br>Maksimal ball - 190 ball.
            </p>
        </h5>
        <div class="row">
            <a href="{{route('admin.tasdiqadminuquvmashgulot')}}"><button class="btn btn-primary">Tasdiqlangan</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Soni</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($uquvmashgulot as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->soni}}</td>
                        <td><a href="{{asset('storage/uquvmashgulot/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('admin.editauquvmashgulot',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('admin.uquvmashgulotdelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
