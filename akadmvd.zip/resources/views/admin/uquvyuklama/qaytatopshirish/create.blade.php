@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminqaytatopshirish')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Oraliq va yakuniy baholashlarni о‘tkazish, shuningdek qoldirgan (о‘zlashtirmagan) darslarni qayta topshirishini qabul qilish
               </h5>
               <hr>
               <form action="{{route('admin.updateqaytatopshirish',$qaytatopshirish->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Kursant/Tinlovchilar soni </label>--}}
{{--                       <input type="number" name="soni" min="1" max="5" class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Guruh yoki kursant soni </label>
                       <input type="text" name="soni" id="soni_id" class="form-control" value="{{$qaytatopshirish->id}}"/>
                   </div>

                   <div class="form-group">
                       <label for="">Darajasi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getQaytatopshirishName2()">
                           <option value="0">Tanlang</option>
                           <option value="1"> og‘zaki suhbat, amaliy ish shaklida</option>
                           <option value="2"> yozma ish shaklida</option>
                       </select>
                   </div>

                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" id="ball_id" name="ball"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Tasdiqlash</button>
               </form>
           </div>
       </div>
    </div>
@endsection
