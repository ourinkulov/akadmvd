@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <h5>Fan doktori (DSc) ilmiy darajasiga ega professor-o'qituvchilar</h5>
        <div class="row">
            <div class="col">
                <table class="table  " id="dataTable" width="100%" cellspacing="0">
                    <thead class="text-center " style=" font-size: 16px; background-color: rgb(252,252,252)">
                    <th>№</th>
                    <th>-</th>
                    <th>F.I.O</th>
                    <th>Lavozim</th>
                    <th>Ilmiy darajasi</th>
                    <th>Kafedra</th>
                    <th>Diplom olingan yil</th>
                    <th>Diplom fayli</th>
                    </thead>
                    <tbody>
                    @foreach($ds as $k=>$item)
                        <tr>
                            <td rowspan="2">{{++$k}}</td>
                            <td rowspan="2" >
                                <a href="{{route('admintouser.getoneteacherresult',$item->id)}}">
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </a>
                            </td>
                            <td>{{Str::upper($item->name)}}</td>
                            <td>{{$item->lavozim}}</td>
                            <td>{{$item->turi_name}}</td>
                            <td>{{$item->kaf_name}}</td>
                            <td><strong>{{$item->sana}}</strong>
                            <td>
                                <a href="{{asset('storage/ilmiydaraja/'.$item->file)}}" alt="" width="64px" style="border-radius: 45%;" target="_blank"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>
                        <tr>

{{--                            <td  colspan="4">--}}
{{--                                <div class="progress">--}}
{{--                                    <div--}}
{{--                                        @php--}}
{{--                                            $color = null;--}}
{{--                                        @endphp--}}



{{--                                        @if($item->ball > 600)--}}
{{--                                            class="progress-bar bg-success"--}}
{{--                                        @elseif($item->ball > 300)--}}
{{--                                            class="progress-bar bg-info"--}}
{{--                                        @elseif($item->ball > 200)--}}
{{--                                            class="progress-bar bg-warning"--}}
{{--                                        @elseif($item->ball < 200)--}}
{{--                                            class="progress-bar bg-danger"--}}
{{--                                        @endif--}}



{{--                                        role="progressbar" style="width: {{$item->ball*100/1000}}%" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" >--}}
{{--                                        {{$item->ball*100/1000}}%--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </td>--}}
                        </tr>

                    @endforeach
                </table>
            </div>
        </div>
    </div>
@endsection
