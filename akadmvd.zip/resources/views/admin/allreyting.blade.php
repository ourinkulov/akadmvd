@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <h4>Tizimdagi foydalanuvchilar soni: {{$user_count}}</h4>
            </div>
        </div>
        <div class="row">

            <div class="col">
                <table class="table  " id="dataTable" width="100%" cellspacing="0">
                    <thead class="text-center " style=" font-size: 16px; background-color: rgb(252,252,252)">
                    <th>Reyting</th>
                    <th>-</th>
                    <th>F.I.O</th>
                    <th>Lavozim</th>
                    <th>Kafedra</th>
                    <th>Ball</th>
                    </thead>
                    <tbody>
                    @foreach($allr as $k=>$item)
                        <tr>
                            <td rowspan="2">{{++$k}}</td>
                            <td rowspan="2" >
                                <a href="{{route('admintouser.getoneteacherresult',$item->user_id)}}">
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </a>
                            </td>
                            <td>{{$item->name}}</td>
                            <td>{{$item->lavozim}}</td>
                            <td>{{$item->kaf_name}}</td>
                            <td>
                                <strong>{{$item->allball}}</strong>
                                <sub>@if(!empty($item->jball)) (<i class="text-success">{{$item->ball}}</i>-<i class="text-danger">{{$item->jball}}</i>{{')'}} @endif   </sub>
                            </td>
                            </td>
                        </tr>
                        <tr>
                            <td  colspan="4">
                                <div class="progress">
                                    <div
                                        @php
                                            $color = null;
                                        @endphp
                                        @if($item->allball >= 600)
                                            class="progress-bar bg-success"
                                        @elseif($item->allball < 600 && $item->allball >= 300)
                                            class="progress-bar bg-info"
                                        @elseif($item->allball >=200 && $item->allball < 300)
                                            class="progress-bar bg-warning"
                                        @elseif($item->allball < 200)
                                            class="progress-bar bg-danger"
                                        @endif
                                        role="progressbar" style="width: {{$item->ball*100/1000}}%" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" >
                                        @if($item->allball >= 600)
                                            {{$item->allball*100/1000}}% - Lider
                                        @elseif($item->allball >= 300 && $item->allball < 600)
                                            {{$item->allball*100/1000}}% - Faol
                                        @elseif($item->allball < 300 && $item->allball >= 200 )
                                            {{$item->allball*100/1000}}% - Qoniqarli
                                        @elseif($item->allball < 200)
                                            {{$item->allball*100/1000}}% - Qoniqarsiz
                                        @endif
                                    </div>
                                </div>
                            </td>
                        </tr>

                    @endforeach
                </table>
            </div>
        </div>
    </div>
@endsection
