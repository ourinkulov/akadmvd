@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5>Metodik materiallarni tayyorlash  </h5>
{{--        <div class="row">--}}
{{--            <a href="{{route('users.createusermetodikmat')}}"><button class="btn btn-info">Yaratish</button></a>--}}
{{--        </div>--}}
        <div class="row mt-2">
            <div class="col-md-2">
                <a href=""><button class="btn btn-info">Tasdiqlangan</button></a>
            </div>
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
{{--                <th>Soni</th>--}}
                <th>Turi</th>

                <th>Yaratilgan vaqti</th>
                <th>Ilova</th>
                <th>Status</th>
                <td>Ball</td>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($metodikmat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
{{--                        <td>{{$item->soni}}</td>--}}
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->sana}}</td>
                        <td><a href="{{asset('storage/metodikmat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            @if($item->status == 1)
                                <button class="btn btn-warning">Tasdiqlanmagan</button>
                            @elseif($item->status == 2)
                                <button class="btn btn-success">Tasdiqlangan</button>
                            @endif
                        </td>
                        <td>{{$item->ball}}</td>
                        <td>
                            <a href="{{route('admin.editadminmetodikmat',$item->id)}}"><i class="fa fa-edit"></i></a>
                        </td>
                        <td>
                            <form action="{{route('admin.metodikmatdelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

        </div>
{{--        <div class="row">--}}
{{--            <div class="col-md-2">--}}
{{--               <div class="paginate" style="height: 10px">--}}
{{--                   {{ $metodikmat->links() }}--}}
{{--               </div>--}}
{{--            </div>--}}
{{--        </div>--}}

    </div>

@endsection
