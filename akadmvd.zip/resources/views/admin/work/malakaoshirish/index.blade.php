@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="col-md-6">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
        </div>
        <h5>
            Qayta tayyorlash va malaka oshirish kurslarida о‘qish
        </h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
{{--                <th>Mualliflar soni</th>--}}
                <th>Sana</th>
                <th>Ilova</th>
                <td>Status</td>
                <th>Ball</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>

                </thead>
                <tbody>
                    @foreach($malakaoshirish as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>
{{--                        <td>{{$item->taboq}}</td>--}}
                        <td><a href="{{asset('storage/malakaoshirish/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        @if($item->status == 2)
                            <td><button class="btn btn-success">Tasdiqlangan</button></td>
                        @elseif($item->status == 1)
                            <td><button class="btn btn-warning">Tasdiqlanmagan</button></td>
                        @endif
                        <td>{{$item->ball}}</td>

                        <td>
                            <a href="{{route('admin.editmalakaoshirish',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('admin.malakaoshirishdel', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>

                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
