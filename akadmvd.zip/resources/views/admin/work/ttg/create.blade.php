@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminttg')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Jamoat tartibini saqlash tadbirlari hamda tergov-tezkor guruhida ishtirok etish
               </h5>
               <hr>
               <form action="{{route('admin.updatettg',$ttg->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info"> Mavzusi </label>--}}
{{--                       <input type="text" name="title"  class="form-control" />--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Soni</label>
                       <input type="number" name="soni" id="soni_id" class="form-control" value="{{$ttg->soni}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Sana</label>--}}
{{--                       <input type="date" name="sana"  class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni</label>--}}
{{--                       <input type="number" name="taboq"  class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="">Natija</label>--}}
{{--                       <select name="turi_id" id="turi_id" class="form-control" onchange="getSotenginName()">--}}
{{--                           <option value="0">Tanlang</option>--}}
{{--                           <option value="1"> Onlayn pedagogik nazorat natijalari “yaxshi” baholanganda </option>--}}
{{--                           <option value="2"> Onlayn pedagogik nazorat natijalari “qoniqarli” baholanganda </option>--}}
{{--                           <option value="2"> O‘zlashtirishi sust bо‘lgan kursantlar semestr yakunlari bо‘yicha barcha fanlardan 4 baho olganda</option>--}}

{{--                       </select>--}}
{{--                   </div>--}}
                   <a href="#" onclick="event.preventDefault();getTtgBall()">Balni xisoblash</a>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball" id="ball_id" class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
