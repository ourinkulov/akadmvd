@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.admintadbir')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Ommaviy axborot vositalaridagi televizion dasturlarda ishtirok etish hamda intervyular berish, Sport, madaniy-ma’rifiy va ijodiy tadbirlarni tashkil etish va о‘tkazish va Tashkilotlarda ma’ruzalar qilish, shu jumladan huquqiy targ‘ibot ishlarini amalga oshirish
               </h5>
               <hr>
               <form action="{{route('admin.updatetadbir',$tadbir->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Muallif </label>
                       <input type="text" value="{{$tadbir->user_name}}"  class="form-control" />
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                       <input type="text" name="title"  class="form-control" value="{{$tadbir->title}}" />
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Sana</label>--}}
{{--                       <input type="date" name="sana"  class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni</label>--}}
{{--                       <input type="number" name="taboq"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getTadbirName()">
                           <option value="0">Tanlang</option>
                           <option value="1"> Ommaviy axborot vositalaridagi televizion dasturlarda ishtirok etish hamda intervyular berish</option>
                           <option value="2"> Sport, madaniy-ma’rifiy va ijodiy tadbirlarni tashkil etish va о‘tkazish</option>
                           <option value="3"> Tashkilotlarda ma’ruzalar qilish, shu jumladan huquqiy targ‘ibot ishlarini amalga oshirish</option>

                       </select>
                   </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball"  id="ball_id" class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Tasdiqlash</button>
               </form>
           </div>
       </div>
    </div>
@endsection
