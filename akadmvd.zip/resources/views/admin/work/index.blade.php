@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <h5>Jamoat ishlarini hisoblash reytingi</h5>
        <div class="row">
{{--            <a href="{{route('admin.adminuquvreja')}}"><button class="btn btn-info">Ortga</button></a>--}}
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg table-hover">
                <thead class="bg-white">
                <th>#</th>
                <th class="text-center"></th>
                <th>F.I.SH</th>
                <th>Kafedra nomi</th>
                <th>Ball</th>
                <th>Ball (15%)</th>
{{--                <th>Ilova</th>--}}
{{--                <th>Tasdiqlash</th>--}}
                </thead>
                <tbody>
                @foreach($jir as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td><img src="{{asset('storage/userimage/'.$item->image)}}" alt="" height="78px" width="78px" style="border-radius: 50%"></td>
                        <td>{{$item->name}}</td>
                        <td>{{$item->kaf_name}}</td>
                        <td>{{$item->ball}}</td>
                        <td>{{number_format($item->ball*0.15,1)}}</td>

{{--                        <td><a href="{{asset('storage/uquvreja/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>--}}
{{--                        <td>--}}
{{--                            <a href="{{route('admin.editadminuquvreja',$item->id)}}"><i class="fa fa-edit"></i></a>--}}
{{--                        </td>--}}
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
