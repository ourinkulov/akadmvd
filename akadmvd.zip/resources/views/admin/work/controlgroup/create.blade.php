@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.admincontrolgroup')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Akademiya boshlig‘ining buyrug‘i (farmoyishi)ga asosan ichki tekshiruv komissiyalari tarkibida ishlash:
               </h5>
               <hr>
               <form action="{{route('admin.updatecontrolgroup',$controlgroup->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info"> Mavzusi </label>--}}
{{--                       <input type="text" name="title"  class="form-control" />--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                       <input type="text" name="title"  class="form-control" value="{{$controlgroup->title}}"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Boshlangan sana</label>
                       <input type="date" name="sana"  class="form-control" value="{{$controlgroup->sana}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni</label>--}}
{{--                       <input type="number" name="taboq"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getControlgroupName()">
                           <option value="0">Tanlang</option>
                           <option value="1"> Komissiya raisligi uchun </option>
                           <option value="2"> Kotiblik uchun </option>
                           <option value="3"> A’zolik uchun</option>

                       </select>
                   </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Tasdiqlash</button>
               </form>
           </div>
       </div>
    </div>
@endsection
