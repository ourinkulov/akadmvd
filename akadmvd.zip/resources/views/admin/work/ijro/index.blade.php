@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="col-md-6">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
        </div>
        <h5>
            Ijro hujjatlari hamda rahbariyatning boshqa topshiriqlarini bajarish
        </h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Turi</th>
{{--                <th>Mualliflar soni</th>--}}
{{--                <th>Sana</th>--}}
                <th>Ilova</th>
                <th>Status</th>
                <th>Ball</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($ijro as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
{{--                        <td>{{$item->sana}}</td>--}}
{{--                        <td>{{$item->taboq}}</td>--}}
                        <td><a href="{{asset('storage/ijro/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>@if($item->status == 2) <button class="btn btn-success">Tasdiqlangan</button>@else<button class="btn btn-warning">Tasdiqlanmagan</button>@endif</td>

                        <td>{{$item->ball}}</td>
                        <td>
                            <a href="{{route('admin.editeijro',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('admin.ijrodel', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
