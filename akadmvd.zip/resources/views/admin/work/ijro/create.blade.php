@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminijro')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                   Ijro hujjatlari hamda rahbariyatning boshqa topshiriqlarini bajarish
               </h5>
               <hr>
               <form action="{{route('admin.updateijro',$ijro->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info"> Mavzusi </label>--}}
{{--                       <input type="text" name="title"  class="form-control" />--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                       <input type="text" name="title"  class="form-control" value="{{$ijro->title}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Boshlangan sana</label>--}}
{{--                       <input type="date" name="sana"  class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni</label>--}}
{{--                       <input type="number" name="taboq"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getIjroName()">
                           <option value="0">Tanlang</option>
                           <option value="1"> Qо‘shimcha о‘rganish, qо‘shimcha hujjatlar sо‘rab olish, tahliliy yondashuv hamda kо‘p vaqt va katta resurs talab etiladigan topshiriqlar</option>
                           <option value="2"> Tashkiliy tadbirlar orqali amalga oshiriladigan, qо‘shimcha ma’lumot olish talab etiladigan, topshiriqlar </option>
                           <option value="3"> Qо‘shimcha о‘rganish, ortiqcha vaqt va resurs talab etmaydigan hujjatlar</option>

                       </select>
                   </div>
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                      <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
