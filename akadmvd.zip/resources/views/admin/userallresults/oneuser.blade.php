@extends('layouts.app')
@section('content')
{{--  <h1>{{ \Illuminate\Support\Facades\Auth::user()->name }}</h1>--}}
{{--  @if (is_null(\Illuminate\Support\Facades\Auth::user()->image))--}}
{{--      <img src="{{asset('storage/userimage/images.png')}}" class="card-img-top" alt="..." style="height: 267px; !important;">--}}
{{--  @else--}}
{{--      <img src="{{asset('storage/userimage/'.\Illuminate\Support\Facades\Auth::user()->image)}}" class="card-img-top" alt="..." style="height: 267px; width: 260px; !important;">--}}
{{--  @endif--}}
{{--  <hr>--}}
<a href="{{route('admin.dashboard')}}"><button class="btn btn-info ml-4 mb-2 mt-0">Ortga</button></a>
      <div class="container-fluid">
          <div class="row justify-content-center">
              <div class="col-md-2">
                  <div class="card shadow p-3 mb-5 bg-white rounded" style="border-radius: 2%; border-color: white">
                      @if (is_null(\Illuminate\Support\Facades\Auth::user()->image))
                          <img src="{{asset('storage/userimage/images.png')}}" class="card-img-top" alt="..." style="height: 267px; !important;">
                      @else
                          <img src="{{asset('storage/userimage/'.$user->image)}}" class="card-img-top" alt="..." style="height: 267px; !important;">
                      @endif
                      <div class="card-body text-center">
                          <h5 class="card-title">
                              <strong>{{$user->name}}</strong>
                          </h5>
                          <h6>{{$user->lavozim}}</h6>
                          <div class="container">
                              <div class="row">
                                  <div class="col-md-6 text-right">
                                      <img src="{{asset('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0hQbEzmtyhO_VNZGC5Yvm8Pu7Obwdg5bnCA&usqp=CAU')}}" width="36px;" alt="">
                                  </div>
                                  <div class="col-md-6 text-left m-0 ml-0 pl-0">
                                      <a href="{{route('users.getallreyting')}}"> <span style="font-size: 16px; " class=" badge badge-pill badge-warning badge-counter">
{{--                                        {{ $rating }}--}}
                                    </span></a>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-md-5">
                  <div class="card " style="border-radius: 2%; border-color: white">
                      <div class="card-header"><strong>{{ __('Umumiy ma\'lumotlar') }}</strong></div>
                      <div class="card-body ">
                          <div class="container">
                              <div class="row">
                                  <div class="col-md-12">
                                      <table class="table table-hover table-responsive-lg " style="border: none">
                                          <tr ><td class="text-center" style="background-color: rgba(8,34,201,0.37); border-radius: 16px;">
                                                  <img src="{{asset('calendar.svg')}}" width="36px" alt=""></td><td>Tavallud sanasi:</td><td>
                                              {{$user->born}}</tr>
                                          <tr ><td class="text-center" style="background-color:rgba(91,97,190,0.37); border-radius: 16px">
                                                  <img src="{{asset('graduated.svg')}}" width="36px" alt=""></td><td>Malumoti:</td><td>{{$user->malumoti}}</td></tr>
                                          <tr><td class="text-center" style="background-color: rgba(120,210,125,0.37); border-radius: 16px">
                                                  <img src="{{asset('certificate.svg')}}" width="36px" alt=""></td><td>Ma'lumoti bo'yicha mutaxassisligi:</td><td>{{$user->mutaxassislik}}</td></tr>
                                          <tr><td class="text-center" style="background-color:  rgba(115,220,224,0.37); border-radius: 16px">
                                                  <img src="{{asset('calendar.png')}}" width="36px" alt=""></td><td>IIOda qachondan:</td><td>{{$user->iio}}</td></tr>

                                          <tr><td class="text-center" style="background-color: rgba(187,89,167,0.37); border-radius: 16px">
                                                  <img src="{{asset('year.svg')}}" width="36px" alt=""></td><td>Amaliy ish tajribasi:</td><td><span style="font-size: 18px;" class="badge badge-success badge-colors">{{$user->ait}}</span></td></tr>
                                          <tr><td class="text-center" style="background-color: rgba(220,143,157,0.37); border-radius: 16px">
                                                  <img src="{{asset('year.svg')}}" width="36px" alt=""></td><td>Pedagogik ish tajribasi:</td><td><span style="font-size: 18px;" class="badge badge-success badge-colors">{{$user->pit}}</span></td></tr>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-md-5">
                  <div class="card" style="border-radius: 2%; border-color: white">
                      <div class="card-header"><strong>{{ __('Umumiy ma\'lumotlar') }} 1 </strong></div>
                      <div class="card-body">
                          <div class="container">
                              <div class="row">
                                  <div class="col-md-12">
                                      <table class="table table-hover table-responsive-lg -border-none">
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(245,2,2,0.37); border-radius: 16px">
                                                  <img src="{{asset('diploma.png')}}" width="36px" alt="">
                                              </td>
                                              <td>Ilmiy darajasi:
                                              <td>
                                                  {{--                                            {{$data['idara']}}--}}
                                                  @if(!empty($idara && $idara->fayl && $idara->tur_id == 2)){{'DSc'}}
                                                  @elseif(!empty($idara && $idara->fayl && $idara->tur_id == 1)){{'PhD'}}
                                                  @else Mavjud emas
                                                  @endif
                                              </td>
                                              <td>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(171,1,175,0.37); border-radius: 16px">
                                                  <img src="{{asset('file-download.svg')}}" width="36px" alt=""></td><td>Ilmiy daraja ilovasi:</td><td>
                                                  @if(!empty($idara && $idara->fayl))
                                                      <a href="{{asset('storage/'.$idara->fayl)}}" target="_blank"><i class="fa fa-book-open"></i></a>
                                                  @elseif(!empty($idara->fayl))
                                                      <a href="{{asset('/storage/'.$idara->fayl)}}" target="_blank"><i class="fa fa-book-open"></i></a>
                                                  @endif</td>
                                          </tr>
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(33,30,136,0.37); border-radius: 16px">
                                                  <img src="{{asset('graduation-diploma.png')}}" width="36px" alt=""></td><td>Ilmiy unvon::</td><td>
                                                  @if(!empty($yunvon && $yunvon->fayl && $yunvon->tur_id == 2)){{'Professor'}}
                                                  @elseif(!empty($yunvon && $yunvon->fayl && $yunvon->tur_id == 1)){{'Dotsent'}}
                                                  @else Mavjud emas
                                                  @endif

                                              </td>
                                          </tr>
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(9,112,115,0.37); border-radius: 16px">
                                                  <img src="{{asset('file-download.svg')}}" width="36px" alt=""></td><td>Ilmiy unvon ilovasi:</td><td>
                                                  @if(!empty($yunvon && $yunvon->fayl))
                                                      <a href="{{asset('storage/'.$yunvon->fayl)}}" target="_blank"><i class="fa fa-book-open"></i></a>
                                                  @elseif(!empty($oldilmiyunvon->fayl))
                                                      <a href="{{asset('/storage/'.$oldilmiyunvon->fayl)}}" target="_blank"><i class="fa fa-book-open"></i></a>
                                                  @endif
                                              </td>
                                          </tr>
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(82,182,78,0.37); border-radius: 16px">
                                                  <img src="{{asset('meeting.svg')}}" width="36px" alt=""></td><td>Kuratorlik guruhi/yo'nalishi:</td><td>
                                              </td>
                                          </tr>
                                          <tr>
                                              <td class="text-center" style="background-color: rgba(215,158,53,0.37); border-radius: 16px">
                                                  <img src="{{asset('classroom.png')}}" width="36px" alt=""></td><td>Kafedra:<td>{{$user->kaf_name}}
                                              </td>
                                          </tr>
                                      </table>
                                  </div>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">
              <div style="width: 600px;">
                  <div class="card">
                      <div class="card-header text-secondary">
                          <b>{{$user->name}}</b> ning faoliyati ko'rsatkichlari radar chart diagrammasi
                      </div>
                      <div class="card-body">
                          <canvas id="radarChart"></canvas>
                      </div>
                  </div>
              </div>
          </div>
          <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


          @if(Auth()->user()->role == 3)
              <script>
                  const plugin = {
                      id: 'customCanvasBackgroundColor',
                      beforeDraw: (chart, args, options) => {
                          const {ctx} = chart;
                          ctx.save();
                          ctx.globalCompositeOperation = 'destination-over';
                          ctx.fillStyle = options.color || '#99ffff';
                          ctx.fillRect(0, 0, chart.width, chart.height);
                          ctx.restore();
                      }
                  };
                  var ctx = document.getElementById('radarChart').getContext('2d');
                  var myRadarChart = new Chart(ctx, {
                      type: 'radar',
                      data: {
                          labels: ["O'quv yuklamasi", "O'quv-uslubiy ishlar", 'ilmiy ishlar', 'jamoat (ustoz-shogird)'],
                          datasets: [{
                              label: 'Ballar koifisenti',
                              data:  @json($chart),
                              backgroundColor: 'rgba(235,54,145,0.2)',
                              borderColor: 'rgb(240,65,117)',
                              borderWidth: 1
                          }]
                      },
                      options: {
                          scale: {
                              min: 0,
                              max: 1,
                              stepSize:1,
                              ticks: {
                                  suggestedMin: 0,
                                  suggestedMax: 1,
                                  stepSize: 0.1,
                                  negative: false
                              }
                          },

                      }
                  });
              </script>
          @endif
      </div>
  <hr>
  <div class="row mt-2 m-2">
      <table class="table table-responsive-lg">
          <thead class="bg-white">
          <th>#</th>

              <th>O'qituvchi</th>
              <th>Band</th>
              <th>Turi</th>
              <th>Soni</th>
          <th>Mualliflar soni</th>
              <th>Ilova</th>
          <th>Ilova</th>
          <th>Status</th>
          <th>Izoh</th>
          <th>Ball</th>

{{--              <th>O'zgartirish</th>--}}
{{--              <th>O'chirish</th>--}}

          </thead>
          <tbody>
          @if(!empty($res))
              @foreach($res as $item)
                  <tr @if ($item->kriteriya_id>=57) class="table-danger"> @endif  >
                      <td>{{ $item->id }}</td>
                      {{--                            @if($admin=4)--}}
                      <th>{{ $item->teacher->name }}</th>
                      <th>{{ $item->kriteriya->band }}</th>
                      {{--                            @endif--}}



                      @if($item->kriteriya->turlar_bormi)
                          <td>{{ unserialize($item->kriteriya->turlar)[intval($item->tur_id) - 1]['nomi'] }}</td>
                      @else
                          <td></td>
                      @endif

                          <td>{{ $item->soat }}</td>
                      <td>{{ $item->muallif_soni }}</td>

                      @if($item->havola)
                          <td><a href="{{ $item->havola }}" target="_blank">{{ Str::limit($item->havola,50) }}</a></td>
                      @else
                          <td></td>
                      @endif
                      <td><a href="{{ asset('storage/'. $item->fayl) }}"><i class="fa fa-download" aria-hidden="true"></i></a></td>
                      <td>
                          @if(!$item->status)
                              <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
                          @else
                              <button class="btn btn-success btn-sm">Tasdiqlangan</button>
                          @endif
                      </td>
                      <td>{{ $item->comment }}</td>
                      <td>{{ $item->ball }}</td>

{{--                          <th>--}}
{{--                              <a href="{{ route('kriteriya.edit',  [$item->route, $item->id]) }}">--}}
{{--                                  <button class="btn btn-primary btn-sm">O'zgartirish</button>--}}
{{--                              </a>--}}
{{--                          </th>--}}
{{--                          <th>--}}
{{--                              <form action="{{ route('kriteriya.destroy',  [$item->route, $item->id]) }}" method="post">--}}
{{--                                  @csrf--}}
{{--                                  @method('DELETE')--}}
{{--                                  <button class="btn btn-danger btn-sm">O'chirish</button>--}}
{{--                              </form>--}}
{{--                          </th>--}}

                  </tr>
              @endforeach
          @endif

          </tbody>
      </table>
  </div>
  <hr>
      <script>
          const plugin = {
              id: 'customCanvasBackgroundColor',
              beforeDraw: (chart, args, options) => {
                  const {ctx} = chart;
                  ctx.save();
                  ctx.globalCompositeOperation = 'destination-over';
                  ctx.fillStyle = options.color || '#99ffff';
                  ctx.fillRect(0, 0, chart.width, chart.height);
                  ctx.restore();
              }
          };
          var ctx = document.getElementById('radarChart').getContext('2d');
          var myRadarChart = new Chart(ctx, {
              type: 'radar',
              data: {
                  labels: ["O'quv yuklamasi", "O'quv-uslubiy ishlar", 'ilmiy ishlar', 'jamoat (ustoz-shogird)'],
                  datasets: [{
                      label: 'Ballar koifisenti',
                      data:  @json($chart),
                      backgroundColor: 'rgba(235,54,145,0.2)',
                      borderColor: 'rgb(240,65,117)',
                      borderWidth: 1
                  }]
              },
              options: {
                  scale: {
                      min: 0,
                      max: 1,
                      stepSize:1,
                      ticks: {
                          suggestedMin: 0,
                          suggestedMax: 1,
                          stepSize: 0.1,
                          negative: false
                      }
                  },

              }
          });
      </script>

@endsection('content')
