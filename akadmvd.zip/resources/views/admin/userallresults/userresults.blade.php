@extends('layouts.adminapp')
@section('content')
  <h1>{{ $user->name }}</h1>
  @if (is_null(\Illuminate\Support\Facades\Auth::user()->image))
      <img src="{{asset('storage/userimage/images.png')}}" class="card-img-top" alt="..." style="height: 267px; !important;">
  @else
      <img src="{{asset('storage/userimage/'.$user->image)}}" class="card-img-top" alt="..." style="height: 267px; width: 260px; !important;">
  @endif
  <hr>
  <h5>
      Yakuniy davlat attestatsiyasini о‘tkazish.
  </h5>
  <hr>
  <div class="row mt-2">
      <table class="table table-responsive-lg">
          <thead class="bg-white">
          <th>#</th>
          <th>Nomlanishi</th>
          <th>Ilova</th>
          <th>Status</th>
          <th>Ball</th>
          </thead>
          <tbody>
          @foreach($attestat as $item)
              <tr>
                  <td>{{++$i}}</td>
                  <td>{{$item->turi_name}}</td>
                  {{--                        <td>{{$item->turi_name}}</td>--}}

                  <td><a href="{{asset('storage/davatestat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                  <td>
                      {{$item->status}}
                  </td>
                  <td>
                      {{$item->ball}}
                  </td>
              </tr>
          @endforeach
          </tbody>
      </table>
  </div>
  <hr>

@endsection('content')
