@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminpednazorat')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Ma’ruza va boshqa о‘kuv   mashg‘ulotlarini pedagogik nazorat qilish va  О‘quv  mashg‘ulotlariga о‘zaro  qatnashish, yozma shaklda taqriz yozish majburiyati bilan</h5>
               <hr>
               <form action="{{route('admin.updateadminpednazorat',$pednazorat->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                        <input type="text" name="title"  class="form-control" value="{{$pednazorat->title}}"/>
                    </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Akademik soat yoki mashg'ulot soni</label>
                       <input id="soni_id" type="number" name="soni"  class="form-control" value="{{$pednazorat->soni}}"/>
                   </div>

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Yaratilgan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getPednazoratTuriName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">Ma’ruza va boshqa о‘kuv   mashg‘ulotlarini pedagogik nazorat qilish</option>
                           <option value="2">О‘quv  mashg‘ulotlariga о‘zaro  qatnashish, yozma shaklda taqriz yozish majburiyati bilan</option>

                       </select>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF shaklda | Ishlanmaning skaneri)</label>--}}
{{--                       <input type="file" name="file"  class="form-control"/>--}}
{{--                   </div>--}}
                   <div class="form-group">
                                              <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                                              <input type="text" name="ball"  id="ball_id" class="form-control" value="{{$pednazorat->ball}}"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
