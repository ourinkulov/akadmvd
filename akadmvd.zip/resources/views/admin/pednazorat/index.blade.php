@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5 class="bg-white p-3 text-center " style="border-radius: 10%">Ma’ruza va boshqa о‘kuv   mashg‘ulotlarini pedagogik nazorat qilish va  О‘quv  mashg‘ulotlariga о‘zaro  qatnashish, yozma shaklda taqriz yozish majburiyati bilan</h5>
{{--        <div class="row">--}}
{{--            <a href="{{route('users.createuserpednazorat')}}"><button class="btn btn-info">Yaratish</button></a>--}}
{{--        </div>--}}
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Soni</th>
                <th>Turi</th>
                <th>Yaratilgan vaqti</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($pednazorat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->soni}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->sana}}</td>
                        <td><a href="{{asset('storage/pednazorat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('admin.editadminpednazorat',$item->id)}}"><i class="fa fa-edit"></i></a>
                        </td>
                        <td>
                            <form action="{{route('admin.pednazoratdelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
