@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        <form action="{{route('admin.getteacherreport')}}" method="POST">
            @csrf
            <div class="col-md-12 ">
                <div class="row justify-content-center">
                    <hr>
                    <div class="col-md-2">
                        <div class="form-row">
                            <label>Boshlanish sanasi:</label>
                            <input type="date" name="fdate" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-row">
                            <label>Tugash sanasi:</label>
                            <input type="date" name="ldate" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-row">
                            <label>Xisobot turi</label>
                            <select name="turId" id="" class="form-control">
                                <option value="">Tanlang</option>
                                <option value="1">Bandlar kesimida umumiy xisobot</option>
                                <option value="2">Bandlar bo'yicha kafedralar kesimida xisobot</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-row">
                            <label for="">Xisobotni yuklab olish</label><br>
                            <button type="submit" class="btn btn-success mt-4">Yuklash</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <hr>
        <div class="row">
            <div class="col-md-12">
                @if(!empty($results))
                    <div class="card-body bg-success text-white bold text-center">
                        <h4>{{$fdate .' sanasidan '}}{{$ldate.' sanasigacha tizimga yuklangan ma\'lumotar'}}</h4>
                    </div>
                @endif

                <table class="table table-responsive-lg table-hovered" width="100%">
                    <tr>
                        <td>ID</td>
                        <td>Kriteriya bandi</td>
                        <td>Yuklangan ma'lumotlar soni</td>
{{--                        <td>Olingan ball</td>--}}
{{--                        <td>Fayl</td>--}}
                    </tr>
                    @if(!empty($results))
                        @foreach($results as $item)
                            <tr class="bg-white">
                                <td>{{$item->id}}</td>
                                <td>{{$item->band}}</td>
                                <td>{{$item->count}}</td>
{{--                                <td>{{$item->ball}}</td>--}}
                                <td>
{{--                                    <a href="{{asset('storage/'.$item->fayl)}}">Ilova</a>--}}
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </table>
            </div>
        </div>
    </div>
@endsection
