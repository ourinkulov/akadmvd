@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('admin.adminmaruzafond')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Yangi ma'ruza fondlari, maslalar toplami, amaliy-uslubiy qo'llanmalar yaratish</h5>
               <hr>
               <form action="{{route('admin.updateadminmaruzafond',$maruzafond->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Nomlanishi</label>
                        <input value="{{$maruzafond->title}}" type="text" name="title"  class="form-control"/>
                    </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>
                       <input id="mavzu_soni_id" value="{{$maruzafond->mavzu_soni}}" type="number" name="mavzu_soni"  class="form-control"/>
                   </div>

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getBallAdmin()">
                           <option value="0">Tanlang</option>
                           <option value="1">Yangi ma'ruza fond</option>
                           <option value="2">Masalalar toplami</option>
                           <option value="3">Amaliy-uslubiy qo'llanma</option>
                       </select>
                   </div>
                   <div class="form-group">
                       <label for="">Ball</label>
                       <input type="text"  class="form-control" name="ball" id="ball_id" value="{{$maruzafond->ball}}">
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" >
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
