@extends('layouts.app')
@section('content')
    <div class="container-fluid">
        
        <hr>
        <div class="row">
            <div class="col-md-12">
                <h5>HEMIS axborot tizimi dars jadvaliga kiritilgan va professor-o'qituvchi tomonidan o'tganligi qayd qilingan dars soatlari xisobga olingan</h3>
               
                <table class="table table-responsive-lg table-hovered" width="100%">
                    <tr>
                        <td>ID</td>
                        <td>F.I.SH</td>
                        <td>Dars soati</td>
                       <td>Olingan ball</td>
{{--                        <td>Fayl</td>--}}
                    </tr>
                    @if(!empty($results))
                        @foreach($results as $item)
                            <tr class="bg-white">
                                <td>{{$item->_employee}}</td>
                                <td>{{$item->name}}</td>
                                {{-- <td>{{$item->lavozim}}</td> --}}
                                <td>{{$item->dars_soni}}</td>
                                <td>{{$item->ball}}</td>
{{--                                <td>{{$item->ball}}</td>--}}
                                <td>
{{--                                    <a href="{{asset('storage/'.$item->fayl)}}">Ilova</a>--}}
                                </td>
                            </tr>
                        @endforeach
                    @endif
                </table>
            </div>
        </div>
    </div>
@endsection
