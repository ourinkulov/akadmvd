@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <a href="{{route('admin.admindarsliks')}}"><button class="btn btn-info">Ortga</button></a>
                <hr>
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
       <div class="row">
           <div class="col-md-6">
               <h5>Darslikni tasdiqlash</h5>
               <hr>
               <form action="{{route('admin.updateadmindarsliks',$darslik->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                   @method('POST')
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Darslik nomi</label>
                        <input type="text" name="title"  class="form-control" value="{{$darslik->title}}"/>
                    </div>

                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Darslik muallifi</label>
                       <input type="text" name="user_name"  class="form-control" value="{{$darslik->user_name}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Darslik yaratilgan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Mualliflar soni</label>
                       <input id="muallif_id" type="number" name="muallif_soni"  class="form-control" value="{{$darslik->muallif_soni}}"/>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Taboqlar soni</label>
                       <input id="taboq_id" type="text" name="taboq"  class="form-control" value="{{$darslik->taboq}}"/>
                   </div>
                   <div class="form-group">
                       <label for="">Darslik turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getTuriName()">
                           <option value="{{$darslik->turi_id}}" selected>{{$darslik->turi_name}}</option>
                           <option value="1">Yangi darslik</option>
                           <option value="2">Yangi o'quv-qo'llanma</option>
                           <option value="3">Qayta nashr etilgan darslik</option>
                           <option value="4">Qayta nashr etilgan o'quv-qo'llanma</option>
                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input id="ball_id" type="text" name="ball"  class="form-control" />
                   </div>
                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF shaklda)</label>--}}
{{--                       <input type="file" name="file"  class="form-control"/>--}}
{{--                   </div>--}}
                   <button class="btn btn-primary" type="submit">Tasdiqlash</button>
               </form>
           </div>
       </div>
    </div>
@endsection
