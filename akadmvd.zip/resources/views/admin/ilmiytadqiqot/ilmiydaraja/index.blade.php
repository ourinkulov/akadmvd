@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy darajalarni tasdiqlash</h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                </thead>
                <tbody>
                @foreach($ilmiydaraja as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>

                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/ilmiydaraja/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('admin.editadminilmiydaraja',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
