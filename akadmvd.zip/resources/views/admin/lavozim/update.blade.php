@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('error'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('lavozim.index')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>
                  Lavozimlar
               </h5>
               <hr>
               <form action="{{route('lavozim.update',$lavozim->id)}}"  method="post" enctype="multipart/form-data">
                   @csrf
                   @method('PATCH')
                   <div class="form-group">
                      <label for="" class="bg-white p-2 border-bottom-info">Lavozim nomi</label>
                      <input type="text" name="lavozim_name" value="{{$lavozim->lavozim_name}}" id="lavozim_name" class="form-control"/>
                   </div>
                   <button class="btn btn-primary" type="submit">O'zgartirish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
