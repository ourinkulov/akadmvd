@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="col-md-6">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
        </div>
        <h5>
            Lavozimlar
        </h5>
        <div class="row">
            <a href="{{route('lavozim.create')}}"><button class="btn btn-primary">Yaratish</button></a>
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg bg-white">
                <thead class="bg-white">
                <th>T/r</th>
                <th>Lavozim</th>
                <th>O'zgartirish</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($lavozim as $item)
                    <tr>
                        <td>{{++$loop->index}}</td>
                        <td>{{$item->lavozim_name}}</td>
                        <td>
                            <a href="{{route('lavozim.edit',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>
                            <form action="{{route('lavozim.destroy', $item->id)}}" method="post">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
