@extends('layouts.adminapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                @if ($message = Session::get('danger'))
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
            </div>
        </div>
        <h5>Elektron platformaga o'quv yuklamasida nazarda tutilganidan tashqari mustaqil ishlab chiqilgan va o'quv jarayonidan foydalanilayotgan o'quv-uslubiy majmualar</h5>
        <div class="row">
{{--            <a href="{{route('admin.editadminmajmua')}}"><button class="btn btn-info">Yaratish</button></a>--}}
        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>Yaratilgan vaqti</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Havola</th>
{{--                <th>Status</th>--}}
                <th>Ball</th>
                <th>Status</th>

                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($majmua as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>
                        <td>{{$item->turi_name}}</td>

                        <td><a href="{{asset('storage/majmua/'.$item->file)}}" target=""><i class="fa fa-eye"></i></a></td>
                        <td><a href="{{asset($item->havola)}}" target="_blank"><i class="fa fa-eye"></i></a></td>
{{--                        <td>@if($item->status == 2) <button class="btn btn-success">Tasdiqlangan</button>@else<button class="btn btn-warning">Tasdiqlanmagan</button>@endif</td>--}}
                        <td>{{$item->ball}}</td>

                        <td>@if($item->status == 1)  <a href="{{route('admin.editadminmajmua',$item->id)}}"><i class="fa fa-edit"></i></a> @else <button class="btn btn-success">Tasdiqlangan</button>@endif</td>


                        <td>
                            <form action="{{route('admin.majmuadelete', $item->id)}}">
                                @csrf
                                @method('GET')

                                <button type="submit" class="btn btn-danger">O'chirish</button>
                            </form>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
