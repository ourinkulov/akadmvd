<td>
    @if($item->status == 1)
        <button class="btn btn-warning btn-sm">Tasdiqlanmagan</button>
    @elseif($item->status == 2)
        <button class="btn btn-success btn-sm">Tasdiqlangan</button>
    @endif
</td>
