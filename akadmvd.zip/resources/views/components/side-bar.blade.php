@switch(\Illuminate\Support\Facades\Auth::user()->role)
    @case(1)
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-book "></i>
                <span>O'quv yuklamasi</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k1 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach

                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities2" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-file-pen "></i>
                <span>O'quv-uslubiy ishlar</span>
            </a>
            <div id="collapseUtilities2" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">

                    @foreach($k2 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities4" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Jamoat (Ustoz-shogird) ishlar</span>
            </a>
            <div id="collapseUtilities4" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k4 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities10" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>O'quv-yuklama jarima ballari</span>
            </a>
            <div id="collapseUtilities10" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k5 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities11" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>O'quv-uslubiy jarima ballari</span>
            </a>
            <div id="collapseUtilities11" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k6 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities12" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Ustoz-shogird jarima ballari</span>
            </a>
            <div id="collapseUtilities12" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k8 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
    @break
    @case(2)
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities3" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-rocket "></i>
                <span>Ilmiy-tadqiqot ishlar</span>
            </a>
            <div id="collapseUtilities3" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k3 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities10" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Jarima ballari</span>
            </a>
            <div id="collapseUtilities10" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k7 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>

    @break
        @case(10)
        @break
    @case(3)
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-book "></i>
                <span>O'quv yuklamasi</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k1 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach

                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities2" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-file-pen "></i>
                <span>O'quv-uslubiy ishlar</span>
            </a>
            <div id="collapseUtilities2" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">

                    @foreach($k2 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities3" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-rocket "></i>
                <span>Ilmiy-tadqiqot ishlar</span>
            </a>
            <div id="collapseUtilities3" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k3 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities4" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Jamoat (Ustoz-shogird) ishlar</span>
            </a>
            <div id="collapseUtilities4" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k4 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities10" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>O'quv-yuklama jarima ballari</span>
            </a>
            <div id="collapseUtilities10" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k5 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities11" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>O'quv-uslubiy jarima ballari</span>
            </a>
            <div id="collapseUtilities11" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k6 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities12" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Ilmiy ishlardagi jarima ballari</span>
            </a>
            <div id="collapseUtilities12" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k7 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities13" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Ustoz-shogird jarima ballari</span>
            </a>
            <div id="collapseUtilities13" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k8 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
    @break
    @case(4)
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-book "></i>
            <span>O'quv yuklamasi</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="py-2 bg-white rounded collapse-inner">
                @foreach($k1 as $kr)
                    <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                @endforeach

            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities2" aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-file-pen "></i>
            <span>O'quv-uslubiy ishlar</span>
        </a>
        <div id="collapseUtilities2" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="py-2 bg-white rounded collapse-inner">

                @foreach($k2 as $kr)
                    <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                @endforeach
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities3" aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-rocket "></i>
            <span>Ilmiy-tadqiqot ishlar</span>
        </a>
        <div id="collapseUtilities3" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="py-2 bg-white rounded collapse-inner">
                @foreach($k3 as $kr)
                    <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                @endforeach
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities4" aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-people-line "></i>
            <span>Jamoat (Ustoz-shogird) ishlar</span>
        </a>
        <div id="collapseUtilities4" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="py-2 bg-white rounded collapse-inner">
                @foreach($k4 as $kr)
                    <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span> {{ $kr->menu }} </span></a>
                @endforeach
            </div>
        </div>
    </li>

    @break
@endswitch


