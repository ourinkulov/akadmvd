@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiyseminar')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Ilmiy darajalar beruvchi ilmiy kengash ishida ishtirok etish</h5>
               <hr>
               <form action="{{route('ilmiy.updateilmiyseminar',$ilmiyseminar->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Ilmiy kengash nomlanishi</label>
                        <input type="text" name="title"  class="form-control" value="{{$ilmiyseminar->title}}"/>
                    </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text" name="title"  class="form-control" value="{{$ilmiyseminar->user_name}}"/>
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular (Taboq ) soni</label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getIlmiyseminarName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">Ilmiy seminar raisi sifatida</option>

                           <option value="2">Ilmiy seminar  ilmiy kotibi</option>
                           <option value="3">Ilmiy seminar  a’zosi</option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
