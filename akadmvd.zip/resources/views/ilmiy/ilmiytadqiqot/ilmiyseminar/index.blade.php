@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy seminar ishida ishtirok etish (2 tagacha kengash inobatga olinadi)</h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Kengash nomi</th>
                <th>Ishtiroki</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($ilmiyseminar as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/ilmiyseminar/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editilmiyseminar',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>


                        </td>
                        <td>
                            <a href="{{route('ilmiyseminar.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"></i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
