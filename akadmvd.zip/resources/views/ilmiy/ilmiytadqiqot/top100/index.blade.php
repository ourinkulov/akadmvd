@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Oliy ta’lim muassasalarning birinchi mingtalik yoki fan yо‘nalishlari bо‘yicha birinchi yuztalik xalqaro  reytinglarga kirgan OTMning onlayn ta’lim platformalariga ma’ruza joylashtirish yoki sayyor shaklda ma’ruza о‘tkazish</h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>OTM Nomlanishi</th>
                <th>Sana</th>
                <th>Ilova (Havola)</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($top100 as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>

                        <td><a href="{{asset('storage/top100/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editetop100',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>

                        </td>
                        <td>

                            <a href="{{route('ilmiytop100.destroy',$item->id)}}"><i class="fa-2x fa fa-trash" style="color: indianred"> </i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
