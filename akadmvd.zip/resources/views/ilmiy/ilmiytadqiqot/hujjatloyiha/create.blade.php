@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiyhujjatloyiha')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Normativ-huquqiy hujjatlar loyihasini tayyorlashda ishtirok etish (Normativ-huquqiy hujjatlar qabul qilish huquqiga ega bо‘lgan organ tomonidan qabul qilinganda
                   )</h5>
               <hr>
               <form action="{{route('ilmiy.updatehujjatloyiha',$hujjatloyiha->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text" value="{{$hujjatloyiha->user_name}}" name="user_name"  class="form-control"/>
                   </div>


                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getLoyihaName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">О‘zbekiston Respublikasining qonunlari</option>
                           <option value="2">О‘zbekiston Respublikasi Prezidentining farmonlari va qarorlari</option>
                           <option value="3">Vazirlar Mahkamasining qarorlari</option>
                           <option value="4">Vazirliklar, davlat qо‘mitalari va idoralarning buyruqlari hamda qarorlari</option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" id="ball_id" name="ball"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
