@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Normativ-huquqiy hujjatlar loyihasini tayyorlashda ishtirok etish (Normativ-huquqiy hujjatlar qabul qilish huquqiga ega bо‘lgan organ tomonidan qabul qilinganda
            )</h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Taklif mavzusi</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($hujjatloyiha as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/hujjatloyiha/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.edithujjatloyiha',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>


                        </td>
                        <td><a href="{{route('ilmiyhujjatloyiha.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"></i></a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
