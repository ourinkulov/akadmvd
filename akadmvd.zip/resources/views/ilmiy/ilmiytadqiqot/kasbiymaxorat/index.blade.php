@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Kasbiy mahorat (pedagogik faoliyat,
            ilmiy-tadqiqot ishi, sport musobaqalari) tanlovi (konkurs)da faxrli о‘rinlarni egallaganligi va Fan olimpiadalari, sport musobaqalari, tanlovlarda g‘oliblikni qо‘lga kiritgan kursantlarni tayyorlagani
        </h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Mavzusi</th>
                <th>Natija</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($kasbiymaxorat as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/kasbiymaxorat/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editekasbiymaxorat',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
                        <td>

                            <a href="{{route('ilmiykasbiymaxorat.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"></i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
