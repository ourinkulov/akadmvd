@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiyraxbar')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>kursantlarining bitiruv malakaviy ishiga Magistratura tinglovchisining magistrlik dissertatsiyasi
                   va ilmiy-tadqiqot ishiga rahbarlik (ilmiy maslahatchilik) qilish
               </h5>
               <hr>
               <form action="{{route('ilmiy.updateraxbar',$raxbar->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif </label>
                       <input type="text" value="{{$raxbar->user_name}}" class="form-control">
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Kursant/Tinlovchilar soni </label>
                       <input type="number" name="soni"  id="soni_id" min="1" max="5" class="form-control" value="{{$raxbar->soni}}"/>
                   </div>

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Darajasi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getRaxbarName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">Bakalavriat ta’lim yо‘nalishi kursantlarining bitiruv malakaviy ishiga rahbarlik qilish, xulosalar yozish </option>
                           <option value="2">Magistratura tinglovchisining magistrlik dissertatsiyasi
                               va ilmiy-tadqiqot ishiga rahbarlik (ilmiy maslahatchilik) qilish
                           </option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
