@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>kursantlarining bitiruv malakaviy ishiga Magistratura tinglovchisining magistrlik dissertatsiyasi
            va ilmiy-tadqiqot ishiga rahbarlik (ilmiy maslahatchilik) qilish
        </h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Til</th>
                <th>Turi</th>
                <th>Soni</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($raxbar as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->soni}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/raxbar/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editeraxbar',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>

                        </td>
                        <td>
                            <a href="{{route('ilmiyraxbar.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
