@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy darajalar beruvchi xorijiy ilmiy, ekspertlik, ilmiy-texnik kengashlarda ishtirok etish</h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Nomlanishi</th>
                <th>A'zo bo'lgan sana</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($horijiykengash as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->sana}}</td>

                        <td><a href="{{asset($item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.edithorijiykengash',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>

                        </td>
                        <td>

                            <a href="{{route('ilmiyhorijiykengash.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
