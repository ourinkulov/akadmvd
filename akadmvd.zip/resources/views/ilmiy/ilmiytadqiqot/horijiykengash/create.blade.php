@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiyhorijiykengash')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Ilmiy darajalar beruvchi xorijiy ilmiy, ekspertlik, ilmiy-texnik kengashlarda ishtirok etish</h5>
               <hr>
               <form action="{{route('ilmiy.updatehorijiykengash',$horijiykengash->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Horijiy kengash nomi</label>
                        <input type="text" class="form-control" name="title" value="{{$horijiykengash->title}}">
                    </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text" class="form-control" name="title" value="{{$horijiykengash->user_name}}">
                   </div>


{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mualliflar soni</label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="">Turi</label>--}}
{{--                       <select name="turi_id" id="turi_id" class="form-control" onchange="getIqtibosName()">--}}
{{--                           <option value="0">Tanlang</option>--}}
{{--                           <option value="1">Web of Science, Scopus nashrlarida berilgan iqtiboslar </option>--}}
{{--                           <option value="2">Xalqaro RINS (Ilmiy iqtibos indeksi)  ma’lumotlar bazasiga kiritilgan boshqa nashrlarda e’lon qilingan ishlarga berilgan iqtiboslar</option>--}}
{{--                           <option value="3">О‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Oliy attestatsiya komissiyasi tomonidan tavsiya etilgan nashrlarda e’lon qilingan ishlarga berilgan iqtiboslar</option>--}}

{{--                       </select>--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" name="ball" id="ball_id"  class="form-control" value="15"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
