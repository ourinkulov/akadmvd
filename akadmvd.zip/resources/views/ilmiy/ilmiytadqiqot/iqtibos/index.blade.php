@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Iqtiboslar (H-indeks):</h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Mavzusi</th>
                <th>Turi</th>
                <th>Mualliflar soni</th>
                <th>Taboqlar soni</th>
                <th>Havola</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($iqtibos as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->soni}}</td>
                        <td>{{$item->taboq}}</td>
                        <td><a href="{{asset($item->havola)}}" target="_blank"><i class="fa fa-link"></i></a></td>
                        <td><a href="{{asset('storage/iqtibos/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editiqtibos',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>


                        </td>
                        <td> <a href="{{route('ilmiyiqtibos.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
