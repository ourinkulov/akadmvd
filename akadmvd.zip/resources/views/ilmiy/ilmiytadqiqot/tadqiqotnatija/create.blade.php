@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiytadqiqotnatija')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Tadqiqot natijalarini amaliyotga joriy qilinganligi haqida markaziy davlat organlari va davlat boshqaruv organlarining dalolatnomasi (Dalolatnoma olingan yil
                   uchun
                   )</h5>
               <hr>
               <form action="{{route('ilmiy.updatetadqiqotnatija',$tadqiqotnatija->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
{{--                    <div class="form-group">--}}
{{--                        <label for="" class="bg-white p-2 border-bottom-info">Taklif mazmuni</label>--}}
{{--                        <textarea name="title" id="" cols="30" rows="10" class="form-control" value="{{$tadqiqotnatija->title}}"></textarea>--}}
{{--                    </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Muallif</label>
                       <input type="text" name="title"  class="form-control" value="{{$tadqiqotnatija->user_name}}"/>
                   </div>

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getTadqiqotnatijaName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">О‘zbekiston Respublikasi Oliy Majlisi Qonunchilik palatasi, Vazirlar mahkamasi</option>
                           <option value="2">Vazirlik va qо‘mitalar</option>
                           <option value="3">Oliy ta’lim muassasalari </option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="">Ball</label>
                       <input type="text" id="ball_id" name="ball" class="form-control">
                   </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ilova (PDF yoki rasm shaklda | Qarorning skaneri)</label>--}}
{{--                       <input type="file" name="file"  class="form-control"/>--}}
{{--                   </div>--}}

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
