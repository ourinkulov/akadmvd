@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy darajalarni tasdiqlash</h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Diplom berilgan sana</th>
                <th>Ilova</th>
                <th>Status</th>
                <th>Tasdiqlash</th>
                </thead>
                <tbody>
                @foreach($ilmiydaraja as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>

                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->sana}}</td>
                        <td><a href="{{asset('storage/ilmiydaraja/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>@if($item->status == 1) <button class="btn btn-warning">Tasdiqlanmagan</button> @else <button class="btn btn-success">Tasdiqlangan</button>@endif</td>
                        @if($item->status == 2) <td></td>
                        @else
                        <td>
                            <a href="{{route('ilmiy.editilmiydaraja',$item->id)}}"><i class="fa fa-edit"> Tasdiqlash</i></a>
                            <hr>
                            <a href="{{route('ilmiy.destroy',$item->id)}}"><i class="fa fa-trash" style="color: indianred">  O'chirish </i></a>
                        </td>
                        @endif
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
