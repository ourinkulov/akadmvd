@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Akademiya mezbon sifatida ishtirok etadigan nufuzli xalqaro konferensiyada (simpozium, davra suhbati),Xorijiy mamlakatlarda tashkil qilingan ilmiy-pedagogik faoliyatga oid xalqaro tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar) taklifga asosan ma’ruza bilan qatnash va  Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da qatnashish </h5>
        <div class="row">
            @if ($message = Session::get('status'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif
            @if ($message = Session::get('danger'))
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>{{ $message }}</strong>
                </div>
            @endif

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Mavzusi</th>
                <th>Turi</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                    @foreach($konferensiya as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        @if($item->turi_id==1)
                            <td><p>Akademiya mezbon sifatida ishtirok etadigan nufuzli xalqaro konferensiyada:tashkiliy guruh ishida ishtirok etish</p></td>
                        @elseif($item->turi_id==2)
                            <td><p>Akademiya mezbon sifatida ishtirok etadigan nufuzli xalqaro konferensiyada:ma’ruzachi sifatida ishtirok etish </p></td>
                        @elseif($item->turi_id==3)
                            <td><p>Xorijiy mamlakatlarda tashkil qilingan ilmiy-pedagogik faoliyatga oid xalqaro tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar) taklifga asosan ma’ruza bilan qatnashish </p></td>
                        @elseif($item->turi_id==4)
                            <td><p>Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: tashkiliy guruh ishida qatnashish </p></td>
                        @elseif($item->turi_id==5)
                            <td><p>Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: ma’ruzachi sifatidagi qatnashish </p></td>
                        @elseif($item->turi_id==6)
                            <td><p>Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: ishtirokchi sifatida qatnashish </p></td>
                        @endif

                        <td><a href="{{asset('storage/konferensiya/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editekonferensiya',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>

                        </td>
                        <td>

                            <a href="{{route('ilmiykonferensiya.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"></i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
