@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiykonferensiya')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Dissertatsiya tadqiqoti bо‘yicha taqriz berish</h5>
               <hr>
               <form action="{{route('ilmiy.updatekonferensiya',$konferensiya->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Mavzu</label>
                        <input type="text" name="title" class="form-control" value="{{$konferensiya->title}}">
                    </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular (Taboq ) soni</label>--}}
{{--                       <input type="number" name="soni"  class="form-control"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Mavzular soni</label>--}}
{{--                       <input type="number" name="mavzu_soni"  class="form-control"/>--}}
{{--                   </div>--}}

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getKonfName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">Akademiya mezbon sifatida ishtirok etadigan nufuzli xalqaro konferensiyada:tashkiliy guruh ishida ishtirok etish  </option>
                           <option value="2">Akademiya mezbon sifatida ishtirok etadigan nufuzli xalqaro konferensiyada:ma’ruzachi sifatida ishtirok etish </option>
                           <option value="3">Xorijiy mamlakatlarda tashkil qilingan ilmiy-pedagogik faoliyatga oid xalqaro tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar) taklifga asosan ma’ruza bilan qatnashish </option>
                           <option value="4">Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: tashkiliy guruh ishida qatnashish </option>
                           <option value="5">Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: ma’ruzachi sifatidagi qatnashish </option>
                           <option value="6">Ilmiy-pedagogik faoliyatga oid Respublika miqyosidagi tadbirlarda (forumlar, konferensiyalar, kongresslar, anjumanlar va boshqalar)da: ishtirokchi sifatida qatnashish </option>                      </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball (Akademiya miqyosidagi tadbir uchun ushbu ballning
                           50 foiz beriladi
                           )</label>
                       <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
