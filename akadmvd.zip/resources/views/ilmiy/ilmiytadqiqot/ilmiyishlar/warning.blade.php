@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>E’lon qilingan ilmiy ishlar</h5>
        <div class="row">

        </div>
        <a href="{{route('ilmiy.ilmiyilmiyishlar')}}"><button class="btn btn-info">Ortga</button></a>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Mavzusi</th>
                <th>Turi</th>
                <th>Mualliflar soni</th>
                <th>Taboqlar soni</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
{{--                <th>Shubhali deb belgilash</th>--}}
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($ilmiyishlar as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td>{{$item->soni}}</td>
                        <td>{{$item->taboq}}</td>
                        <td><a href="{{asset('storage/ilmiyishlar/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editilmiyishlar',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>
                        </td>
{{--                        <td>--}}
{{--                            <a href="{{route('ilmiyilmiyishlar.warning',$item->id)}}"><button class="btn btn-warning"><i class="fa fa-link-slash"></i></button></a>--}}
{{--                        </td>--}}
                        <td>
                            <a href="{{route('ilmiyilmiyishlar.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
