@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiyilmiyishlar')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>E’lon qilingan ilmiy ishlar</h5>
               <hr>
               <form action="{{route('ilmiy.updateilmiyishlar',$ilmiyishlar->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Mavzu</label>
                        <input type="text" class="form-control" name="title" value="{{$ilmiyishlar->title}}">
                    </div>
{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info"> Taboq  soni</label>--}}
{{--                       <input type="number" name="taboq"  id="taboq_soni" class="form-control" value="{{$ilmiyishlar->taboq}}"/>--}}
{{--                   </div>--}}

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Mualliflar soni</label>
                       <input type="number" name="soni"  id="muallif_soni" class="form-control" value="{{$ilmiyishlar->soni}}"/>
                   </div>

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getIlmiyishlarName()">
                           <option value="0">Tanlang</option>
                           <option value="1">Scopus ma’lumotlar hamda Web of Science indeksatsiyalangan ma’lumotlar bazalari jurnallarida e’lon qilingan ilmiy maqola </option>
                           <option value="2">Xalqaro RINS (Ilmiy iqtibos indeksi)  ma’lumotlar bazasiga kiritilgan nashrlarda e’lon qilingan ishlar</option>
                           <option value="3">О‘zbekiston Respublikasi Vazirlar Mahkamasi huzuridagi Oliy attestatsiya komissiyasi tomonidan tavsiya etilgan mahalliy nashrlarda yoki yopiq tо‘plamda e’lon qilingan ishlar</option>
                           <option value="4">Xalqaro konferensiya materiallari tо‘plamida e’lon qilingan ishlar</option>
                           <option value="5">Respublika ilmiy va ilmiy-amaliy konferensiya</option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" name="ball" id="ball_id"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden" value="0">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
