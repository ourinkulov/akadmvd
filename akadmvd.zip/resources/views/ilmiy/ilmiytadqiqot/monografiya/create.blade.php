@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                @if ($message = Session::get('status'))
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                    </div>
                @endif
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong>{{ $message }}</strong>
                        </div>
                    @endif
            </div>
        </div>
        <a href="{{route('ilmiy.ilmiymonografiya')}}"><button class="btn btn-info">Ortga</button></a>
       <div class="row">
           <div class="col-md-6">
               <h5>Monografiya tayyorlash va nashr etish (Bir bosma taboq uchun
                   (hammualliflarga teng taqsimlanadi)
                   )</h5>
               <hr>
               <form action="{{route('ilmiy.updatemonografiya',$monografiya->id)}}" method="POST" enctype="multipart/form-data">
                   @csrf
                    <div class="form-group">
                        <label for="" class="bg-white p-2 border-bottom-info">Mavzu</label>
                        <input type="text" class="form-control" name="title" value="{{$monografiya->title}}">
                    </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info"> Taboq  soni</label>
                       <input type="number" name="taboq" id="taboq_soni" class="form-control" value="{{$monografiya->taboq}}"/>
                   </div>

{{--                   <div class="form-group">--}}
{{--                       <label for="" class="bg-white p-2 border-bottom-info">Ximoya qilingan sana</label>--}}
{{--                       <input type="date" name="sana" placeholder="Darslik yaratilgan sana" class="form-control"/>--}}
{{--                   </div>--}}
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Mualliflar soni</label>
                       <input type="number" name="soni"  id="muallif_soni" class="form-control" value="{{$monografiya->soni}}"/>
                   </div>

                   <div class="form-group">
                       <label for="">Turi</label>
                       <select name="turi_id" id="turi_id" class="form-control" onchange="getMonografiyaName2()">
                           <option value="0">Tanlang</option>
                           <option value="1">Mahalliy nashrlarda: dissertatsiya doirasida</option>
                           <option value="2">Mahalliy nashrlarda: dolzarb mavzularda</option>
                           <option value="3">Xorijiy nashrlarda: dissertatsiya doirasida</option>
                           <option value="4">Xorijiy nashrlarda: dolzarb mavzularda</option>

                       </select>
                   </div>
                   <div class="form-group">
                       <label for="" class="bg-white p-2 border-bottom-info">Ball</label>
                       <input type="text" id="ball_id" name="ball"  class="form-control"/>
                   </div>

                   <input id="turi_name_id" name="turi_name" type="hidden">
                   <button class="btn btn-primary" type="submit">Yaratish</button>
               </form>
           </div>
       </div>
    </div>
@endsection
