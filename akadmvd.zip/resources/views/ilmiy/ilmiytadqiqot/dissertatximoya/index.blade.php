@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Dissertatsiyaning о‘z vaqtida yoki muddatidan oldin himoya </h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Turi</th>
                <th>Ximoya uchun berilgan muddat</th>
                <th>Ximoya sanasi</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($dissertatximoya as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>

                        <td>{{$item->ximoya_belgilangan_sana}}</td>
                        <td>{{$item->ximoya_sana}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/dissertathimoya/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editilmiydissertathimoya',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>

                        </td>
                        <td>

                            <a href="{{route('ilmiydissertathimoya.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
