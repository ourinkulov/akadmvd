@extends('layouts.ilmiyapp')
@section('content')
    <div class="container-fluid">
        <h5>Ilmiy, ilmiy-ommabop jurnallar tahrir hay’ati a’zoligi (OAK hamda Axborot va ommaviy kommunikatsiyalar agentligi rо‘yxatidan о‘tgan)</h5>
        <div class="row">

        </div>
        <div class="row mt-2">
            <table class="table table-responsive-lg">
                <thead class="bg-white">
                <th>#</th>
                <th>Muallif</th>
                <th>Jurnal nomi</th>
                <th>Ishtiroki</th>
                <th>Ilova</th>
                <th>Tasdiqlash</th>
                <th>O'chirish</th>
                </thead>
                <tbody>
                @foreach($jurnal as $item)
                    <tr>
                        <td>{{++$i}}</td>
                        <td>{{$item->user_name}}</td>
                        <td>{{$item->title}}</td>
                        <td>{{$item->turi_name}}</td>
                        <td><a href="{{asset('storage/jurnal/'.$item->file)}}"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="{{route('ilmiy.editjurnal',$item->id)}}"><button class="btn btn-info"><i class="fa fa-edit"></i></button></a>


                        </td>
                        <td><a href="{{route('ilmiyjurnal.destroy',$item->id)}}"><i class="fa fa-2x fa-trash" style="color: indianred"> </i></a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
