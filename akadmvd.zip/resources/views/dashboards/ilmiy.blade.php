@extends('layouts.ilmiyapp')
@section('content')
   <div class="container-fluid">
       <h>Ilmiy Dashboard</h>
       <h>Tez kunda ...</h>
   </div>
@endsection
