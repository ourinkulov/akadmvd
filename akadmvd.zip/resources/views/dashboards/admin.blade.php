@extends('layouts.app') @section('content') <div class="container-fluid">
    {{-- <div class="row">
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                                <a  href="{{route('admin.getallreyting')}}" style="text-underline-color: white">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1" >
                                    Professor-o'qituvchilar</div>
                                </a>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{$allTeachersCount}}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user fa-2x text-success"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Ilmiy darajaga ega xodimlar</div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">{{$idarajaDSC+$idarajaPHD}}</div>
                                </div>
                                <div class="col">
                                    <div class="progress progress-sm mr-2">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: {{(($idarajaDSC+$idarajaPHD)/$allTeachersCount)*100}}%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            {{number_format((($idarajaDSC+$idarajaPHD)/$allTeachersCount)*100,2,'.',',')}}%
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Fan doktorlari</div>
                            <a href="{{route('admin.getusershasdsdaraja')}}">
                                <div class="h5 mb-0 font-weight-bold text-gray-800">{{$idarajaDSC}}</div>
                            </a>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: {{(($idarajaDSC)/$allTeachersCount)*100}}%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                        </div>
                        <div class="col-auto">
                            {{number_format(($idarajaDSC/$allTeachersCount)*100,2,'.',',')}}%
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Falsafa doktorlari</div>
                            <a href="{{route('admin.usershasphddaraja')}}">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{$idarajaPHD}}</div>
                            </a>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: {{(($idarajaPHD)/$allTeachersCount)*100}}%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                        </div>
                        <div class="col-auto">
                            {{number_format(($idarajaPHD/$allTeachersCount)*100,2,'.',',')}}%
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Professorlar</div>
                            <a href="{{route('admin.getprofessor')}}">
                                <div class="h5 mb-0 font-weight-bold text-gray-800">{{$iunvonProfessor}}</div>
                            </a>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: {{(($iunvonProfessor)/$allTeachersCount)*100}}%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            {{number_format(($iunvonProfessor/$allTeachersCount)*100,2,'.',',')}}%
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Dotsentlar</div>
                            <a href="{{route('admin.getdotsents')}}">
                                <div class="h5 mb-0 font-weight-bold text-gray-800">{{$iunvonDotsent}}</div>
                            </a>
                            <div class="col">
                                <div class="progress progress-sm mr-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: {{(($iunvonDotsent)/$allTeachersCount)*100}}%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                        </div>
                        <div class="col-auto">
                            {{number_format(($iunvonDotsent/$allTeachersCount)*100,2,'.',',')}}%
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
    {{-- <div class="row">
        <div>
            <canvas id="lineChartID" height="5vh" width="50vw" class="bg-white"></canvas>
        </div>
    </div>
    <hr>
    <div class="row">
        <div>
            <canvas id="lineChartPHD" height="5vh" width="50vw" class="bg-white"></canvas>
        </div>
    </div> --}}
    <hr>
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0  ">Professor-o'qituvchilar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table  " id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center " style=" font-size: 16px; background-color: rgb(252,252,252)">
                        <th>Reyting</th>
                        <th>-</th>
                        <th>F.I.O</th>
                        <th>Lavozim</th>
                        <th>Kafedra</th>
                        <th>Ball</th>
                        </thead>
                        <tbody> @foreach($allrating as $k => $item)
                        <tr>
                            <td>
                                <tr >
                            <td rowspan="2">{{++$k}}</td>
                            <td rowspan="2" >
                                <a href="{{route('admintouser.getoneteacherresult',$item->user_id)}}">
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </a>
                            </td>
                            <td>
                                <a href="{{route('admintouser.getoneteacherresult',$item->user_id)}}">{{$item->name}}</a>
                            </td>
                            <td>{{$item->lavozim}}</td>
                            <td>{{$item->kaf_name}}</td>
                            <td>
                                <strong>{{$item->allball}}</strong>
                                <sub>@if(!empty($item->jball)) (<i class="text-success">{{$item->ball}}</i>-<i class="text-danger">{{$item->jball}}</i>{{')'}} @endif   </sub>
                            </td>
                        </tr>
                        <tr>

                            <td  colspan="4">
                                <div class="progress">
                                    <div
                                        @php
                                            $color = null;
                                        @endphp
                                        @if($item->allball >= 600)
                                            class="progress-bar bg-success"
                                        @elseif($item->allball < 600 && $item->allball >= 300)
                                            class="progress-bar bg-info"
                                        @elseif($item->allball >=200 && $item->allball < 300)
                                            class="progress-bar bg-warning"
                                        @elseif($item->allball < 200)
                                            class="progress-bar bg-danger"
                                        @endif
                                        role="progressbar" style="width: {{$item->ball*100/1000}}%" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" >
                                        @if($item->allball >= 600)
                                            {{$item->allball*100/1000}}% - Lider
                                        @elseif($item->allball >= 300 && $item->allball < 600)
                                            {{$item->allball*100/1000}}% - Faol
                                        @elseif($item->allball < 300 && $item->allball >= 200 )
                                            {{$item->allball*100/1000}}% - Qoniqarli
                                        @elseif($item->allball < 200)
                                            {{$item->allball*100/1000}}% - Qoniqarsiz
                                        @endif
                                    </div>
                                </div>
                            </td>
                        </tr>

                            </td>

                        </tr>

                        @endforeach
                        </tbody>
                    </table>
                    <a href="{{route('admin.getallreyting')}}">
                        <button class="btn btn-primary">Batafsil ...</button>
                    </a>
                </div>
            </div>

        </div>
        <div class="col-lg-6 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0">Kafedralar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table   table-responsive-lg" id="dataTable" width="100%" cellspacing="0" style="color: #3f3b3b; font-weight: bold">
                        <thead class="text-center " style=" font-size: 16px; background-color: rgb(252,252,252)">
                        <tr>
                            <th>Reyting</th>
                            <th>Kafedra nomi</th>
                            <th>O'qituvchilar</th>
                            <th>O'rtacha ball</th>
                        </tr>
                        </thead>
                        @foreach($kafs as $k=>$item) <tr
                            @if($item->allball > 300) style="background-color: #289947"
                            @elseif($item->allball > 150) style="background-color: #2d7bec"
                            @elseif($item->allball > 100) style="background-color: #f9bf1a"
                            @else($item->ball < 100) style="background-color: #e33e30"
                            @endif >


{{--                                @php--}}
{{--                                for ($i=1; $i<=count($value->kaf_id); $i++)--}}
{{--                                    for ($j = $i+1; $j<=count($kafUsersCount); $j++)--}}
{{--                                        {--}}
{{--                                            if ($value[$i] < $value[$j])--}}
{{--                                                {--}}
{{--                                                    $value[0] = $value[$i];--}}
{{--                                                    $value[$i] = $value[$j];--}}
{{--                                                    $value[$j] = $value[0];--}}

{{--                                                }--}}
{{--                                        }--}}
{{--                                print $value;--}}
{{--                                @endphp--}}






                                    <td style=" color: whitesmoke">{{++$k}}</td>
                                    <td style="color: whitesmoke">{{$item->kaf_name}}</td>
                                    <td style="color: whitesmoke">{{number_format($item->user_count,1)}} </td>
                                <td>
                                    <h5>
                                        <strong>{{number_format($item->allball,3)}}</strong>
                                        <sub style="font-size: 12px">@if(!empty($item->jball)) (<i class="text-success">{{number_format($item->ball,2)}}</i>-<i class="text-danger">{{number_format($item->jball,2)}}</i>{{')'}} @endif   </sub>
                                    </h5>

                                </td>




                        </tr> @endforeach <tfoot>
                        <tr>
                            <th>Reyting</th>
                            <th>Kafedra nomi</th>
                            <th>O'qituvchilar</th>
                            <th>Ball</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        {{-- @foreach ($kaff as $kaf)--}}
                        {{-- <tr>--}}
                        {{-- <td>{{++$g}}</td>--}} {{-- <td>{{$kaf->kname}}</td>--}} {{-- <td>{{number_format($kaf->ball,1)}}</td>--}} {{-- </tr>--}}
                        {{-- @endforeach--}}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

{{--    <div class="row">--}}
{{--        <div class="col-xl-3 col-md-6 mb-4">--}}
{{--            <div class="card border-left-primary shadow h-100 py-2">--}}
{{--                <div class="card-body">--}}
{{--                    <div class="row no-gutters align-items-center">--}}
{{--                        <div class="col mr-2">--}}
{{--                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">O'quv materiallari</div>--}}
{{--                            <div class="h5 mb-0 font-weight-bold text-gray-800">250</div>--}}
{{--                        </div>--}}
{{--                        <div class="col-auto">--}}
{{--                            <i class="fa fa-book-open fa-2x text-primary"></i>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <div class="col-xl-3 col-md-6 mb-4">--}}
{{--            <div class="card border-left-success shadow h-100 py-2">--}}
{{--                <div class="card-body">--}}
{{--                    <div class="row no-gutters align-items-center">--}}
{{--                        <div class="col mr-2">--}}
{{--                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Ochiq va maxorat darslari</div>--}}
{{--                            <div class="h5 mb-0 font-weight-bold text-gray-800">90</div>--}}
{{--                        </div>--}}
{{--                        <div class="col-auto">--}}
{{--                            <i class="fas fa-address-card fa-2x text-success"></i>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <div class="col-xl-3 col-md-6 mb-4">--}}
{{--            <div class="card border-left-info shadow h-100 py-2">--}}
{{--                <div class="card-body">--}}
{{--                    <div class="row no-gutters align-items-center">--}}
{{--                        <div class="col mr-2">--}}
{{--                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">To'garaklar</div>--}}
{{--                            <div class="row no-gutters align-items-center">--}}
{{--                                <div class="col-auto">--}}
{{--                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">32</div>--}}
{{--                                </div>--}}
{{--                                <div class="col">--}}
{{--                                    <div class="progress progress-sm mr-2">--}}
{{--                                        <div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="col-auto">--}}
{{--                            <i class="fas fa-calendar fa-2x text-info"></i>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--        <div class="col-xl-3 col-md-6 mb-4">--}}
{{--            <div class="card border-left-secondary shadow h-100 py-2">--}}
{{--                <div class="card-body">--}}
{{--                    <div class="row no-gutters align-items-center">--}}
{{--                        <div class="col mr-2">--}}
{{--                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Malaka oshirishlar</div>--}}
{{--                            <div class="h5 mb-0 font-weight-bold text-gray-800">68</div>--}}
{{--                        </div>--}}
{{--                        <div class="col-auto">--}}
{{--                            <i class="fas fa-comments fa-2x text-warning"></i>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
    <div class="row">

        <div class="col-lg-6 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">O‘quv yuklamasi bilan bog‘liq ishlar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                        <th>Reyting</th>
                        <th>-</th>
                        {{-- <th>Rasm</th>--}}
                        <th>F.I.O</th>
                        <th>Lavozim</th>
                        <th>Kafedra</th>
                        <th>Ball</th>
                        </thead>
                        <tbody>
                        {{-- @foreach($teach_reyting as $k=>$item)--}}
                        {{-- <tr>--}}
                        {{-- <td>{{++$k}}</td>--}} {{-- <td>
											<img src="{{asset('storage/profileimages/'.$item->profileimage)}}" alt="" width="64px" style="border-radius: 45%;"> </td>--}} {{-- <td>{{$item->name}}</td>--}} {{-- <td>{{$item->lavozim}}</td>--}} {{-- <td>{{$item->kafName}}</td>--}} {{-- <td>{{$item->ball}}</td>--}} {{-- </tr>--}}
                        {{-- @endforeach--}}
                        </tbody> @foreach($usr as $k=>$item) <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </td>
                            <td>{{$item->name}}</td>
                            {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                            <td>{{$item->ball}}</td>
                        </tr> @endforeach </tbody>
                    </table>
{{--                    <a href="{{route('admin.getreting','3e47d333-ee16-4f76-aaae-861c57000c93')}}">--}}
{{--                        <button class="btn btn-primary">Batafsil ...</button>--}}
{{--                    </a>--}}
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">О‘quv-uslubiy ishlar reytingi</h6>
                    </div>
                    <div class="card-body">
                        <table class="table  table-hover table-responsive-lg" id="dataTable" width="100%" cellspacing="0">
                            <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                            <tr>
                                <th>Reyting</th>
                                <th>-</th>
                                <th>F.I.O</th>
                                <th>Kafedra nomi</th>
                                <th>Ball</th>
                            </tr>
                            </thead>
                            {{-- {{--
                                                              <tfoot>--}}
                            {{-- <tr>--}}
                            {{-- <th>Reyting</th>--}}
                            {{-- <th>Kafedra nomi</th>--}}
                            {{-- <th>Ball</th>--}}
                            {{-- </tr>--}}
                            {{-- </tfoot>--}}
                            <tbody> @foreach($uyr as $k=>$item) <tr>
                                <td>{{++$k}}</td>
                                <td>
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </td>
                                <td>{{$item->name}}</td>
                                {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                                <td>{{$item->ball}}</td>
                            </tr> @endforeach </tbody>
                        </table>
{{--                        <a href="{{route('admin.getreting','d4e45598-6033-4543-89cf-eed106f1127e')}}">--}}
{{--                            <button class="btn btn-primary">Batafsil ...</button>--}}
{{--                        </a>--}}
                    </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ilmiy tadqiqot ishlar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                        <th>Reyting</th>
                        <th>-</th>
                        {{-- <th>Rasm</th>--}}
                        <th>F.I.O</th>
                        <th>Lavozim</th>
                        <th>Kafedra</th>
                        <th>Ball</th>
                        </thead>
                        <tbody> @foreach($iir as $k=>$item) <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </td>
                            <td>{{$item->name}}</td>
                            {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                            <td>{{$item->ball}}</td>
                        </tr> @endforeach </tbody>
                        <tbody></tbody>
                    </table>
{{--                    <a href="{{route('admin.getreting','a86e6ca3-9bdc-45ce-a03f-a116315e5d71')}}">--}}
{{--                        <button class="btn btn-primary">Batafsil ...</button>--}}
{{--                    </a>--}}
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Jamoat ishlaridagi ishtiroki (“Ustoz-shogird” ishlari)</h6>
                </div>
                <div class="card-body">
                    <table class="table  table-hover table-responsive-lg" id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                        <tr>
                            <th>Reyting</th>
                            <th>-</th>
                            <th>F.I.O</th>
                            <th>Kafedra nomi</th>
                            <th>Ball</th>
                        </tr>
                        </thead>
                        {{-- @foreach($kafedra_reyting as $item=>$k)--}}
                        {{-- <tr>--}}
                        {{-- <td>{{++$item}}</td>--}} {{-- <td>{{$k->kafName}}</td>--}} {{-- <td>{{$k->ball}}</td>--}} {{-- </tr>--}}
                        {{-- @endforeach--}}
                        {{-- <tfoot>--}}
                        {{-- <tr>--}}
                        {{-- <th>Reyting</th>--}}
                        {{-- <th>Kafedra nomi</th>--}}
                        {{-- <th>Ball</th>--}}
                        {{-- </tr>--}}
                        {{-- </tfoot>--}}
                        <tbody> @foreach($jir as $k=>$item) <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </td>
                            <td>{{$item->name}}</td>
                            {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                            <td>{{$item->ball}}</td>
                        </tr> @endforeach </tbody>
                    </table>
{{--                    <a href="{{route('admin.getreting','a843760e-2a2c-4446-aca7-a696d3dd355c')}}">--}}
{{--                        <button class="btn btn-primary">Batafsil ...</button>--}}
{{--                    </a>--}}
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0  ">Ma'lumot taqdim etmagan professor-o'qituvchilar</h6>
        </div>
        <div class="card-body">
            <table class="table  " id="dataTable" width="100%" cellspacing="0">
                                        <thead class="text-center " style=" font-size: 16px; background-color: rgb(252,252,252)">
                                        <th>Reyting</th>
                                        <th>-</th>
                                        <th>F.I.O</th>
                                        <th>Lavozim</th>
                                        <th>Kafedra</th>
                                        <th>Ball</th>
                                        </thead>
                <tbody>
                @foreach($passiveTeachs as $k => $item)
                    <tr>
                        <td>{{++$k}}</td>
                        <td>
                            <a href="{{route('admintouser.getoneteacherresult',$item->id)}}">
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </a>
                        </td>
                        <td>
                            <a href="{{route('admintouser.getoneteacherresult',$item->id)}}">{{$item->name}}</a>
                        </td>
                        <td>{{$item->lavozim}}</td>
                        <td>{{$item->kaf_name}}</td>
                @endforeach
                </tbody>
            </table>
            <a href="{{route('admin.getallreyting')}}">
                <button class="btn btn-primary">Batafsil ...</button>
            </a>
        </div>
    </div>
</div>
<script>

    // line chart
    new Chart($("#lineChartID"), {
        type: 'line',
        data: {
            labels: [
                '1991', '1995', '1998',
                '2003', '2005', '2006',
                '2008','2009', '2011',
                '2016', '2018','2019',
                '2020', '2021', '2022',
                '2023'
            ],
            datasets: [{
                label: 'Fan doktori (DSc) ilmiy darajasi dinamikasi',
                data: [1, 1, 1, 2, 1, 1, 1,1,1,3,2,3,1,3,4,1
                ],// End data
                borderColor: 'green',
                fill: false,
                tension: 0.1,
                steps:1
            }]// End datasets
        }// End data
    });

    new Chart($("#lineChartPHD"), {
        type: 'line',
        data: {
            labels: [
                '1982', '1986',
                '1987', '1988', '1989',
                '1992', '1993', '1994',
                '1995','1996', '1997',
                '1999', '2000','2001',
                '2002', '2004', '2006',
                '2007','2008','2009',
                '2011','2012','2018',
                '2019','2020','2021',
                '2022','2023'
            ],
            datasets: [{
                label: 'Falsafa doktori (PhD) ilmiy darajasi dinamikasi',
                data: [2,1,1,1,1,1,1, 1,2, 1, 2, 3, 1,1,2,1,1,3,1,2,4,6,3,1,8,11,18,12,7
                ],// End data
                borderColor: 'orange',
                fill: false,
                tension: 0.1
            }]// End datasets
        }// End data
    });

</script>
@endsection
