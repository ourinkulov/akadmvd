@extends('layouts.nachkafapp')
@section('content')
    <div class="container-fluid">
{{--        <h>Kafedra boshlig'i kabineti</h>--}}

        <div class="row">
            <div class="col-md-6 offset-4">
                <div class="col-md-6 m-2">
                    <div class="card text-center pt-2">
                        <div class="card-block">
                            <h4 class="card-title"> Professor-o'qituvchilar soni</h4>
                            <h6><i class="fa fa-users fa-3x"></i></h6>
                        </div>
                        <div class="row px-2 no-gutters">
                            <div class="col-6">
                                <h3 class="card card-block border-top-0 border-left-0 border-bottom-0 ">{{$teacherCount}}/{{$dotsWithoutDegree}}</h3>
                            </div>
                            <div class="col-6">
                                <h3 class="card card-block border-top-0 border-left-0 border-bottom-0 border-right-0">
                                    {{ $teacherCount > 0 ? number_format(($dsc + $phd + $dotsWithoutDegree) * 100 / $teacherCount, 2) : '0.00' }}

                                    %</h3>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-md-2 m-2">
                <div class="card text-center  pt-2">
                    <div class="card-block">
                        <h3 class="card-title"> DSc ilmiy darajasi mavjud</h3>
                        <h6><i class="fa fa-graduation-cap fa-3x"></i></h6>
                    </div>
                    <div class="row px-2 no-gutters">
                        <div class="col-6">
                            <h3 class="card card-block bg-secondary text-white">{{$dsc}}</h3>
                        </div>
                        <div class="col-6">
                            <h3 class="card card-block bg-success text-white">
                                @if(!empty($dsc) && !empty($teacherCount))
                                {{number_format($dsc*100/$teacherCount,2)}}%</h3>
                               @endif
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-2 m-2">
                <div class="card text-center pt-2">
                    <div class="card-block">
                        <h3 class="card-title"> PhD ilmiy darajasi mavjud </h3>
                        <h6><i class="fa fa-certificate fa-3x"></i></h6>
                    </div>
                    <div class="row px-2 no-gutters">
                        <div class="col-6">
                            <h3 class="card card-block bg-secondary text-white">{{$phd}}</h3>
                        </div>
                        <div class="col-6">
                            <h3 class="card card-block bg-success text-white">
                                @if(!empty($phd) && !empty($teacherCount))
                                    {{number_format($phd*100/$teacherCount,2)}}%</h3>
                            @endif
{{--                                {{number_format($phd->soni*100/$teacherCount,2)}}%</h3>--}}
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-2 m-2">
                <div class="card text-center pt-2">
                    <div class="card-block">
                        <h3 class="card-title"> Ilmiy darajaga ega bo'lmagan </h3>
                        <h6><i class="fa fa-user fa-3x"></i></h6>
                    </div>
                    <div class="row px-2 no-gutters">
                        <div class="col-6">
                            <h3 class="card card-block bg-secondary text-white">{{($teacherCount-$phd-$dsc-$dotsWithoutDegree)}}</h3>
                        </div>
                        <div class="col-6">
                            @if(!empty($teacherCount) && !empty($teacherCount))
                                @if(number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)>=75)
                                    <h3 class="card card-block bg-danger text-white">{{number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)}}%</h3>
                                @elseif(number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)<75 && number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)>60)
                                    <h3 class="card card-block bg-warning text-white">{{number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)}}%</h3>
                                @elseif(number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)<=60)
                                    <h3 class="card card-block bg-success text-white">{{number_format(($teacherCount-$phd-$dsc-$dotsWithoutDegree)*100/$teacherCount,2)}}%</h3>
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 m-2">
                <div class="card text-center pt-2">
                    <div class="card-block">
                        <h3 class="card-title"> Dotsent ilmiy unvoni mavjud </h3>
                        <h6><i class="fa fa-certificate fa-3x"></i></h6>
                    </div>
                    <div class="row px-2 no-gutters">
                        <div class="col-6">
                            <h3 class="card card-block bg-secondary text-white">{{$dotsent->soni}}</h3>
                        </div>
                        <div class="col-6">
                            <h3 class="card card-block bg-success text-white">
                                @if(!empty($dotsent->soni) && !empty($teacherCount))
                                    {{number_format($dotsent->soni*100/$teacherCount,2)}}%
                                @endif
                            </h3>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-2 m-2">
                <div class="card text-center pt-2">
                    <div class="card-block">
                        <h3 class="card-title"> Professor ilmiy unvoni mavjud </h3>
                        <h6><i class="fa fa-graduation-cap fa-3x"></i></h6>
                    </div>
                    <div class="row px-2 no-gutters">
                        <div class="col-6">
                            <h3 class="card card-block bg-secondary text-white">{{$professor->soni}}</h3>
                        </div>
                        <div class="col-6">

                            <h3 class="card card-block bg-success text-white">
                                @if(!empty($professor->soni) && !empty($teacherCount))
                                    {{number_format($professor->soni*100/$teacherCount,2)}}%
                                @endif
                                </h3>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-8 offset-2">
                <hr>
            </div>
        </div>
        <h3 class="text-center">Kafedra professor-o'qituvchilari faoliyati natijalari </h3>
        <div class="row">
            @foreach($res as $item)
                <div class="col-md-3">
                   <div class="card mb-2">
                       <div class="card-body text-center">

                               <a href="{{route('nachkaf.getTeacherResultsByCategory',$item->id)}}">
                                   <p class="badge-counter badge-success text-center" style="border-radius: 50%; display: inline-block; padding: 10px; align-items: center">{{$item->soni}}</p></a>
                           <p >{{$item->band}}</p>
                       </div>
                   </div>
                </div>
            @endforeach
        </div>
        <div class="row m-2">
            <h3 class="text-center">Tizimga ma'lumot yuklamagan professor-o'qituvchilar</h3>

            <table class="table table-responsive-md table-hover bg-white">

            <tr class=" text-white" style="background-color: #91c8b4">
                <td>#</td>
                <td>------</td>
                <td>F.I.SH</td>
                <td>Lavozimi</td>
            </tr>

                @foreach($passiveTeachs as $item)
                    <tr>
                        <td>{{$item->id}}</td>
                        <td>
                            <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                        </td>
                        <td>{{$item->name}}</td>
                        <td>{{$item->lavozim}}</td>

                    </tr>

                @endforeach
            </table>

        </div>
    </div>
@endsection
