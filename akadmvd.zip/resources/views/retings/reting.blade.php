@extends('layouts.app') @section('content') <div class="container-fluid">
    <a href="{{route('admin.dashboard')}}"><button class="btn btn-info">Ortga</button></a>
    @switch($type_id)
        @case('3e47d333-ee16-4f76-aaae-861c57000c93')
            <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">O‘quv yuklamasi bilan bog‘liq ishlar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                        <th>Reyting</th>
                        <th>-</th>
                        {{-- <th>Rasm</th>--}}
                        <th>F.I.O</th>
{{--                        <th>Lavozim</th>--}}
                        <th>Kafedra</th>
                        <th>Ball</th>
                        </thead>
                        <tbody>
                        {{-- @foreach($teach_reyting as $k=>$item)--}}
                        {{-- <tr>--}}
                        {{-- <td>{{++$k}}</td>--}} {{-- <td>
											<img src="{{asset('storage/profileimages/'.$item->profileimage)}}" alt="" width="64px" style="border-radius: 45%;"> </td>--}} {{-- <td>{{$item->name}}</td>--}} {{-- <td>{{$item->lavozim}}</td>--}} {{-- <td>{{$item->kafName}}</td>--}} {{-- <td>{{$item->ball}}</td>--}} {{-- </tr>--}}
                        {{-- @endforeach--}}
                        </tbody> @foreach($reting as $k=>$item) <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </td>
                            <td>{{$item->name}}</td>
                            {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                            <td>{{$item->ball}}</td>
                        </tr> @endforeach </tbody>
                    </table>

                </div>
            </div>
        </div>
            @break

        @case('d4e45598-6033-4543-89cf-eed106f1127e')
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">О‘quv-uslubiy ishlar reytingi</h6>
                        </div>
                        <div class="card-body">
                            <table class="table  table-hover table-responsive-lg" id="dataTable" width="100%" cellspacing="0">
                                <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                                <tr>
                                    <th>Reyting</th>
                                    <th>-</th>
                                    <th>F.I.O</th>
                                    <th>Kafedra nomi</th>
                                    <th>Ball</th>
                                </tr>
                                </thead>
                                {{-- {{--
                                                                  <tfoot>--}}
                                {{-- <tr>--}}
                                {{-- <th>Reyting</th>--}}
                                {{-- <th>Kafedra nomi</th>--}}
                                {{-- <th>Ball</th>--}}
                                {{-- </tr>--}}
                                {{-- </tfoot>--}}
                                <tbody> @foreach($reting as $k=>$item) <tr>
                                    <td>{{++$k}}</td>
                                    <td>
                                        <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                    </td>
                                    <td>{{$item->name}}</td>
                                    {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                                    <td>{{$item->ball}}</td>
                                </tr> @endforeach </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            @break

        @case('a86e6ca3-9bdc-45ce-a03f-a116315e5d71')
           <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Ilmiy tadqiqot ishlar reytingi</h6>
                </div>
                <div class="card-body">
                    <table class="table  table-hover" id="dataTable" width="100%" cellspacing="0">
                        <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                        <th>Reyting</th>
                        <th>-</th>
                        {{-- <th>Rasm</th>--}}
                        <th>F.I.O</th>
{{--                        <th>Lavozim</th>--}}
                        <th>Kafedra</th>
                        <th>Ball</th>
                        </thead>
                        <tbody> @foreach($reting as $k=>$item) <tr>
                            <td>{{++$k}}</td>
                            <td>
                                <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                            </td>
                            <td>{{$item->name}}</td>
                            {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                            <td>{{$item->ball}}</td>
                        </tr> @endforeach </tbody>
                        <tbody></tbody>
                    </table>

                </div>
            </div>
        </div>
           </div>
            @break
        @case('a843760e-2a2c-4446-aca7-a696d3dd355c')
            <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Jamoat ishlaridagi ishtiroki (“Ustoz-shogird” ishlari)</h6>
                    </div>
                    <div class="card-body">
                        <table class="table  table-hover table-responsive-lg" id="dataTable" width="100%" cellspacing="0">
                            <thead class="text-center" style="color: white; font-size: 16px; background-color: rgb(6 45 163)">
                            <tr>
                                <th>Reyting</th>
                                <th>-</th>
                                <th>F.I.O</th>
                                <th>Kafedra nomi</th>
                                <th>Ball</th>
                            </tr>
                            </thead>
                            {{-- @foreach($kafedra_reyting as $item=>$k)--}}
                            {{-- <tr>--}}
                            {{-- <td>{{++$item}}</td>--}} {{-- <td>{{$k->kafName}}</td>--}} {{-- <td>{{$k->ball}}</td>--}} {{-- </tr>--}}
                            {{-- @endforeach--}}
                            {{-- <tfoot>--}}
                            {{-- <tr>--}}
                            {{-- <th>Reyting</th>--}}
                            {{-- <th>Kafedra nomi</th>--}}
                            {{-- <th>Ball</th>--}}
                            {{-- </tr>--}}
                            {{-- </tfoot>--}}
                            <tbody> @foreach($reting as $k=>$item) <tr>
                                <td>{{++$k}}</td>
                                <td>
                                    <img src="{{asset('storage/userimage/'.$item->image)}}" alt="" width="64px" style="border-radius: 45%;">
                                </td>
                                <td>{{$item->name}}</td>
                                {{-- <td>{{$item->lavozim}}</td>--}} <td>{{$item->kaf_name}}</td>
                                <td>{{$item->ball}}</td>
                            </tr> @endforeach </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
            @break
        @default
            <div>Hatolik yuz berdi.</div>
    @endswitch
@endsection
