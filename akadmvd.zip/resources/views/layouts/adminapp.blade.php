<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'SmartReyting') }}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="{{ asset('js/app.js') }}" defer></script>
    {{--    <link rel="dns-prefetch" href="//fonts.gstatic.com">--}}
    {{--    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">--}}


    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    {{--    <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">--}}
    {{--    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">--}}


    <link href="{{asset('css/sb-admin-2.css')}}" rel="stylesheet">

    {{--    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>--}}
    <style>
        .card-title{font-size: 14px !important;}
        .bg-primary{background-color:rgb(0 35 141) !important;}
        body{font-size:14px !important;}
        .thbody{background-color:rgb(0 35 141);color: white }
        .legend {
            font-size: 1.5rem;
            line-height: inherit;
            display: block;
            width: 100%;
            max-width: 100%;
            margin-bottom: .5rem;
            padding: 0;
            white-space: normal;
            color: inherit;
        }
        h5{background-color: white; padding: 5px; border-radius: 10%; text-align: center !important;}
        .col-auto{width: auto;
            max-width: none;
            flex: 0 0 auto;}
        .icon-shape i {
            font-size: 1.25rem;
        }
        .footer {
            padding: 2.5rem 0;
            background: #f7fafc;
        }

        .footer .copyright {
            font-size: .875rem;
        }

        .header {
            position: relative;
        }

        .icon {
            width: 3rem;
            height: 3rem;
        }

        .icon i {
            font-size: 1.75rem;
        }

        .icon-shape {
            display: inline-flex;
            padding: 12px;
            text-align: center;
            border-radius: 50%;
            align-items: center;
            justify-content: center;
        }
    </style>
    {{--    <script src="{{ asset('js/jquery.js') }}" ></script>--}}
    {{--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>--}}
    {{--    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>--}}

</head>
<body id="page-top">


<div id="wrapper">


    <ul class="navbar-nav bg-primary sidebar sidebar-dark accordion" id="accordionSidebar">


        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{url('/admin/dashboard')}}">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="mx-3 sidebar-brand-text">Smart reyting <sup></sup></div>
            {{--            <div class="sidebar-brand-icon rotate-n-15">--}}
            {{--                <i class="fas fa-user-graduate"></i>--}}
            {{--            </div>--}}
        </a>


        <hr class="my-0 sidebar-divider">


        <li class="nav-item active">
            <a class="nav-link" href="{{url('/admin/dashboard')}}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>O'quv-uslubiy boshqarma kabineti</span></a>
        </li>


        <hr class="sidebar-divider">


        <div class="sidebar-heading">
            Kategoriyalar
        </div>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities2" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-file-pen "></i>
                <span>O‘quv yuklamasi </span>
            </a>
            <div id="collapseUtilities2" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
{{--                    <a class="collapse-item" href="{{route('admin.darslik')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Darsliklar </span></a>--}}
                    <a class="collapse-item" href="{{route('admin.adminuquvmashgulot')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> O'quv mashg'ulot </span></a>
                    <a class="collapse-item" href="{{route('admin.adminkurswork')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Kurs ishlari</span></a>
                    <a class="collapse-item" href="{{route('admin.adminattestat')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Davlat attestatsiyasi</span></a>
                    <a class="collapse-item" href="{{route('admin.adminqaytatopshirish')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Qayta topshirishlar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminmasterclas')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Master klass</span></a>
                    <a class="collapse-item" href="{{route('admin.adminsotengin')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Ijtimoiy so'rov</span></a>
                    <a class="collapse-item" href="{{route('admin.adminfanteach')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> O'zlashtirish</span></a>
                    <a class="collapse-item" href="{{route('admin.adminsustuzlashtirgan')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Sust o'zlashtirish</span></a>
                    <a class="collapse-item" href="{{route('admin.adminsetpednazorat')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Ped nazorat</span></a>
                    <a class="collapse-item" href="{{route('admin.uquvyuklamareyting')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Reyting </span></a>
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-book "></i>
                <span>O'quv-uslbiy ishlar</span>
            </a>
            <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    <a class="collapse-item" href="{{route('admin.admindarsliks')}}"><i class="fa fa-address-book"></i><span for=""> Darsliklar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminmaruzafond')}}"><i class="fa fa-address-card"></i><span for=""> Ma'ruza fondlar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminmajmua')}}"><i class="fa fa-bars-progress"></i><span for=""> Mustaqil yaratilgan majmualar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminuquvmaxsulot')}}"><i class="fa fa-book-open"></i><span for=""> O'quv mahsulotlar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminuquvreja')}}"><i class="fa fa-calendar"></i><span for=""> O'quv rejalar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminkazus')}}"><i class="fa fa-clipboard"></i><span for=""> Kazuslar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminmetodikmat')}}"><i class="fa fa-book-open-reader"></i><span for=""> Metodik materiallar</span></a>
                    <a class="collapse-item" href="{{route('admin.adminpednazorat')}}"><i class="fa fa-file-shield"></i><span for=""> Pedagogik nazorat</span></a>
                    <a class="collapse-item" href="{{route('admin.adminuquvuslubiyreyting')}}"><i class="fa fa-chart-line"></i><span for=""> O'quv-uslubiy reyting</span></a>
{{--                    <a class="collapse-item" href="{{url('/admin/docs')}}"><i class="fa fa-scroll"></i><span for="">  Hujjat turlari</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{url('/admin/kafedras')}}"><i class="fa fa-atom"></i><span for="">  {{__('Kafedra')}}</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{url('/admin/fans')}}"><i class="fa fa-book"></i><span for="">  {{__('Fan')}}</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{url('/admin/mavzus')}}"><i class="fa fa-book"></i><span for="">  {{__('Mavzu')}}</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{url('/admin/groups')}}"><i class="fa fa-certificate"></i><span for=""> {{__('Guruh')}}</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{route('user.loyiha')}}"><i class="fa fa-pencil-ruler"></i><span for="">  Loyihalar</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{route('user.lang')}}"><i class="fa fa-language"></i><span for=""> Til bilish</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{route('user.kurs')}}"><i class="fa fa-users"></i><span for="">  To'garaklar</span></a>--}}
                    {{--                    <a class="collapse-item" href="{{route('user.malaka')}}"><i class="fa fa-hat-wizard"></i><span for="">  Malaka oshirishlar</span></a>--}}
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities4" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Jamoat (Ustoz-shogird) ishlar</span>
            </a>
            <div id="collapseUtilities4" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    <a class="collapse-item" href="{{route('admin.adminwork')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Ishchi guruhlar </span></a>
                    <a class="collapse-item" href="{{route('admin.adminhududmetodik')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Hudud metodikasi </span></a>
                    <a class="collapse-item" href="{{route('admin.adminkurator')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Kuratorlik </span></a>
                    <a class="collapse-item" href="{{route('admin.admincontrolgroup')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Nazorat guruhlarida </span></a>
                    <a class="collapse-item" href="{{route('admin.adminmaster')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Uchrashuvlar </span></a>
                    <a class="collapse-item" href="{{route('admin.adminxizmattekshiruv')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Xizmat tekshiruv </span></a>
                    <a class="collapse-item" href="{{route('admin.adminmalakaoshirish')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Malaka oshirish </span></a>
                    <a class="collapse-item" href="{{route('admin.admintadbir')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Tadbirlar-Chiqishlar </span></a>
                    <a class="collapse-item" href="{{route('admin.adminttg')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Tergov-tezkor guruhi </span></a>
                    <a class="collapse-item" href="{{route('admin.adminijro')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Ijro hujjatlar </span></a>
                    <a class="collapse-item" href="{{route('admin.jamoatishlarreyting')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Reyting </span></a>
                </div>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities5" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-people-line "></i>
                <span>Qo'shimcha sozlamalar</span>
            </a>
            <div id="collapseUtilities5" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    <a class="collapse-item" href="{{route('lavozim.index')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Lavozimlar </span></a>
                    <a class="collapse-item" href="{{route('admin.statsindex')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Statistik jadval</span></a>


                </div>
            </div>
        </li>
    {{--        <li class="nav-item">--}}
    {{--            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities2" aria-expanded="true" aria-controls="collapseUtilities">--}}
    {{--                <i class="fas fa-calendar-day "></i>--}}
    {{--                <span>Dars jadvali</span>--}}
    {{--            </a>--}}
    {{--            <div id="collapseUtilities2" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">--}}
    {{--                <div class="py-2 bg-white rounded collapse-inner">--}}
    {{--                    --}}{{--                    <a class="collapse-item" href="{{route('user.dars')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Maxorat darslari</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/studyyear')}}"><i class="fa fa-hourglass"></i><span for="">  {{__(' O\'quv yili')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/semestrs')}}"><i class="fa fa-hourglass-end"></i><span for="">  {{__(' Semestr')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/comples')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' O\'quv reja')}}</span></a>--}}



    {{--                </div>--}}
    {{--            </div>--}}
    {{--        </li>--}}

    {{--        <li class="nav-item">--}}
    {{--            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities1" aria-expanded="true" aria-controls="collapseUtilities">--}}
    {{--                <i class="fas fa-book "></i>--}}
    {{--                <span>Sozlamalar</span>--}}
    {{--            </a>--}}
    {{--            <div id="collapseUtilities1" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">--}}
    {{--                <div class="py-2 bg-white rounded collapse-inner">--}}
    {{--                    --}}{{--                    <a class="collapse-item" href="{{route('user.dars')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Maxorat darslari</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/docs')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' Hujjat turini kiritish')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/ongenerate')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' ON Generatsiya')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/createyakuniy')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' Yakuniy nazorat')}}</span></a>--}}

    {{--                </div>--}}
    {{--            </div>--}}
    {{--        </li>--}}

    {{--        <li class="nav-item">--}}
    {{--            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities3" aria-expanded="true" aria-controls="collapseUtilities">--}}
    {{--                <i class="fas fa-book "></i>--}}
    {{--                <span>O'zlashtirish</span>--}}
    {{--            </a>--}}
    {{--            <div id="collapseUtilities3" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">--}}
    {{--                <div class="py-2 bg-white rounded collapse-inner">--}}
    {{--                    --}}{{--                    <a class="collapse-item" href="{{route('user.dars')}}"><i class="fa fa-chalkboard-teacher"></i><span for=""> Maxorat darslari</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/showjnmarks')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' Joriy nazorat')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/showonmarks')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' Oraliq nazorat')}}</span></a>--}}
    {{--                    <a class="collapse-item" href="{{url('/admin/showallons')}}"><i class="fa fa-calendar-alt"></i><span for=""> {{__(' ON ')}}</span></a>--}}
    {{--                </div>--}}
    {{--            </div>--}}
    {{--        </li>--}}




    <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="border-0 rounded-circle" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">
                <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
                    <i class="fa fa-bars"></i>
                </button>
                <form class="my-2 mr-auto d-none d-sm-inline-block form-inline ml-md-3 my-md-0 mw-100 navbar-search">
                    <div class="input-group">
                        <input type="text" class="border-0 form-control bg-light small" placeholder="Qidiruv..." aria-label="Search" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <ul class="ml-auto navbar-nav">
                    <li class="nav-item dropdown no-arrow d-sm-none">
                        <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-search fa-fw"></i><sup>2</sup>
                        </a>
                        <div class="p-3 shadow dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="searchDropdown">
                            <form class="mr-auto form-inline w-100 navbar-search">
                                <div class="input-group">
                                    <input type="text" class="border-0 form-control bg-light small" placeholder="Qidiruv..." aria-label="Search" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </li>
                    <li class="mx-1 nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="" >
                            <i class="fas fa-bell fa-fw"></i>
                            <span class="badge badge-danger badge-counter"></span>
                        </a>
                        <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="alertsDropdown">
                            <h6 class="dropdown-header">
                                E'lonlar
                            </h6>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="mr-3">
                                    <div class="icon-circle bg-primary">
                                        <i class="text-white fas fa-file-alt"></i>

                                    </div>
                                </div>
                                <div>
                                    <div class="text-gray-500 small">December 12, 2023</div>
                                </div>
                            </a>

                            <a class="text-center text-gray-500 dropdown-item small" href="#">Show All Alerts</a>
                        </div>
                    </li>
                    <li class="mx-1 nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-envelope fa-fw"></i>
                            <span class="badge badge-danger badge-counter"></span>
                        </a>
                    </li>
                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    {{--                    <li class="nav-item dropdown no-arrow">--}}
                    {{--                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">--}}
                    {{--                            <span class="mr-2 text-gray-600 d-none d-lg-inline small">{{\Illuminate\Support\Facades\Auth::user()->name}}</span>--}}

                    {{--                        </a>--}}
                    {{--                        <!-- Dropdown - User Information -->--}}
                    {{--                        <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="userDropdown">--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-user fa-sm fa-fw"></i>--}}
                    {{--                                Profile--}}
                    {{--                            </a>--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-cogs fa-sm fa-fw"></i>--}}
                    {{--                                Settings--}}
                    {{--                            </a>--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-list fa-sm fa-fw"></i>--}}
                    {{--                                Activity Log--}}
                    {{--                            </a>--}}
                    {{--                            <div class="dropdown-divider"></div>--}}

                    {{--                            <a class="dropdown-item" href="{{route('logout')}}" data-toggle="modall" data-target="#logoutModall">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>--}}
                    {{--                                Logout--}}
                    {{--                            </a>--}}
                    {{--                        </div>--}}
                    {{--                    </li>--}}

{{--                    <li class="nav-item dropdown">--}}
{{--                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>--}}
{{--                            {{ Auth::user()->name }}--}}
{{--                        </a>--}}

{{--                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">--}}
{{--                            <a class="dropdown-item" href="{{ route('logout') }}"--}}
{{--                               onclick="event.preventDefault();--}}
{{--                                                     document.getElementById('logout-form').submit();">--}}
{{--                                {{ __('Chiqish') }}--}}
{{--                            </a>--}}

{{--                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">--}}
{{--                                @csrf--}}
{{--                            </form>--}}
{{--                        </div>--}}
{{--                    </li>--}}
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ Auth::user()->name }}
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li>
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"
                               href="{{ route('logout') }}"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                {{ __('Chiqish') }}
                            </a>
                        </li>
                        </ul>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </li>
                </ul>
            </nav>
            @yield('content')
        </div>
        <!-- End of Main Content -->
        <!-- Footer -->
    <footer class="bg-white sticky-footer">
            <div class="container my-auto">
                <div class="my-auto text-center copyright">
                    <span>IIV Akademiyasi &copy; Axborot texnologiyalarini joriy etish va ta'limni raqamlashtirish bo'limi 2022</span>
                </div>
            </div>
    </footer>
        <!-- End of Footer -->
    </div>

    <!-- End of Content Wrapper -->
    <!-- Bootstrap core JavaScript-->
</div>
{{--@livewireScripts--}}
{{--<script type="text/javascript">--}}
{{--    window.livewire.on('docadded',()=>{--}}
{{--        $('#createHujjat').modal('hide');--}}
{{--    });--}}
{{--</script>--}}
</body>
<script>
    var ctx = document.getElementById("myAreaChart").getContext('2d');
    var myLineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels:['2016','2017','2018','2019','2020','2021'],
            // labels: ["2016", "2017", "2018", "2019", "2020"],
            datasets: [{
                label: "",
                lineTension: 0.3,
                backgroundColor: "rgba(78, 115, 223, 0.05)",
                borderColor: "rgba(78, 115, 223, 1)",
                pointRadius: 3,
                pointBackgroundColor: "rgba(78, 115, 223, 1)",
                pointBorderColor: "rgba(78, 115, 223, 1)",
                pointHoverRadius: 3,
                pointHoverBackgroundColor: "rgba(78, 115, 223, 1)",
                pointHoverBorderColor: "rgba(78, 115, 223, 1)",
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data:['1','3','3','4','4','6'],
                //data: [10, 11, 20, 25, 30],
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function(value, index, values) {
                            return '#' + number_format(value);
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': #' + number_format(tooltipItem.yLabel);
                    }
                }
            }
        }
    });
    var ctx = document.getElementById("myPieChart");
    var myPieChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Fan doktorlari", "PhD", "Mavjud emas"],
            datasets: [{
                data: [8.33, 29.17, 62.50],
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
                hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }],
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
            },
            legend: {
                display: false
            },
            cutoutPercentage: 80,
        },
    });

    function getTuriName(){
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball_id = document.getElementById('ball_id');
        var temp_muallif_id = document.getElementById('muallif_id');
        var temp_taboq_id = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1)
        {
            temp_ball_id.value = (temp_taboq_id.value * 5)/temp_muallif_id.value;
        }
        else if(turi_name.value == 2)
        {
            temp_ball_id.value = (temp_taboq_id.value * 2.5)/temp_muallif_id.value;
        }
        else if(turi_name.value == 3)
        {
            temp_ball_id.value = (temp_taboq_id.value * 2)/temp_muallif_id.value;
        }
        else if(turi_name.value == 4)
        {
            temp_ball_id.value = (temp_taboq_id.value * 1.5)/temp_muallif_id.value;
        }
        // else
        // {
        //     temp_ball_id.value = 0;
        // }
         console.log(turi_name_id.value);
    }
    function getBallAdmin()
    {
        var turi_name = document.getElementById('turi_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_mavzu_soni = document.getElementById('mavzu_soni_id');
        var turi_name_id = document.getElementById('turi_name_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        temp_ball.value = temp_mavzu_soni.value * 10;
        console.log(turi_name_id.value);
    }

    function getMajmuaBall()
    {
        var turi_name = document.getElementById('turi_id');
        var temp_ball = document.getElementById('ball_id');
        var turi_name_id = document.getElementById('turi_name_id');
        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5;}else if(turi_name.value == 2){ temp_ball.value = 10;} console.log(temp_ball.value)
    }
    function getMajmuaBall2()
    {
        var turi_name = document.getElementById('turi_id');
        var temp_ball = document.getElementById('ball_id');
        var turi_name_id = document.getElementById('turi_name_id');
        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 10;}else if(turi_name.value == 2){ temp_ball.value = 15;} console.log(temp_ball.value)
    }
    function getUquvrejaTuriName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5;}else if(turi_name.value == 2){ temp_ball.value = 5;}else if(turi_name.value == 3){ temp_ball.value = 5;}
        else if(turi_name.value == 4){ temp_ball.value = 3;}else if(turi_name.value == 5){ temp_ball.value = 3;}
        //console.log(temp_ball.value)
        //console.log(turi_name_id.value);
    }
    function getKazusTuriName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5;}else if(turi_name.value == 2){ temp_ball.value = 2.5;}else if(turi_name.value == 3){ temp_ball.value = 1.5;}

        // console.log(turi_name_id.value);
    }

    function getMetodikmatTuriName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;

        if(turi_name.value == 1) { temp_ball.value = 2.5;}
        else if(turi_name.value == 2){ temp_ball.value = 3.5;}
        else if(turi_name.value == 3){ temp_ball.value = 4;}
        else if(turi_name.value == 4){ temp_ball.value = 5;}
        else if(turi_name.value == 5){ temp_ball.value =3;}
        else if(turi_name.value == 6){ temp_ball.value = 2;}
        //console.log(turi_name_id.value);
        // console.log(turi_name_id.value);
    }
    function getPednazoratTuriName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 0.5*temp_soni_id.value;}
        else if(turi_name.value == 2){ temp_ball.value = 0.1*temp_soni_id.value;}
        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getUquvmashgulotName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;

        if(turi_name.value == 1) { temp_ball.value = 150;}
        else if(turi_name.value == 2){  temp_ball.value = temp_soni_id.value/10;}
        // else if(turi_name.value == 3){ temp_ball.value = 1*temp_soni_id.value;}
        // else if(turi_name.value == 4){ temp_ball.value = 0.1*temp_soni_id.value;}
        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getkursworkBall()
    {
        //var turi_name = document.getElementById('turi_id');
        //var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        temp_ball.value = 0.5*temp_soni_id.value;

    }
    function getQaytatopshirishName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 0.5*temp_soni_id.value;}
        else if(turi_name.value == 2){ temp_ball.value = 1*temp_soni_id.value;}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getMasterclasName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 2*temp_soni_id.value;}
        else if(turi_name.value == 2){ temp_ball.value = 3*temp_soni_id.value;}
        else if(turi_name.value == 3){ temp_ball.value = 5*temp_soni_id.value;}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getSotenginName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        // var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 15}
        else if(turi_name.value == 2){ temp_ball.value = 10}
        else if(turi_name.value == 3){ temp_ball.value = 5}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getFanteachName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        // var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5}
        else if(turi_name.value == 2){ temp_ball.value = 4}
        // else if(turi_name.value == 3){ temp_ball.value = 5}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }

    function getSustuzlashtirganName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = temp_soni_id.value*1.5}
        else if(turi_name.value == 2){ temp_ball.value = temp_soni_id.value*3}
        else if(turi_name.value == 3){ temp_ball.value = temp_soni_id.value*2}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getSetpednazoratName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        // var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 10}
        else if(turi_name.value == 2){ temp_ball.value = 5}
        // else if(turi_name.value == 3){ temp_ball.value = temp_soni_id.value*2}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }
    function getHududmetodikBall()
    {
        var taboq_val = document.getElementById('taboq_id');
        var soni_val = document.getElementById('soni_id');
        // var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        // const desc = turi_name.options[turi_name.selectedIndex].text;
        // turi_name_id.value = desc;
        temp_ball.value = 7*taboq_val.value/soni_val.value;
        // if(turi_name.value == 1) { temp_ball.value = 10}
        // else if(turi_name.value == 2){ temp_ball.value = 5}
        // else if(turi_name.value == 3){ temp_ball.value = temp_soni_id.value*2}

        //console.log(turi_name_id.value);
        //console.log(temp_ball.value);
    }

    function getControlgroupName()
    {

        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
       if(turi_name.value==1){ temp_ball.value = 5;}
       else if(turi_name.value==2){ temp_ball.value = 2.5;}
       else if(turi_name.value==3){ temp_ball.value = 2.5;}
        // console.log(turi_name_id.value);
        // console.log(temp_ball.value);
    }

    function getTadbirName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value==1){ temp_ball.value = 10;}
        else if(turi_name.value==2){ temp_ball.value = 10;}
        else if(turi_name.value==3){ temp_ball.value = 7;}
    }
    function getTtgBall()
    {
        var soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');
        temp_ball.value = soni_id.value*1;
    }

    function getIjroName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value==1){ temp_ball.value = 10;}
        else if(turi_name.value==2){ temp_ball.value = 8;}
        else if(turi_name.value==3){ temp_ball.value = 5;}
    }
</script>
<script src="{{asset('vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

<!-- Core plugin JavaScript-->
<script src="{{asset('vendor/jquery-easing/jquery.easing.min.js')}}"></script>

<!-- Custom scripts for all pages-->
<script src="{{asset('js/sb-admin-2.min.js')}}"></script>

<!-- Page level plugins -->
<script src="{{asset('vendor/chart.js/Chart.min.js')}}"></script>

<!-- Page level custom scripts -->
<script src="{{asset('js/demo/chart-area-demo.js')}}"></script>
<script src="{{asset('js/demo/chart-pie-demo.js')}}"></script>
<script type="text/javascript">
    var ctx = document.getElementById("myBarChart");
    var myBarChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ["ATK", "TQFK", "DTK", "HTK", "DHFK", "ss","dd", "fg", "uh", "HTK", "DHFK", "IIFK","ATK", "TQFK", "DTK", "HTK", "DHFK", "IIFK","ATK", "TQFK", "DTK", "HTK", "DHFK", "IIFK"],
            datasets: [{
                label: "",
                backgroundColor: ["#0000000","#1cc88a"],
                hoverBackgroundColor: "#4e73df",
                borderColor: "#4e73df",
                data: [215, 312, 251, 841, 821, 4984, 4215, 5312, 6251, 7841, 9821, 4984,4215, 5312, 6251, 7841, 9821, 4984,4215, 5312, 10, 100, 1000, 1],
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'month'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 6
                    },
                    maxBarThickness: 25,
                }],
                yAxes: [{
                    ticks: {
                        min: 0,
                        max: 10000,
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function(value, index, values) {
                            return '#' + number_format(value);
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#9561e2",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
                callbacks: {
                    label: function(tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + '' + number_format(tooltipItem.yLabel);
                    }
                }
            },
        }
    });
</script>
<script  type="text/javascript">
    window.livewire.on('darstas', () => {
        $('#darsupdate').modal('hide');
    });
    window.livewire.on('darstasdiqlandi',()=>{
        $('#darsupdate').modal('hide');
    });
    window.livewire.on('maqolatasdiqlandi',()=>{
        $('#maqolanitaxrirlash').modal('hide');
    });
    window.livewire.on('dissertatsiyatasdiqlandi',()=>{
        $('#dissertatsiyanitasdiqlash').modal('hide');
    });
    window.livewire.on('dissertatsiyauchirildi',()=>{
        $('#dissertatsiyaniuchirish').modal('hide');
    });
    window.livewire.on('materialtasdiqlandi',()=>{
        $('#materialnitasdiqlash').modal('hide');
    });
    window.livewire.on('patenttasdiqandi',()=>{
        $('#patentnitasdiqlash').modal('hide');
    });
    window.livewire.on('loyihadeleted',()=>{
        $('#loyihadelet').modal('hide');
    });
    window.livewire.on('loyihatasdiqlandi',()=>{
        $('#loyihanitasdiqlash').modal('hide');
    });
    window.livewire.on('langtasdiqlandi',()=>{
        $('#langtasdiqlash').modal('hide');
    });
    window.livewire.on('langdeleted',()=>{
        $('#langdelete').modal('hide');
    });
    window.livewire.on('kurstasdiqlandi',()=>{
        $('#kurstasdiqlash').modal('hide');
    });
    window.livewire.on('kursdeleted',()=>{
        $('#kursdelete').modal('hide');
    });
    window.livewire.on('malakatasdiqlandi',()=>{
        $('#malakatasdiqlash').modal('hide');
    });
    window.livewire.on('malakadeleted',()=>{
        $('#malakadelete').modal('hide');
    });
    window.livewire.on('elonsaqlandi',()=>{
        $('#messagesaqlash').modal('hide');
    });
    window.livewire.on('elonuzgardi',()=>{
        $('#messageupdate').modal('hide');
    });
    // function getdarsball(){
    //     var darsID =$("#ballid").val();
    //
    //     var darsVal = document.querySelector("#darsVal");
    //     if (darsID==1)
    //     {
    //         darsVal.value=12.5;
    //     }
    //     if     (darsID==2)
    //     {
    //         darsVal.value=35;
    //     }
    //
    //     if (darsID==0)
    //     {
    //
    //         darsVal.value=0;
    //     }
    //
    //
    //     // //miqyosVal.value = miqyosID;
    //     console.log(darsVal.value );
    //}
    // function getDissVal(){
    //     var dissID =  $( "#maqomi" ).val();
    //     var dissVal = document.querySelector("#dissVal");
    //     if (dissID==1)
    //     {
    //         dissVal.value=12.5;
    //     }
    //     if     (dissID==2)
    //     {
    //         dissVal.value=35;
    //     }
    //
    //     if (dissID==0)
    //     {
    //
    //         dissVal.value=0;
    //     }
    //
    //
    //     // //miqyosVal.value = miqyosID;
    //     console.log(dissVal.value );
    // }
    // function getLangVal(){
    //     var levelID =  $( "#levelID" ).val();
    //     var levelVal = document.querySelector("#levelVal");
    //     if (levelID==1)
    //     {
    //         levelVal.value=10;
    //     }
    //     if     (levelID==2)
    //     {
    //         levelVal.value=7.5;
    //     }
    //     if (levelID==3)
    //     {
    //         levelVal.value=5;
    //     }
    //     if (levelID==0)
    //     {
    //
    //         levelVal.value=0;
    //     }
    //
    //
    //     // //miqyosVal.value = miqyosID;
    //     console.log(levelVal.value );
    // }
    // function getMiqyosVal(){
    //     var miqyosID =  $( "#miqyosID" ).val();
    //     var miqyosVal = document.querySelector("#miqyosVal");
    //     if (miqyosID==3)
    //     {
    //         miqyosVal.value=15;
    //     }
    //     if     (miqyosID==4)
    //     {
    //         miqyosVal.value=7.5;
    //     }
    //     if (miqyosID==5)
    //     {
    //         miqyosVal.value=10;
    //     }
    //     if (miqyosID==6)
    //     {
    //
    //         miqyosVal.value=5;
    //     }
    //     if (miqyosID==0)
    //     {
    //
    //         miqyosVal.value=0;
    //     }
    //
    //
    //     // //miqyosVal.value = miqyosID;
    //     console.log(miqyosVal.value );
    // };
    // function getPatentBall(){
    //     var patentID=$("#patentID").val();
    //     var patentBall=document.querySelector("#patentBall");
    //     if(patentID==1)
    //     {
    //         patentBall.value=15;
    //     }
    //     if(patentID==2)
    //     {
    //         patentBall.value=7.5;
    //     }
    //     if(patentID==0)
    //     {
    //         patentBall.value=0;
    //     }
    //     console.log(patentBall.value );
    // }
    // function getMaterialBall(){
    //     var patentID=$("#turiID").val();
    //     var muallifID=$("#muallifID").val();
    //     var taboqID=$("#taboqID").val();
    //     var patentBall=document.querySelector("#materialBall");
    //     if(patentID==1)
    //     {
    //         patentBall.value=taboqID*2.5/muallifID;
    //     }
    //     if(patentID==2)
    //     {
    //         patentBall.value=taboqID*1.5/muallifID;
    //     }
    //     if(patentID==3)
    //     {
    //         patentBall.value=taboqID*1.5/muallifID;
    //     }
    //     if(patentID==4)
    //     {
    //         patentBall.value=taboqID*2.5/muallifID;
    //     }
    //     if(patentID==0)
    //     {
    //         patentBall.value=0;
    //     }
    //     console.log(patentBall.value );
    // }

    // function getValue(){
    //     var Val = document.getElementById("miqyosi").value;
    //     alert(Val);
    // };
    // Area Chart Example


    // Pie Chart Example
    var ctx = document.getElementById("myPieChart");
    var myPieChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["Fan doktorlari", "PhD", "Mavjud emas"],
            datasets: [{
                data: [8.33, 29.17, 62.50],
                backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc'],
                hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
                hoverBorderColor: "rgba(234, 236, 244, 1)",
            }],
        },
        options: {
            maintainAspectRatio: false,
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                caretPadding: 10,
            },
            legend: {
                display: false
            },
            cutoutPercentage: 80,
        },
    });

    // Bar Chart Example



    // var ctx = document.getElementById('myChart');
    // var myChart = new Chart(ctx, {
    //     type: 'bar',
    //     data: {
    //         labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
    //         datasets: [{
    //             label: '# of Votes',
    //             data: [12, 19, 3, 5, 2, 3],
    //             backgroundColor: [
    //                 'rgba(255, 99, 132, 0.2)',
    //                 'rgba(54, 162, 235, 0.2)',
    //                 'rgba(255, 206, 86, 0.2)',
    //                 'rgba(75, 192, 192, 0.2)',
    //                 'rgba(153, 102, 255, 0.2)',
    //                 'rgba(255, 159, 64, 0.2)'
    //             ],
    //             borderColor: [
    //                 'rgba(255, 99, 132, 1)',
    //                 'rgba(54, 162, 235, 1)',
    //                 'rgba(255, 206, 86, 1)',
    //                 'rgba(75, 192, 192, 1)',
    //                 'rgba(153, 102, 255, 1)',
    //                 'rgba(255, 159, 64, 1)'
    //             ],
    //             borderWidth: 1
    //         }]
    //     },
    //     options: {
    //         scales: {
    //             yAxes: [{
    //                 ticks: {
    //                     beginAtZero: true
    //                 }
    //             }]
    //         }
    //     }
    // });
</script>
</html>
