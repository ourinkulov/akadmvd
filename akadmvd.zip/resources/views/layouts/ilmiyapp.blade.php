<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'E-HUJJAT') }}</title>

    <script src="{{ asset('js/app.js') }}" defer></script>
    {{--    <link rel="dns-prefetch" href="//fonts.gstatic.com">--}}
    {{--    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">--}}


    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    {{--    <link href="{{asset('vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">--}}
    {{--    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">--}}


    <link href="{{asset('css/sb-admin-2.css')}}" rel="stylesheet">

    {{--    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>--}}
    <style>
        .card-title{font-size: 14px !important;}
        .bg-primary{background-color:rgb(0 35 141) !important;}
        body{font-size:14px !important;}
        .thbody{background-color:rgb(0 35 141);color: white }
        .legend {
            font-size: 1.5rem;
            line-height: inherit;
            display: block;
            width: 100%;
            max-width: 100%;
            margin-bottom: .5rem;
            padding: 0;
            white-space: normal;
            color: inherit;
        }
        .col-auto{width: auto;
            max-width: none;
            flex: 0 0 auto;}
        .icon-shape i {
            font-size: 1.25rem;
        }
        .footer {
            padding: 2.5rem 0;
            background: #f7fafc;
        }

        .footer .copyright {
            font-size: .875rem;
        }

        .header {
            position: relative;
        }

        .icon {
            width: 3rem;
            height: 3rem;
        }

        .icon i {
            font-size: 1.75rem;
        }

        .icon-shape {
            display: inline-flex;
            padding: 12px;
            text-align: center;
            border-radius: 50%;
            align-items: center;
            justify-content: center;
        }
    </style>
    {{--    <script src="{{ asset('js/jquery.js') }}" ></script>--}}
    {{--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>--}}
    {{--    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>--}}

</head>
<body id="page-top">


<div id="wrapper">


    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">


        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{url('/ilmiy/dashboard')}}">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="mx-3 sidebar-brand-text">Smart reyting <sup></sup></div>
            {{--            <div class="sidebar-brand-icon rotate-n-15">--}}
            {{--                <i class="fas fa-user-graduate"></i>--}}
            {{--            </div>--}}
        </a>


        <hr class="my-0 sidebar-divider">


        <li class="nav-item active">
            <a class="nav-link" href="{{url('/ilmiy/dashboard')}}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Ilmiy tadqiqot bo'limi kabineti</span></a>
        </li>


        <hr class="sidebar-divider">


        <div class="sidebar-heading">
            SAXIFALAR
        </div>

        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseUtilities3" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="fas fa-rocket "></i>
                <span>Ilmiy-tadqiqot ishlar</span>
            </a>
            <div id="collapseUtilities3" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="py-2 bg-white rounded collapse-inner">
                    @foreach($k3 as $kr)
                        <a class="collapse-item" href="{{route('kriteriya.index', ['route' => $kr->route])}}"><i class="fa fa-list"></i><span for=""> {{ $kr->menu }} </span></a>
                    @endforeach
                </div>
            </div>
        </li>
    <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="border-0 rounded-circle" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="mb-4 bg-white shadow navbar navbar-expand navbar-light topbar static-top">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="mr-3 btn btn-link d-md-none rounded-circle">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Search -->
                <form class="my-2 mr-auto d-none d-sm-inline-block form-inline ml-md-3 my-md-0 mw-100 navbar-search">
                    <div class="input-group">
                        <input type="text" class="border-0 form-control bg-light small" placeholder="Qidiruv..." aria-label="Search" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Topbar Navbar -->
                <ul class="ml-auto navbar-nav">

                    <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                    <li class="nav-item dropdown no-arrow d-sm-none">
                        <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-search fa-fw"></i><sup>2</sup>
                        </a>
                        <!-- Dropdown - Messages -->
                        <div class="p-3 shadow dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="searchDropdown">
                            <form class="mr-auto form-inline w-100 navbar-search">
                                <div class="input-group">
                                    <input type="text" class="border-0 form-control bg-light small" placeholder="Qidiruv..." aria-label="Search" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </li>

                    <!-- Nav Item - Alerts -->
                    <li class="mx-1 nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="" >
                            <i class="fas fa-bell fa-fw"></i>
                            <!-- Counter - Alerts -->
                            <span class="badge badge-danger badge-counter"></span>
                        </a>
                        <!-- Dropdown - Alerts -->
                        <div class="shadow dropdown-list dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="alertsDropdown">
                            <h6 class="dropdown-header">
                                E'lonlar
                            </h6>
                            <a class="dropdown-item d-flex align-items-center" href="#">
                                <div class="mr-3">
                                    <div class="icon-circle bg-primary">
                                        <i class="text-white fas fa-file-alt"></i>

                                    </div>
                                </div>
                                <div>
                                    <div class="text-gray-500 small">December 12, 2019</div>

                                </div>
                            </a>

                            <a class="text-center text-gray-500 dropdown-item small" href="#">Show All Alerts</a>
                        </div>
                    </li>

                    <!-- Nav Item - Messages -->
                    <li class="mx-1 nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-envelope fa-fw"></i>
                            <!-- Counter - Messages -->
                            <span class="badge badge-danger badge-counter"></span>
                        </a>

                    </li>

                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    {{--                    <li class="nav-item dropdown no-arrow">--}}
                    {{--                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">--}}
                    {{--                            <span class="mr-2 text-gray-600 d-none d-lg-inline small">{{\Illuminate\Support\Facades\Auth::user()->name}}</span>--}}

                    {{--                        </a>--}}
                    {{--                        <!-- Dropdown - User Information -->--}}
                    {{--                        <div class="shadow dropdown-menu dropdown-menu-right animated--grow-in" aria-labelledby="userDropdown">--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-user fa-sm fa-fw"></i>--}}
                    {{--                                Profile--}}
                    {{--                            </a>--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-cogs fa-sm fa-fw"></i>--}}
                    {{--                                Settings--}}
                    {{--                            </a>--}}
                    {{--                            <a class="dropdown-item" href="#">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-list fa-sm fa-fw"></i>--}}
                    {{--                                Activity Log--}}
                    {{--                            </a>--}}
                    {{--                            <div class="dropdown-divider"></div>--}}

                    {{--                            <a class="dropdown-item" href="{{route('logout')}}" data-toggle="modall" data-target="#logoutModall">--}}
                    {{--                                <i class="mr-2 text-gray-400 fas fa-sign-out-alt fa-sm fa-fw"></i>--}}
                    {{--                                Logout--}}
                    {{--                            </a>--}}
                    {{--                        </div>--}}
                    {{--                    </li>--}}

                    {{--                    <li class="nav-item dropdown">--}}
                    {{--                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>--}}
                    {{--                            {{ Auth::user()->name }}--}}
                    {{--                        </a>--}}

                    {{--                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">--}}
                    {{--                            <a class="dropdown-item" href="{{ route('logout') }}"--}}
                    {{--                               onclick="event.preventDefault();--}}
                    {{--                                                     document.getElementById('logout-form').submit();">--}}
                    {{--                                {{ __('Chiqish') }}--}}
                    {{--                            </a>--}}

                    {{--                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">--}}
                    {{--                                @csrf--}}
                    {{--                            </form>--}}
                    {{--                        </div>--}}
                    {{--                    </li>--}}
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ Auth::user()->name }}
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"
                                   href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    {{ __('Chiqish') }}
                                </a>
                            </li>
                        </ul>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </li>

                </ul>

            </nav>
            @yield('content')
        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="bg-white sticky-footer">
            <div class="container my-auto">
                <div class="my-auto text-center copyright">
                    <span>IIV Akademiyasi &copy; Axborot texnologiyalari va ta'limni raqamlashtirish bo'limi 2022</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    <!-- Bootstrap core JavaScript-->
</div>
{{--@livewireScripts--}}
{{--<script type="text/javascript">--}}
{{--    window.livewire.on('docadded',()=>{--}}
{{--        $('#createHujjat').modal('hide');--}}
{{--    });--}}
{{--</script>--}}

<script >
    function getIlmiydarajaName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 10;}
        else if(turi_name.value == 2){ temp_ball.value = 15;}
        // console.log(turi_name_id.value);
        // console.log(temp_ball.value);
    }

    function getIlmiyunvonName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_soni_id = document.getElementById('soni_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 7.5;}
        else if(turi_name.value == 2){ temp_ball.value = 10;}
        // console.log(turi_name_id.value);
        // console.log(temp_ball.value);
    }
    function getIlmiymaktabName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        // var temp_soni_id = document.getElementById('soni_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        console.log(turi_name_id.value);
    }
    function getDissertathimoyaName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 2;}
        else if(turi_name.value == 2){ temp_ball.value = 3;}
       // console.log(turi_name_id.value);
    }
    function getIlmiykengashName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5;}
        else if(turi_name.value == 2){ temp_ball.value = 3.5;}
        else if(turi_name.value == 3){ temp_ball.value = 3.5;}
        else if(turi_name.value == 4){ temp_ball.value = 2.5;}
        else if(turi_name.value == 5){ temp_ball.value = 5;}
        //console.log(turi_name_id.value);
    }
    function getIlmiyseminarName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 4;}
        else if(turi_name.value == 2){ temp_ball.value = 3;}
        else if(turi_name.value == 3){ temp_ball.value = 2;}
        //console.log(turi_name_id.value);
    }
    function getJurnalName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 2.5;}
        else if(turi_name.value == 2){ temp_ball.value = 5;}

        //console.log(turi_name_id.value);
    }
    function getTadqiqotnatijaName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 15;}
        else if(turi_name.value == 2){ temp_ball.value = 10;}
        else if(turi_name.value == 3){ temp_ball.value = 5;}

        console.log(turi_name_id.value);
    }
    function getLoyihaName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 5;}
        else if(turi_name.value == 2){ temp_ball.value = 4;}
        else if(turi_name.value == 3){ temp_ball.value = 3;}
        else if(turi_name.value == 4){ temp_ball.value = 2;}

        //console.log(turi_name_id.value);
    }
    function getMonografiyaName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_muallif_soni = document.getElementById('muallif_soni');
        var temp_taboq_soni = document.getElementById('taboq_soni');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (1*temp_taboq_soni.value)/temp_muallif_soni.value;}
        else if(turi_name.value == 2){ temp_ball.value = (2*temp_taboq_soni.value)/temp_muallif_soni.value;}
        else if(turi_name.value == 3){ temp_ball.value = (2*temp_taboq_soni.value)/temp_muallif_soni.value;}
        else if(turi_name.value == 4){ temp_ball.value = (3*temp_taboq_soni.value)/temp_muallif_soni.value;;}

        //console.log(turi_name_id.value);
    }
    function getIlmiyishlarName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_muallif_soni = document.getElementById('muallif_soni');
        // var temp_taboq_soni = document.getElementById('taboq_soni');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = 15/temp_muallif_soni.value;}
        else if(turi_name.value == 2){ temp_ball.value = 7/temp_muallif_soni.value;}
        else if(turi_name.value == 3){ temp_ball.value = 5/temp_muallif_soni.value;}
        else if(turi_name.value == 4){ temp_ball.value = 3/temp_muallif_soni.value;}
        else if(turi_name.value == 5){ temp_ball.value = 2/temp_muallif_soni.value;}

        //console.log(turi_name_id.value);
    }
    function getIqtibosName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_muallif_soni = document.getElementById('soni_id');
        var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (12.5*temp_taboq_soni.value)/temp_muallif_soni.value;}
        else if(turi_name.value == 2){ temp_ball.value = (10*temp_taboq_soni.value)/temp_muallif_soni.value;}
        else if(turi_name.value == 3){ temp_ball.value = (5*temp_taboq_soni.value)/temp_muallif_soni.value;}

        //console.log(turi_name_id.value);
    }

    function getGrandName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (12.5);}
        else if(turi_name.value == 2){ temp_ball.value = (7);}
        else if(turi_name.value == 3){ temp_ball.value = (5);}

        //console.log(turi_name.value);
    }
    //Taqriz
    function getTaqrizName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (2.5);}
        else if(turi_name.value == 2){ temp_ball.value = (3.5);}
        else if(turi_name.value == 3){ temp_ball.value = (3);}
        else if(turi_name.value == 4){ temp_ball.value = (4);}
        else if(turi_name.value == 5){ temp_ball.value = (3.5);}
        else if(turi_name.value == 6){ temp_ball.value = (4.5);}
        else if(turi_name.value == 7){ temp_ball.value = (5);}
        else if(turi_name.value == 8){ temp_ball.value = (5);}


        console.log(turi_name_id.value);
    }
    function getKonfName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (5);}
        else if(turi_name.value == 2){ temp_ball.value = (5);}
        else if(turi_name.value == 3){ temp_ball.value = (10);}
        else if(turi_name.value == 4){ temp_ball.value = (3);}
        else if(turi_name.value == 5){ temp_ball.value = (3);}
        else if(turi_name.value == 6){ temp_ball.value = (1);}



        console.log(turi_name_id.value);
    }

    function getKasbiymaxoratName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (5);}
        else if(turi_name.value == 2){ temp_ball.value = (5*0.75);}
        else if(turi_name.value == 3){ temp_ball.value = (5*0.50);}
        else if(turi_name.value == 4){ temp_ball.value = (10);}
        else if(turi_name.value == 5){ temp_ball.value = (10*0.75);}
        else if(turi_name.value == 6){ temp_ball.value = (10*0.50);}
        else if(turi_name.value == 7){ temp_ball.value = (20);}
        else if(turi_name.value == 8){ temp_ball.value = (20*0.75);}
        else if(turi_name.value == 9){ temp_ball.value = (20*0.50);}

        else if(turi_name.value == 10){ temp_ball.value = (7);}
        else if(turi_name.value == 11){ temp_ball.value = (7*0.75);}
        else if(turi_name.value == 12){ temp_ball.value = (7*0.50);}
        else if(turi_name.value == 13){ temp_ball.value = (15);}
        else if(turi_name.value == 14){ temp_ball.value = (15*0.75);}
        else if(turi_name.value == 15){ temp_ball.value = (15*0.50);}
        else if(turi_name.value == 16){ temp_ball.value = (22);}
        else if(turi_name.value == 17){ temp_ball.value = (22*0.75);}
        else if(turi_name.value == 18){ temp_ball.value = (22*0.50);}
        //console.log(temp_ball.value);

    }

    function getTilName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (15);}
        else if(turi_name.value == 2){ temp_ball.value = (12);}
        else if(turi_name.value == 3){ temp_ball.value = (10);}
        else if(turi_name.value == 4){ temp_ball.value = (7);}
        else if(turi_name.value == 5){ temp_ball.value = (5);}
        else if(turi_name.value == 6){ temp_ball.value = (3);}
        else if(turi_name.value == 7){ temp_ball.value = (10);}
        else if(turi_name.value == 8){ temp_ball.value = (7);}
        else if(turi_name.value == 9){ temp_ball.value = (5);}

        else if(turi_name.value == 10){ temp_ball.value = (4);}
        else if(turi_name.value == 11){ temp_ball.value = (3);}
        else if(turi_name.value == 12){ temp_ball.value = (2);}
        else if(turi_name.value == 13){ temp_ball.value = (8);}

        //console.log(temp_ball.value);
    }

    function getTugarakName()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        // var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (10);}
        else if(turi_name.value == 2){ temp_ball.value = (3);}


        //console.log(turi_name.value);
    }

    function getRaxbarName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (1.5*temp_muallif_soni.value);}
        else if(turi_name.value == 2){ temp_ball.value = (1.5*temp_muallif_soni.value);}
        //console.log(turi_name.value);
    }
    function getAtestatName2()
    {
        var turi_name = document.getElementById('turi_id');
        var turi_name_id = document.getElementById('turi_name_id');
        var temp_ball = document.getElementById('ball_id');
        var temp_muallif_soni = document.getElementById('soni_id');
        // var temp_taboq_soni = document.getElementById('taboq_id');

        const desc = turi_name.options[turi_name.selectedIndex].text;
        turi_name_id.value = desc;
        if(turi_name.value == 1) { temp_ball.value = (0.5);}
        else if(turi_name.value == 2){ temp_ball.value = (1);}
        else if(turi_name.value == 3){ temp_ball.value = (2);}


        //console.log(turi_name.value);
    }



</script>
</body>

</html>
